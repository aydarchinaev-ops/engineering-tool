import { registerPlugin } from './engine'
import type { FindingLocation } from '@/types/analysis'

// ─── Встроенные плагины-анализаторы ──────────────────────────────────────────
// Каждый плагин — самостоятельный модуль с интерфейсом AnalyzerPlugin.
// Новый анализ = новый вызов registerPlugin() здесь или в любом другом модуле.

const MAX_LOCATIONS = 12

function makeLocation(text: string, index: number, match: string): FindingLocation {
  const from = Math.max(0, index - 35)
  const to = Math.min(text.length, index + match.length + 35)
  const context =
    (from > 0 ? '…' : '') + text.slice(from, to).replace(/\s+/g, ' ').trim() + (to < text.length ? '…' : '')
  return { match, index, context }
}

registerPlugin({
  id: 'vague-terms',
  name: 'Размытые формулировки',
  description: 'Ищет неопределённые обороты, которые нельзя проверить при приёмке',
  run: (text) => {
    const vague = [
      'и т\\.?\\s?д\\.?', 'и т\\.?\\s?п\\.?', 'т\\.?\\s?н\\.?', 'проч(ее|ие|его)',
      'по\\s+возможности', 'по\\s+усмотрению', 'и\\s+так\\s+далее',
      'современн(ый|ого|ые)', 'удобн(ый|ого|ые)', 'быстр(ый|ого|ые)',
      'качественн(ый|ого|ые)', 'оптимальн(ый|ого|ые)', 'достаточн(ый|ое|о)',
      'при\\s+необходимости', 'и\\s+друг(ие|их)',
    ]
    const re = new RegExp(`(?<![а-яёa-z0-9])(${vague.join('|')})(?![а-яёa-z0-9])`, 'giu')
    const found = new Map<string, number>()
    const locations: FindingLocation[] = []
    for (const m of text.matchAll(re)) {
      const k = m[0].toLowerCase()
      found.set(k, (found.get(k) ?? 0) + 1)
      if (locations.length < MAX_LOCATIONS) locations.push(makeLocation(text, m.index, m[0]))
    }
    if (found.size === 0) {
      return [{ severity: 'info', title: 'Размытых формулировок не найдено', detail: 'Текст не содержит непроверяемых оборотов.' }]
    }
    const total = [...found.values()].reduce((a, b) => a + b, 0)
    const list = [...found.entries()].slice(0, 6).map(([w, n]) => `«${w}» ×${n}`).join(', ')
    return [{
      severity: total > 5 ? 'critical' : 'warning',
      title: `Размытые формулировки: ${total} шт.`,
      detail: `Найдены непроверяемые обороты: ${list}. Замените их на конкретные, измеримые требования. Нажмите на место ниже, чтобы перейти к нему в тексте.`,
      locations,
    }]
  },
})

registerPlugin({
  id: 'tbd-markers',
  name: 'Незакрытые вопросы',
  description: 'Метки TBD/TODO, «уточняется», «согласовывается» — признаки незавершённого ТЗ',
  run: (text) => {
    const re = /\b(tbd|todo|fixme|xxx)\b|уточня(ется|ют|ются)|согласовываетс[яю]|будет\s+определено|на\s+согласовании/giu
    const locations: FindingLocation[] = []
    let count = 0
    for (const m of text.matchAll(re)) {
      count++
      if (locations.length < MAX_LOCATIONS) locations.push(makeLocation(text, m.index, m[0]))
    }
    if (count === 0) return []
    return [{
      severity: 'critical',
      title: `Незакрытые вопросы: ${count}`,
      detail: 'В тексте есть метки TBD/TODO или формулировки «уточняется» / «согласовывается». ТЗ нельзя считать завершённым, пока они не закрыты. Нажмите на место ниже, чтобы перейти к нему в тексте.',
      locations,
    }]
  },
})

registerPlugin({
  id: 'structure',
  name: 'Структура документа',
  description: 'Оценивает структурированность: заголовки, нумерация, списки',
  run: (text) => {
    const lines = text.split('\n').filter((l) => l.trim())
    const headings = lines.filter((l) => /^\s*(\d+\.(\d+\.)*|[А-ЯЁA-Z][А-ЯЁA-Z\s]{4,}$)/.test(l.trim())).length
    const listItems = lines.filter((l) => /^\s*([—–\-•*]|\d+[.)])\s+/.test(l)).length
    const findings = []
    if (headings < 3) {
      findings.push({
        severity: 'warning' as const,
        title: 'Мало заголовков',
        detail: `Обнаружено заголовков: ${headings}. Разбейте документ на пронумерованные разделы — это обязательное требование к ТЗ.`,
      })
    }
    if (listItems < 5) {
      findings.push({
        severity: 'info' as const,
        title: 'Мало списков',
        detail: 'Требования удобнее проверять, когда они оформлены нумерованными списками, а не сплошным текстом.',
      })
    }
    return findings
  },
})

registerPlugin({
  id: 'volume',
  name: 'Объём документа',
  description: 'Проверяет, что документ достаточно детален для полноценного ТЗ',
  run: (text) => {
    const words = text.split(/\s+/).filter(Boolean).length
    if (words < 150) {
      return [{
        severity: 'critical' as const,
        title: 'Слишком короткий документ',
        detail: `Всего ${words} слов. Полноценное ТЗ обычно содержит не менее 500–1000 слов: такой объём вряд ли покрывает все требования.`,
      }]
    }
    if (words < 400) {
      return [{
        severity: 'warning' as const,
        title: 'Небольшой объём',
        detail: `${words} слов. Убедитесь, что документ покрывает все разделы, а не является краткой выжимкой.`,
      }]
    }
    return []
  },
})
