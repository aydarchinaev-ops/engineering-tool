import type {
  AnalysisReport,
  AnalyzerPlugin,
  CategoryResult,
  Checklist,
  CriterionResult,
  PluginFinding,
} from '@/types/analysis'

// ─── Ядро движка анализа ─────────────────────────────────────────────────────
// Движок не знает о конкретных критериях и плагинах: он принимает чек-лист
// и реестр плагинов извне. Это точка расширения — новые проверки добавляются
// данными (критерии в редакторе) или кодом (registerPlugin), без правок ядра.

function safeRegex(pattern: string): RegExp | null {
  try {
    return new RegExp(pattern, 'giu')
  } catch {
    return null
  }
}

function checkCriterion(
  text: string,
  criterion: Checklist['categories'][number]['criteria'][number],
): CriterionResult {
  if (!criterion.enabled) {
    return { criterion, passed: true, matches: [], matchCount: 0 }
  }
  const found = new Set<string>()
  for (const p of criterion.patterns) {
    const re = safeRegex(p)
    if (!re) continue
    for (const m of text.matchAll(re)) {
      if (m[0].trim()) found.add(m[0].trim().toLowerCase())
      if (found.size >= 10) break
    }
  }
  const need = Math.max(1, criterion.minMatches || 1)
  return {
    criterion,
    passed: found.size >= need,
    matches: [...found].slice(0, 3),
    matchCount: found.size,
  }
}

export function runAnalysis(
  rawText: string,
  checklist: Checklist,
  plugins: AnalyzerPlugin[],
  docTitle?: string,
): AnalysisReport {
  const text = rawText.replace(/\s+/g, ' ').trim()
  const words = text ? text.split(' ').length : 0

  const categoryResults: CategoryResult[] = checklist.categories.map((category) => {
    const results = category.criteria.map((c) => checkCriterion(text, c))
    const active = results.filter((r) => r.criterion.enabled)
    const totalWeight = active.reduce((s, r) => s + r.criterion.weight, 0)
    const earned = active.reduce((s, r) => s + (r.passed ? r.criterion.weight : 0), 0)
    const score = totalWeight === 0 ? 100 : Math.round((earned / totalWeight) * 100)
    return { category, results, score }
  })

  const allResults = categoryResults.flatMap((c) => c.results).filter((r) => r.criterion.enabled)
  const totalW = allResults.reduce((s, r) => s + r.criterion.weight, 0)
  const gotW = allResults.reduce((s, r) => s + (r.passed ? r.criterion.weight : 0), 0)
  const score = totalW === 0 ? 0 : Math.round((gotW / totalW) * 100)

  const pluginFindings: PluginFinding[] = plugins.flatMap((p) => {
    try {
      return p.run(rawText)
    } catch {
      return []
    }
  })

  const verdict: AnalysisReport['verdict'] =
    score >= 85 ? 'excellent' : score >= 65 ? 'good' : score >= 40 ? 'weak' : 'poor'

  return {
    id: crypto.randomUUID(),
    createdAt: Date.now(),
    docTitle:
      docTitle?.trim() ||
      text
        .split(' ')
        .filter((w) => !/^\d+[.)]?$/.test(w))
        .slice(0, 8)
        .join(' ') ||
      'Без названия',
    textLength: rawText.length,
    wordCount: words,
    score,
    verdict,
    sourceText: rawText,
    categoryResults,
    pluginFindings,
  }
}

// ─── Реестр плагинов ─────────────────────────────────────────────────────────
// Чтобы добавить собственный анализатор, вызовите registerPlugin({...})
// при инициализации приложения — он появится в отчёте автоматически.

const registry: AnalyzerPlugin[] = []

export function registerPlugin(plugin: AnalyzerPlugin): void {
  if (!registry.some((p) => p.id === plugin.id)) registry.push(plugin)
}

export function getPlugins(): AnalyzerPlugin[] {
  return [...registry]
}
