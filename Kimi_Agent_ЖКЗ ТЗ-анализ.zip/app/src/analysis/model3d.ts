// ─── Вывод параметров 3D-модели из данных предыдущих модулей ─────────────────
// Источники (localStorage):
//   design-basis-params-v1 — класс ЖК, подъезды, площади квартир (модуль «Проектные решения»)
//   design-basis-calc-v1   — площадь участка, пятно застройки, общая площадь, квартиры, парковка
//   sketch-chosen-v1       — выбранный заказчиком вариант эскиза
//
// Если данных нет — используются типовые допущения, каждое поле можно переопределить
// вручную в модуле «3D-модель» (переопределения хранятся в model3d-overrides-v1).

import { parseNum } from '@/analysis/verify'

export interface Model3DParams {
  // Участок
  siteArea: number // м²
  siteWidth: number // м (ось X)
  siteDepth: number // м (ось Z)
  // Здание
  footprintArea: number // пятно застройки, м²
  floors: number // надземных этажей
  floorHeight: number // м
  sections: number // подъездов / секций
  buildingLength: number // м (ось X)
  buildingWidth: number // м (ось Z, глубина корпуса)
  shape: 'bar' | 'l' // прямой корпус / Г-образный
  basement: boolean // подземный паркинг
  // Окружение
  parkingSpots: number
  trees: number
  // Мета
  housingClass: string
  flatsCount: number
  totalArea: number
  sketchVariant: string // выбранный вариант эскиза ('' если не выбран)
  source: string[] // пометки, откуда взято каждое значение
}

export interface Model3DOverrides {
  floors: string
  floorHeight: string
  sections: string
  buildingWidth: string
  shape: '' | 'bar' | 'l'
  basement: '' | 'yes' | 'no'
  parkingSpots: string
}

export const EMPTY_OVERRIDES: Model3DOverrides = {
  floors: '',
  floorHeight: '',
  sections: '',
  buildingWidth: '',
  shape: '',
  basement: '',
  parkingSpots: '',
}

function readJson<T>(key: string): Partial<T> {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as Partial<T>) : {}
  } catch {
    return {}
  }
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v))
}

/** Число из поля ввода; пустая строка → null (parseNum('') даёт 0) */
function numOr(v: string | undefined): number | null {
  if (!v || !v.trim()) return null
  return parseNum(v)
}

const CLASS_FLOOR_HEIGHT: Record<string, number> = {
  эконом: 2.8,
  комфорт: 3.0,
  бизнес: 3.2,
  элит: 3.4,
}

const CLASS_PARKING: Record<string, number> = {
  эконом: 0.7,
  комфорт: 1.0,
  бизнес: 1.5,
  элит: 2.0,
}

/**
 * Собирает параметры 3D-модели из данных предыдущих модулей
 * с учётом ручных переопределений пользователя.
 */
export function deriveModelParams(overrides: Model3DOverrides): Model3DParams {
  const basis = readJson<Record<string, string>>('design-basis-params-v1')
  const calc = readJson<Record<string, string>>('design-basis-calc-v1')
  let sketchVariant = ''
  try {
    sketchVariant = (JSON.parse(localStorage.getItem('sketch-chosen-v1') ?? '""') as string) ?? ''
  } catch {
    /* не выбран */
  }

  const source: string[] = []
  const clsRaw = (basis.housingClass ?? '').toLowerCase()
  const housingClass = clsRaw || 'комфорт'
  if (clsRaw) source.push('класс ЖК — из «Проектных решений»')

  // Участок
  let siteArea = numOr(calc.siteArea) ?? 9000
  if (calc.siteArea) source.push('площадь участка — из расчёта «Проектных решений»')
  siteArea = clamp(siteArea, 1500, 100000)
  // Пропорции участка ~1.6:1
  const siteWidth = Math.round(Math.sqrt(siteArea * 1.6))
  const siteDepth = Math.round(siteArea / siteWidth)

  // Пятно застройки и площадь
  let footprintArea = numOr(calc.footprintArea) ?? 0
  if (footprintArea > 0) source.push('пятно застройки — из расчёта «Проектных решений»')
  else footprintArea = Math.round(siteArea * 0.22)
  footprintArea = clamp(footprintArea, 150, siteArea * 0.6)

  const totalArea = numOr(calc.totalArea) ?? footprintArea * 9
  if (calc.totalArea) source.push('общая площадь — из расчёта «Проектных решений»')

  // Этажность
  let floors = numOr(overrides.floors) ?? Math.round(totalArea / footprintArea)
  floors = clamp(Math.round(floors), 2, 25)
  if (!overrides.floors && calc.totalArea && calc.footprintArea) {
    source.push('этажность — выведена из площади и пятна застройки')
  }

  // Высота этажа
  let floorHeight = numOr(overrides.floorHeight) ?? CLASS_FLOOR_HEIGHT[housingClass] ?? 3.0
  floorHeight = clamp(floorHeight, 2.5, 4.5)

  // Габариты корпуса
  let buildingWidth = numOr(overrides.buildingWidth) ?? (housingClass === 'эконом' ? 12 : 14)
  buildingWidth = clamp(buildingWidth, 9, 22)
  const shape: 'bar' | 'l' = overrides.shape || 'bar'
  let buildingLength = footprintArea / buildingWidth
  if (shape === 'l') buildingLength = buildingLength * 0.72 // Г-образный: два крыла по ~0.72L
  buildingLength = clamp(buildingLength, 14, Math.max(siteWidth - 16, 20))
  buildingLength = Math.round(buildingLength * 10) / 10

  // Секции (подъезды)
  let sections = numOr(overrides.sections) ?? numOr(basis.entrances) ?? 0
  if (sections <= 0) sections = clamp(Math.round(buildingLength / 28), 1, 12)
  else if (basis.entrances) source.push('подъезды — из «Проектных решений»')
  sections = clamp(Math.round(sections), 1, 16)

  // Подземный паркинг: по умолчанию для бизнес/элит
  let basement = housingClass === 'бизнес' || housingClass === 'элит'
  if (overrides.basement === 'yes') basement = true
  if (overrides.basement === 'no') basement = false

  // Парковка
  const flatsCount = numOr(calc.flatsCount) ?? Math.round(totalArea / 60)
  let parkingSpots =
    numOr(overrides.parkingSpots) ??
    numOr(calc.parkingActual) ??
    Math.ceil(flatsCount * (CLASS_PARKING[housingClass] ?? 1.0))
  parkingSpots = clamp(Math.round(parkingSpots), 0, 2000)
  if (calc.parkingActual && !overrides.parkingSpots) source.push('парковка — из расчёта «Проектных решений»')

  // Благоустройство: деревья по свободной площади
  const freeArea = siteArea - footprintArea - parkingSpots * 12.5
  const trees = clamp(Math.round(Math.max(freeArea, 0) / 250), 4, 80)

  return {
    siteArea,
    siteWidth,
    siteDepth,
    footprintArea: Math.round(buildingLength * buildingWidth * (shape === 'l' ? 1.35 : 1)),
    floors,
    floorHeight,
    sections,
    buildingLength,
    buildingWidth,
    shape,
    basement,
    parkingSpots,
    trees,
    housingClass,
    flatsCount,
    totalArea,
    sketchVariant,
    source,
  }
}

// ─── Компоновка на участке (единая для 3D-вида и IFC-экспорта) ──────────────

export interface Rect {
  x: number // центр, м (ось X — ширина участка)
  y: number // центр, м (ось Y — глубина участка, юг = +Y)
  w: number // по X, м
  d: number // по Y, м
}

export interface ModelLayout {
  site: Rect
  building: Rect
  wing: Rect | null // второе крыло для Г-образного корпуса
  entrances: { x: number; y: number }[]
  parking: Rect[]
  trees: { x: number; y: number }[]
}

/** Детерминированный генератор (чтобы 3D-вид и IFC совпадали) */
function lcg(seed: number): () => number {
  let s = seed >>> 0 || 1
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

function inside(r: Rect, x: number, y: number, margin: number): boolean {
  return Math.abs(x - r.x) < r.w / 2 + margin && Math.abs(y - r.y) < r.d / 2 + margin
}

export function computeLayout(p: Model3DParams): ModelLayout {
  const site: Rect = { x: 0, y: 0, w: p.siteWidth, d: p.siteDepth }

  // Корпус — в северной половине участка (юг отдаём под парковку и площадки)
  const by = -p.siteDepth / 2 + 8 + p.buildingWidth / 2 + p.siteDepth * 0.08
  const building: Rect = { x: 0, y: by, w: p.buildingLength, d: p.buildingWidth }

  // Г-образный: второе крыло на восточном торце, уходит на север
  let wing: Rect | null = null
  if (p.shape === 'l') {
    const wingD = Math.min(p.buildingLength * 0.55, p.siteDepth * 0.3)
    wing = {
      x: building.x + building.w / 2 - p.buildingWidth / 2,
      y: building.y - building.d / 2 - wingD / 2,
      w: p.buildingWidth,
      d: wingD,
    }
  }

  // Подъезды равномерно по южному фасаду
  const entrances: { x: number; y: number }[] = []
  for (let i = 0; i < p.sections; i++) {
    const t = p.sections === 1 ? 0.5 : i / (p.sections - 1)
    entrances.push({
      x: building.x - building.w / 2 + (wing ? building.w - p.buildingWidth : building.w) * t + (wing ? 0 : 0),
      y: building.y + building.d / 2,
    })
  }

  // Парковка — полосы вдоль южной границы, машиноместо 2.5×5.3 м
  const parking: Rect[] = []
  let left = p.parkingSpots
  const perRow = Math.max(4, Math.floor((p.siteWidth - 16) / 2.5))
  let row = 0
  while (left > 0 && row < 12) {
    const n = Math.min(left, perRow)
    parking.push({
      x: -p.siteWidth / 2 + 8 + (n * 2.5) / 2,
      y: p.siteDepth / 2 - 6 - row * 7.5,
      w: n * 2.5,
      d: 5.3,
    })
    left -= n
    row++
  }

  // Деревья на свободной территории
  const rnd = lcg(Math.round(p.siteArea) * 31 + p.floors * 7 + p.sections)
  const trees: { x: number; y: number }[] = []
  let guard = 0
  while (trees.length < p.trees && guard < p.trees * 30) {
    guard++
    const x = (rnd() - 0.5) * (p.siteWidth - 10)
    const y = (rnd() - 0.5) * (p.siteDepth - 10)
    if (inside(building, x, y, 4)) continue
    if (wing && inside(wing, x, y, 4)) continue
    if (parking.some((r) => inside(r, x, y, 3))) continue
    if (entrances.some((e) => Math.abs(e.x - x) < 4 && Math.abs(e.y - y) < 6)) continue
    trees.push({ x, y })
  }

  return { site, building, wing, entrances, parking, trees }
}

/** Краткая текстовая сводка модели (для подписи и экспорта) */
export function modelSummary(p: Model3DParams): string {
  const parts = [
    `${p.shape === 'l' ? 'Г-образный корпус' : 'Прямой корпус'} ${p.buildingLength}×${p.buildingWidth} м`,
    `${p.floors} эт. по ${p.floorHeight} м`,
    `секций: ${p.sections}`,
    `участок ${p.siteWidth}×${p.siteDepth} м`,
    `парковка: ${p.parkingSpots} м/м`,
  ]
  if (p.basement) parts.push('подземный паркинг')
  if (p.sketchVariant) parts.push(`эскиз: ${p.sketchVariant === 'v1' ? 'вариант 1' : 'вариант 2'}`)
  return parts.join(' · ')
}
