// ─── Экспорт массовой 3D-модели в IFC (IFC4, STEP ISO-10303-21) ──────────────
// Состав модели: участок → здание → этажи (плита + наружные стены),
// подземный этаж (паркинг), открытая парковка и деревья как элементы-прокси,
// набор свойств здания (класс ЖК, квартиры, площади).
// Это эскизная массовая модель для согласований, не заменяет BIM-модель стадии П/РД.

import { computeLayout, type Model3DParams, type Rect } from '@/analysis/model3d'

// ── Утилиты STEP ─────────────────────────────────────────────────────────────

/** Экранирование строки по ISO-10303-21 (кириллица — через \X2\) */
function stepStr(s: string): string {
  let out = ''
  let hex: string[] = []
  const flush = () => {
    if (hex.length) {
      out += `\\X2\\${hex.join('')}\\X0\\`
      hex = []
    }
  }
  for (const ch of s) {
    const code = ch.codePointAt(0) ?? 63
    if (code > 126 || code < 32) {
      if (code <= 0xffff) hex.push(code.toString(16).toUpperCase().padStart(4, '0'))
    } else {
      flush()
      out += ch === "'" ? "''" : ch
    }
  }
  flush()
  return `'${out}'`
}

function num(n: number): string {
  const r = Math.round(n * 1000) / 1000
  return Number.isInteger(r) ? `${r}.` : `${r}`
}

/** IFC GlobalId: 22 символа из 64-символьного алфавита, первый — 0..3 */
function guid(): string {
  const abc = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$'
  let g = '0123'[Math.floor(Math.random() * 4)]
  for (let i = 0; i < 21; i++) g += abc[Math.floor(Math.random() * 64)]
  return g
}

class Ifc {
  private lines: string[] = []
  private counter = 0
  add(body: string): number {
    this.counter++
    this.lines.push(`#${this.counter}=${body};`)
    return this.counter
  }
  point(x: number, y: number, z: number): number {
    return this.add(`IFCCARTESIANPOINT((${num(x)},${num(y)},${num(z)}))`)
  }
  axis3d(x = 0, y = 0, z = 0): number {
    return this.add(`IFCAXIS2PLACEMENT3D(#${this.point(x, y, z)},$,$)`)
  }
  placement(parent: number | null, x = 0, y = 0, z = 0): number {
    return this.add(`IFCLOCALPLACEMENT(${parent ? `#${parent}` : '$'},#${this.axis3d(x, y, z)})`)
  }
  /** Прямоугольный профиль (центр cx,cy), выдавленный на h по +Z от zOff.
   *  Возвращает IfcProductDefinitionShape — именно его ждёт атрибут Representation
   *  у IfcProduct; «голый» IfcShapeRepresentation вьюверы игнорируют. */
  solidBox(ctx: number, cx: number, cy: number, w: number, d: number, h: number, zOff: number): number {
    const p2d = this.add(`IFCCARTESIANPOINT((${num(cx)},${num(cy)}))`)
    const ax2d = this.add(`IFCAXIS2PLACEMENT2D(#${p2d},$)`)
    const prof = this.add(`IFCRECTANGLEPROFILEDEF(.AREA.,$,#${ax2d},${num(w)},${num(d)})`)
    const dir = this.add(`IFCDIRECTION((0.,0.,1.))`)
    const pos = this.axis3d(0, 0, zOff)
    const solid = this.add(`IFCEXTRUDEDAREASOLID(#${prof},#${pos},#${dir},${num(h)})`)
    const rep = this.add(`IFCSHAPEREPRESENTATION(#${ctx},'Body','SweptSolid',(#${solid}))`)
    return this.add(`IFCPRODUCTDEFINITIONSHAPE($,$,(#${rep}))`)
  }
  text(): string {
    return this.lines.join('\n')
  }
}

// ── Генерация IFC-файла ──────────────────────────────────────────────────────

export function generateIfc(p: Model3DParams, projectName: string): string {
  const L = computeLayout(p)
  const f = new Ifc()
  const H = p.floorHeight
  const wallT = 0.3
  const slabT = 0.22

  // Контекст и единицы
  const ctxOrigin = f.axis3d()
  const ctx = f.add(`IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#${ctxOrigin},$)`)
  const uLen = f.add(`IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.)`)
  const uArea = f.add(`IFCSIUNIT(*,.AREAUNIT.,$,.SQUARE_METRE.)`)
  const uVol = f.add(`IFCSIUNIT(*,.VOLUMEUNIT.,$,.CUBIC_METRE.)`)
  const uAng = f.add(`IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.)`)
  const units = f.add(`IFCUNITASSIGNMENT((#${uLen},#${uArea},#${uVol},#${uAng}))`)

  // Иерархия: проект → участок → здание
  const project = f.add(
    `IFCPROJECT('${guid()}',$,${stepStr(projectName)},${stepStr('Эскизная 3D-модель, сформирована модулем «Проектный офис»')},$,$,$,(#${ctx}),#${units})`,
  )
  const sitePl = f.placement(null)
  const site = f.add(
    `IFCSITE('${guid()}',$,${stepStr('Земельный участок')},$,$,#${sitePl},$,$,.ELEMENT.,$,$,$,$,$)`,
  )
  f.add(`IFCRELAGGREGATES('${guid()}',$,$,$,#${project},(#${site}))`)

  // Здание: начало координат — центр пятна застройки на уровне ±0.000
  const bldPl = f.placement(sitePl, L.building.x, L.building.y, 0)
  const bldName = `Жилой корпус, ${p.floors} эт., ${p.sections} секц.`
  const building = f.add(`IFCBUILDING('${guid()}',$,${stepStr(bldName)},$,$,#${bldPl},$,$,.ELEMENT.,$,$,$)`)
  f.add(`IFCRELAGGREGATES('${guid()}',$,$,$,#${site},(#${building}))`)

  // Прямоугольники корпуса (основной + крыло)
  const rects: Rect[] = [L.building]
  if (L.wing) {
    rects.push({ ...L.wing, x: L.wing.x - L.building.x, y: L.wing.y - L.building.y })
  }
  rects[0] = { ...rects[0], x: 0, y: 0 }

  const storeys: number[] = []

  const addStorey = (name: string, elev: number, withWalls: boolean): number => {
    const stPl = f.placement(bldPl, 0, 0, elev)
    const st = f.add(
      `IFCBUILDINGSTOREY('${guid()}',$,${stepStr(name)},$,$,#${stPl},$,$,.ELEMENT.,${num(elev)})`,
    )
    storeys.push(st)
    const elems: number[] = []
    for (const r of rects) {
      // Плита этажа
      const slabRep = f.solidBox(ctx, r.x, r.y, r.w, r.d, slabT, -slabT)
      const slabPl = f.placement(stPl)
      elems.push(f.add(`IFCSLAB('${guid()}',$,${stepStr(`${name}: перекрытие`)},$,$,#${slabPl},#${slabRep},$,.FLOOR.)`))
      if (withWalls) {
        // Наружные стены: 4 стороны прямоугольника
        const walls: { cx: number; cy: number; w: number; d: number }[] = [
          { cx: r.x, cy: r.y - r.d / 2 + wallT / 2, w: r.w, d: wallT },
          { cx: r.x, cy: r.y + r.d / 2 - wallT / 2, w: r.w, d: wallT },
          { cx: r.x - r.w / 2 + wallT / 2, cy: r.y, w: wallT, d: r.d - wallT * 2 },
          { cx: r.x + r.w / 2 - wallT / 2, cy: r.y, w: wallT, d: r.d - wallT * 2 },
        ]
        for (const wl of walls) {
          const rep = f.solidBox(ctx, wl.cx, wl.cy, wl.w, wl.d, H, 0)
          const pl = f.placement(stPl)
          elems.push(f.add(`IFCWALL('${guid()}',$,${stepStr(`${name}: наружная стена`)},$,$,#${pl},#${rep},$,$)`))
        }
      }
    }
    f.add(`IFCRELCONTAINEDINSPATIALSTRUCTURE('${guid()}',$,$,$,(${elems.map((e) => `#${e}`).join(',')}),#${st})`)
    return st
  }

  // Подземный этаж (паркинг)
  if (p.basement) addStorey('Этаж -1 (подземный паркинг)', -3.3, true)
  // Надземные этажи
  for (let i = 1; i <= p.floors; i++) addStorey(`Этаж ${i}`, Math.round((i - 1) * H * 100) / 100, true)
  f.add(`IFCRELAGGREGATES('${guid()}',$,$,$,#${building},(${storeys.map((s) => `#${s}`).join(',')}))`)

  // Свойства здания
  const props: number[] = []
  props.push(f.add(`IFCPROPERTYSINGLEVALUE(${stepStr('Класс ЖК')},$,IFCLABEL(${stepStr(p.housingClass)}),$)`))
  props.push(f.add(`IFCPROPERTYSINGLEVALUE(${stepStr('Количество квартир')},$,IFCINTEGER(${Math.round(p.flatsCount)}),$)`))
  props.push(f.add(`IFCPROPERTYSINGLEVALUE(${stepStr('Общая площадь, м2')},$,IFCREAL(${num(p.totalArea)}),$)`))
  props.push(f.add(`IFCPROPERTYSINGLEVALUE(${stepStr('Площадь застройки, м2')},$,IFCREAL(${num(p.footprintArea)}),$)`))
  props.push(f.add(`IFCPROPERTYSINGLEVALUE(${stepStr('Площадь участка, м2')},$,IFCREAL(${num(p.siteArea)}),$)`))
  props.push(f.add(`IFCPROPERTYSINGLEVALUE(${stepStr('Парковочных мест')},$,IFCINTEGER(${p.parkingSpots}),$)`))
  const pset = f.add(`IFCPROPERTYSET('${guid()}',$,${stepStr('Проектный офис: параметры')},$,(${props.map((x) => `#${x}`).join(',')}))`)
  f.add(`IFCRELDEFINESBYPROPERTIES('${guid()}',$,$,$,(#${building}),#${pset})`)

  // Открытая парковка и деревья — элементы-прокси на участке
  const siteElems: number[] = []
  L.parking.forEach((r, i) => {
    const rep = f.solidBox(ctx, r.x, r.y, r.w, r.d, 0.1, 0)
    const pl = f.placement(sitePl)
    siteElems.push(
      f.add(`IFCBUILDINGELEMENTPROXY('${guid()}',$,${stepStr(`Открытая парковка (полоса ${i + 1})`)},$,$,#${pl},#${rep},$,$)`),
    )
  })
  for (const t of L.trees) {
    const p2d = f.add(`IFCCARTESIANPOINT((0.,0.))`)
    const ax2d = f.add(`IFCAXIS2PLACEMENT2D(#${p2d},$)`)
    const prof = f.add(`IFCCIRCLEPROFILEDEF(.AREA.,$,#${ax2d},0.9)`)
    const dir = f.add(`IFCDIRECTION((0.,0.,1.))`)
    const pos = f.axis3d(0, 0, 0)
    const solid = f.add(`IFCEXTRUDEDAREASOLID(#${prof},#${pos},#${dir},4.)`)
    const rep = f.add(`IFCSHAPEREPRESENTATION(#${ctx},'Body','SweptSolid',(#${solid}))`)
    const shape = f.add(`IFCPRODUCTDEFINITIONSHAPE($,$,(#${rep}))`)
    const pl = f.placement(sitePl, t.x, t.y, 0)
    siteElems.push(f.add(`IFCBUILDINGELEMENTPROXY('${guid()}',$,${stepStr('Дерево')},$,$,#${pl},#${shape},$,$)`))
  }
  if (siteElems.length) {
    f.add(`IFCRELCONTAINEDINSPATIALSTRUCTURE('${guid()}',$,$,$,(${siteElems.map((e) => `#${e}`).join(',')}),#${site})`)
  }

  const now = new Date().toISOString().replace(/\.\d+Z$/, '')
  const fileName = `${projectName.replace(/[^\wа-яё-]+/gi, '_')}.ifc`
  return [
    'ISO-10303-21;',
    'HEADER;',
    `FILE_DESCRIPTION(('ViewDefinition [CoordinationView]'),'2;1');`,
    `FILE_NAME(${stepStr(fileName)},${stepStr(now)},(${stepStr('Проектный офис')}),(${stepStr('Проектный офис')}),${stepStr('Проектный офис — эскизная 3D-модель')},${stepStr('Проектный офис')},'');`,
    `FILE_SCHEMA(('IFC4'));`,
    'ENDSEC;',
    'DATA;',
    f.text(),
    'ENDSEC;',
    'END-ISO-10303-21;',
    '',
  ].join('\n')
}

/** Скачать IFC-файл в браузере */
export function downloadIfc(p: Model3DParams, projectName: string) {
  const content = generateIfc(p, projectName)
  const blob = new Blob([content], { type: 'application/x-step; charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${projectName.replace(/[^\wа-яё-]+/gi, '_')}.ifc`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}
