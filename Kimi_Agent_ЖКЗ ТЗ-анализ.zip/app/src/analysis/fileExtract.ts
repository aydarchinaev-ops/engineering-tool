// ─── Извлечение текста из файлов ─────────────────────────────────────────────
// Поддержка: .txt/.md (напрямую), .pdf (pdf.js), .docx (mammoth),
// .doc (легаси-бинарный формат — эвристическое извлечение с предупреждением).
// Всё выполняется локально в браузере, файлы никуда не отправляются.

// Тяжёлые парсеры загружаются лениво — только когда пользователь
// действительно загружает файл соответствующего формата.
let pdfjsReady: Promise<typeof import('pdfjs-dist')> | null = null

function getPdfjs() {
  if (!pdfjsReady) {
    pdfjsReady = Promise.all([
      import('pdfjs-dist'),
      import('pdfjs-dist/build/pdf.worker.min.mjs?url'),
    ]).then(([lib, worker]) => {
      lib.GlobalWorkerOptions.workerSrc = worker.default
      return lib
    })
  }
  return pdfjsReady
}

export interface ExtractResult {
  text: string
  /** Предупреждение, если извлечение приблизительное (например, старый .doc) */
  warning?: string
}

async function extractPdf(file: File): Promise<ExtractResult> {
  const pdfjsLib = await getPdfjs()
  const data = await file.arrayBuffer()
  const pdf = await pdfjsLib.getDocument({ data }).promise
  const parts: string[] = []
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i)
    const content = await page.getTextContent()
    parts.push(content.items.map((it) => ('str' in it ? it.str : '')).join(' '))
  }
  const text = parts.join('\n').replace(/[ \t]+/g, ' ').trim()
  if (!text) {
    throw new Error('Не удалось извлечь текст: похоже, это скан без текстового слоя. Используйте PDF с распознанным текстом.')
  }
  return { text }
}

async function extractDocx(file: File): Promise<ExtractResult> {
  const mammoth = (await import('mammoth')).default
  const arrayBuffer = await file.arrayBuffer()
  const result = await mammoth.extractRawText({ arrayBuffer })
  const text = result.value.trim()
  if (!text) throw new Error('Не удалось извлечь текст из DOCX-файла.')
  return { text }
}

// Старый бинарный .doc (OLE2) не имеет надёжных браузерных парсеров.
// Делаем best-effort: пробуем UTF-16LE и Windows-1251, выбираем вариант
// с большим количеством осмысленных (буквенных) фрагментов.
async function extractDoc(file: File): Promise<ExtractResult> {
  const buf = await file.arrayBuffer()

  const CYR = 'А-Яа-яЁёӘәІіҢңҒғҮүҰұҚқӨөҺһ'
  const decode = (encoding: string) => {
    const raw = new TextDecoder(encoding).decode(buf)
    // Вырезаем CJK и прочие нецелевые письменности (бинарный мусор OLE),
    // затем вытаскиваем «осмысленные» текстовые последовательности от 20 символов
    const cleaned = raw.replace(/[⺀-鿿ꥠ-꥿가-힯豈-﫿︰-﹏＀-￯]/gu, ' ')
    const re = new RegExp(
      `[A-Za-z${CYR}][A-Za-z${CYR}0-9 \\t.,;:!?()«»“”„‘’—–\\-–№%°/\\\\*+#=<>\\n]{20,}`,
      'g',
    )
    return (cleaned.match(re) ?? [])
      .map((s) => s.replace(/[ \t]+/g, ' ').trim())
      .filter((s) => new RegExp(`[A-Za-z${CYR}]{4}`).test(s))
      .join('\n')
  }

  const utf16 = decode('utf-16le')
  const cp1251 = decode('windows-1251')
  const score = (t: string) => (t.match(/[A-Za-zА-Яа-яЁё]/g) || []).length
  const text = score(utf16) >= score(cp1251) ? utf16 : cp1251

  if (text.length < 200) {
    throw new Error(
      'Формат .doc (Word 97–2003) не удалось прочитать. Сохраните документ как .docx или .pdf и загрузите снова.',
    )
  }
  return {
    text,
    warning: 'Формат .doc (Word 97–2003) прочитан приблизительно. Для точного анализа лучше загрузить .docx или .pdf.',
  }
}

function extractPlain(file: File): Promise<ExtractResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve({ text: String(reader.result ?? '') })
    reader.onerror = () => reject(new Error('Не удалось прочитать файл.'))
    reader.readAsText(file, 'utf-8')
  })
}

export async function extractTextFromFile(file: File): Promise<ExtractResult> {
  const ext = file.name.toLowerCase().split('.').pop() ?? ''
  switch (ext) {
    case 'pdf':
      return extractPdf(file)
    case 'docx':
      return extractDocx(file)
    case 'doc':
      return extractDoc(file)
    case 'txt':
    case 'md':
    case 'text':
      return extractPlain(file)
    default:
      throw new Error(`Неподдерживаемый формат «.${ext}». Загрузите PDF, DOCX, DOC, TXT или MD.`)
  }
}
