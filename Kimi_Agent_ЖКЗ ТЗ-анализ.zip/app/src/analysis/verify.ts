// ─── Автоматическая проверка приложенных файлов ─────────────────────────────
// Общие помощники для разделов «Исходные данные» и «Основные проектные решения».
// NB: \w и \b в JS не работают с кириллицей — используем [а-яё]+.

export interface VerifyConfig {
  /** Регулярные выражения — характерные признаки документа */
  patterns: string[]
  /** Сколько групп признаков должно найтись, чтобы файл считался соответствующим */
  minMatch: number
  /** Извлекать ФИО (для приказов и матриц) */
  extractPersons?: boolean
}

export interface Attachment {
  fileName: string
  status: 'match' | 'mismatch' | 'error'
  detail: string
  persons?: string[]
}

const PERSON_STOPWORDS = /^(Республика|Республики|Казахстан|Казахстана|Товарищество|Ограниченной|Ответственностью|Акционерное|Общество|Главный|Главного|Руководитель|Ответственный|Директор|Проект|Проекта)$/

export function extractPersons(text: string): string[] {
  const found = new Set<string>()
  // Фамилия И.О.
  for (const m of text.matchAll(/[А-ЯЁ][а-яё]+(?:-[А-ЯЁ][а-яё]+)?\s+[А-ЯЁ]\.\s?[А-ЯЁ]\./g)) {
    if (!PERSON_STOPWORDS.test(m[0].split(/\s+/)[0])) found.add(m[0])
  }
  // Фамилия Имя Отчество (отчество: -вич/-вна/-улы/-кызы и т.п.)
  for (const m of text.matchAll(/[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+/g)) {
    const parts = m[0].split(/\s+/)
    if (parts.some((w) => PERSON_STOPWORDS.test(w))) continue
    if (/(вич|вна|ыч|ична|овна|евна|улы|ұлы|кызы|қызы|уулу)$/i.test(parts[2])) found.add(m[0])
  }
  return [...found].slice(0, 5)
}

export function countMatches(text: string, patterns: string[]): number {
  return patterns.reduce((n, p) => {
    try {
      return new RegExp(p, 'iu').test(text) ? n + 1 : n
    } catch {
      return n
    }
  }, 0)
}

/** Проверка извлечённого текста файла по конфигу; возвращает карточку-результат */
export function verifyText(fileName: string, text: string, warning: string | undefined, cfg: VerifyConfig | undefined): Attachment {
  const warn = warning ? ` ${warning}` : ''
  if (!text.trim() || text.trim().length < 10) {
    return { fileName, status: 'error', detail: 'Не удалось извлечь текст — файл пустой или скан без текстового слоя' }
  }
  if (!cfg) {
    return { fileName, status: 'error', detail: 'Для этого пункта не заданы правила проверки' }
  }
  const hits = countMatches(text, cfg.patterns)
  const persons = cfg.extractPersons ? extractPersons(text) : []
  if (hits >= cfg.minMatch) {
    const personNote = persons.length > 0 ? ` Найдены: ${persons.join(', ')}` : ''
    return {
      fileName,
      status: 'match',
      detail: `Признаки подтверждены: ${hits} из ${cfg.patterns.length}.${personNote}${warn}`,
      persons: persons.length > 0 ? persons : undefined,
    }
  }
  const personNote = persons.length > 0 ? ` Найдены ФИО: ${persons.join(', ')}.` : ''
  return {
    fileName,
    status: 'mismatch',
    detail: `Характерные признаки документа не найдены — проверьте соответствие вручную.${personNote}${warn}`,
    persons: persons.length > 0 ? persons : undefined,
  }
}

/** Парсинг числа из поля ввода (пробелы, запятая) */
export function parseNum(v: string): number | null {
  const n = Number(v.replace(/[\s ]/g, '').replace(',', '.'))
  return Number.isFinite(n) && n >= 0 ? n : null
}
