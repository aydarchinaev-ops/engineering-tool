// ─── Модуль «3D-модель» ──────────────────────────────────────────────────────
// Массовая 3D-модель здания, автоматически собранная из данных предыдущих
// модулей («Проектные решения», выбранный вариант эскиза). Параметры можно
// скорректировать вручную. Экспорт — в IFC (IFC4) для BIM-инструментов.

import { Suspense, lazy, useEffect, useMemo, useState } from 'react'
import { useLocalStorage } from '@/hooks/useLocalStorage'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { RotateCcw, Download, Box, Layers, FileDown, Sparkles, Loader2 } from 'lucide-react'
import {
  deriveModelParams,
  modelSummary,
  EMPTY_OVERRIDES,
  type Model3DOverrides,
} from '@/analysis/model3d'
import { downloadIfc } from '@/analysis/ifcExport'
import { trpc } from '@/providers/trpc'
import { getPrompt, readExamples, withExample, PROMPTS_STORAGE_KEY } from '@/analysis/prompts'
import { buildProjectContext } from '@/sections/SketchSection'
import type { Model3DLayers } from '@/sections/Model3DViewport'

// three.js грузится отдельным чанком — только когда модуль открыт
const Viewport = lazy(() => import('@/sections/Model3DViewport'))

const SELECT_CLASS =
  'flex h-8 w-full rounded-md border border-input bg-background px-2 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring'

export default function Model3DSection() {
  const [overrides, setOverrides] = useLocalStorage<Model3DOverrides>('model3d-overrides-v1', EMPTY_OVERRIDES)
  const [layers, setLayers] = useState<Model3DLayers>({
    windows: true,
    parking: true,
    trees: true,
    basement: true,
    autorotate: false,
  })

  const params = useMemo(() => deriveModelParams(overrides), [overrides])

  // ── ИИ-заключение по модели (асинхронная задача, как в «Эскизном проекте») ──
  const [review, setReview] = useLocalStorage<{ text: string; at: number } | null>('model3d-review-v1', null)
  const [promptOverrides] = useLocalStorage<Record<string, string>>(PROMPTS_STORAGE_KEY, {})
  const startJob = trpc.ai.start.useMutation()
  const [jobId, setJobId] = useState<string | null>(null)
  const [reviewError, setReviewError] = useState<string | null>(null)
  const jobStatus = trpc.ai.status.useQuery(
    { id: jobId ?? '' },
    { enabled: !!jobId, refetchInterval: 2000, retry: false },
  )

  useEffect(() => {
    if (!jobId || !jobStatus.data) return
    const st = jobStatus.data
    if (st.state === 'done') {
      setReview({ text: (st.text ?? '').trim(), at: Date.now() })
      setJobId(null)
    } else if (st.state === 'error') {
      setReviewError(st.error ?? 'Ошибка генерации')
      setJobId(null)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobStatus.data, jobId])

  const generateReview = () => {
    setReviewError(null)
    const system = withExample(getPrompt('model3d-review', promptOverrides), readExamples()['model3d'])
    const ctx = buildProjectContext()
    const prompt = [
      'КОНТЕКСТ ПРОЕКТА (из предыдущих модулей):',
      ctx.text,
      '',
      'ПАРАМЕТРЫ 3D-МОДЕЛИ:',
      modelSummary(params),
      `Корпус: ${params.buildingLength}×${params.buildingWidth} м, форма: ${params.shape === 'l' ? 'Г-образный' : 'прямой'}, ` +
        `этажей: ${params.floors}, высота этажа: ${params.floorHeight} м, секций: ${params.sections}.`,
      `Участок: ${params.siteWidth}×${params.siteDepth} м (${params.siteArea} м²). Парковка: ${params.parkingSpots} м/м` +
        (params.basement ? ', плюс подземный паркинг.' : '.'),
      `Класс ЖК: ${params.housingClass}. Квартир: ${params.flatsCount}. Общая площадь: ${params.totalArea} м².`,
    ].join('\n')
    startJob.mutate(
      { system, prompt, maxTokens: 4000 },
      {
        onSuccess: (d) => setJobId(d.id),
        onError: (e) => setReviewError(e.message),
      },
    )
  }

  const setField = (k: keyof Model3DOverrides, v: string) =>
    setOverrides((o) => ({ ...o, [k]: v }))

  const hasOverrides = (Object.keys(EMPTY_OVERRIDES) as (keyof Model3DOverrides)[]).some(
    (k) => overrides[k] !== EMPTY_OVERRIDES[k],
  )

  return (
    <div className="space-y-4">
      {/* Сводка */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Box className="h-4 w-4" /> Параметры модели
          </CardTitle>
          <CardDescription>{modelSummary(params)}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {params.source.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">
              {params.source.map((s) => (
                <Badge key={s} variant="secondary" className="text-[11px] font-normal">
                  {s}
                </Badge>
              ))}
              {params.sketchVariant && (
                <Badge variant="secondary" className="text-[11px] font-normal">
                  выбранный вариант — из «Эскизного проекта»
                </Badge>
              )}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              Предыдущие модули не заполнены — используются типовые параметры. Заполните «Проектные
              решения», чтобы модель собиралась из данных проекта.
            </p>
          )}

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            <label className="space-y-1">
              <span className="block text-[11px] text-muted-foreground">Этажность</span>
              <Input value={overrides.floors} onChange={(e) => setField('floors', e.target.value)} placeholder={String(params.floors)} className="h-8 text-xs" />
            </label>
            <label className="space-y-1">
              <span className="block text-[11px] text-muted-foreground">Высота этажа, м</span>
              <Input value={overrides.floorHeight} onChange={(e) => setField('floorHeight', e.target.value)} placeholder={String(params.floorHeight)} className="h-8 text-xs" />
            </label>
            <label className="space-y-1">
              <span className="block text-[11px] text-muted-foreground">Секций (подъездов)</span>
              <Input value={overrides.sections} onChange={(e) => setField('sections', e.target.value)} placeholder={String(params.sections)} className="h-8 text-xs" />
            </label>
            <label className="space-y-1">
              <span className="block text-[11px] text-muted-foreground">Глубина корпуса, м</span>
              <Input value={overrides.buildingWidth} onChange={(e) => setField('buildingWidth', e.target.value)} placeholder={String(params.buildingWidth)} className="h-8 text-xs" />
            </label>
            <label className="space-y-1">
              <span className="block text-[11px] text-muted-foreground">Форма корпуса</span>
              <select value={overrides.shape} onChange={(e) => setField('shape', e.target.value)} className={SELECT_CLASS}>
                <option value="">Авто ({params.shape === 'l' ? 'Г-образный' : 'прямой'})</option>
                <option value="bar">Прямой</option>
                <option value="l">Г-образный</option>
              </select>
            </label>
            <label className="space-y-1">
              <span className="block text-[11px] text-muted-foreground">Подземный паркинг</span>
              <select value={overrides.basement} onChange={(e) => setField('basement', e.target.value)} className={SELECT_CLASS}>
                <option value="">Авто ({params.basement ? 'есть' : 'нет'})</option>
                <option value="yes">Есть</option>
                <option value="no">Нет</option>
              </select>
            </label>
          </div>

          {hasOverrides && (
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setOverrides(EMPTY_OVERRIDES)}>
              <RotateCcw className="mr-1 h-3.5 w-3.5" /> Сбросить к данным модулей
            </Button>
          )}
        </CardContent>
      </Card>

      {/* 3D-вид */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Layers className="h-4 w-4" /> Визуализация
            </CardTitle>
            <div className="flex flex-wrap items-center gap-3">
              {(
                [
                  ['windows', 'Окна'],
                  ['parking', 'Парковка'],
                  ['trees', 'Деревья'],
                  ['basement', 'Подземный этаж'],
                  ['autorotate', 'Вращение'],
                ] as [keyof Model3DLayers, string][]
              ).map(([k, label]) => (
                <label key={k} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Checkbox
                    checked={layers[k]}
                    disabled={k === 'basement' && !params.basement}
                    onCheckedChange={(v) => setLayers((l) => ({ ...l, [k]: v === true }))}
                  />
                  {label}
                </label>
              ))}
            </div>
          </div>
          <CardDescription>
            Вращение — мышью, масштаб — колесом. Объёмная схема для согласования концепции, не
            заменяет чертежи.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Suspense
            fallback={
              <div className="flex h-[560px] w-full items-center justify-center rounded-lg border bg-slate-100 text-sm text-muted-foreground">
                Загрузка 3D-движка…
              </div>
            }
          >
            <Viewport params={params} layers={layers} />
          </Suspense>
        </CardContent>
      </Card>

      {/* Экспорт IFC */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileDown className="h-4 w-4" /> Экспорт в IFC
          </CardTitle>
          <CardDescription>
            Файл IFC4 (ISO 10303-21): участок, корпус, этажи с плитами и наружными стенами,
            подземный паркинг, открытая парковка, озеленение и набор свойств здания (класс ЖК,
            квартиры, площади). Открывается в BIMvision, Solibri, Revit, ArchiCAD, Renga.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-3">
          <Button onClick={() => downloadIfc(params, 'ЖК эскизная модель')}>
            <Download className="mr-2 h-4 w-4" /> Скачать .ifc
          </Button>
          <p className="text-xs text-muted-foreground">
            Эскизная массовая модель: без внутренних перегородок, инженерии и узлов — для
            согласования объёмно-планировочной концепции.
          </p>
        </CardContent>
      </Card>

      {/* ИИ-заключение */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-4 w-4" /> ИИ-заключение по модели
            </CardTitle>
            <Button variant="outline" size="sm" onClick={generateReview} disabled={!!jobId}>
              {jobId ? (
                <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />
              ) : (
                <Sparkles className="mr-2 h-3.5 w-3.5" />
              )}
              {jobId ? 'Генерация…' : review ? 'Обновить заключение' : 'Получить заключение'}
            </Button>
          </div>
          <CardDescription>
            Экспертная оценка концепции по параметрам модели и данным предыдущих модулей.
            Промпт и пример заключения настраиваются в настройках.
          </CardDescription>
        </CardHeader>
        {(review || reviewError || jobId) && (
          <CardContent>
            {jobId && (
              <p className="text-sm text-muted-foreground">Формируется заключение… может занять до минуты.</p>
            )}
            {reviewError && <p className="text-sm text-destructive">{reviewError}</p>}
            {review && !jobId && (
              <div className="space-y-1">
                <p className="text-[11px] text-muted-foreground">
                  Сформировано {new Date(review.at).toLocaleString('ru-RU')}
                </p>
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{review.text}</p>
              </div>
            )}
          </CardContent>
        )}
      </Card>
    </div>
  )
}
