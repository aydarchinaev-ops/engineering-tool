import { useMemo, useRef, useState } from 'react'
import { useLocalStorage } from '@/hooks/useLocalStorage'
import { extractTextFromFile } from '@/analysis/fileExtract'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import {
  RotateCcw,
  ClipboardList,
  Check,
  Copy,
  Paperclip,
  FileText,
  X,
  Loader2,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react'

// ─── Чек-лист комплектности исходных данных для проектирования ───────────────
// Три группы: данные к ТЗ, назначения заказчика, действия генпроектировщика.
// Документы и действия принимают файл (txt/pdf/doc/docx) с автопроверкой
// содержимого; назначения заполняются контактными полями (ФИО, должность,
// телефон, почта) — при заполнении обязательных полей пункт отмечается сам.

interface ChecklistItem {
  id: string
  label: string
  hint?: string
  /** Метка области применения, напр. «для жилья» */
  tag?: string
}

interface ChecklistGroup {
  id: string
  title: string
  description: string
  items: ChecklistItem[]
}

interface VerifyConfig {
  /** Регулярные выражения — характерные признаки документа */
  patterns: string[]
  /** Сколько групп признаков должно найтись, чтобы файл считался соответствующим */
  minMatch: number
  /** Извлекать ФИО (для приказов и матриц) */
  extractPersons?: boolean
}

interface Attachment {
  fileName: string
  status: 'match' | 'mismatch' | 'error'
  detail: string
  persons?: string[]
}

/** Контакт назначенного лица */
interface ContactInfo {
  name: string
  position: string
  phone: string
  email: string
}

const EMPTY_CONTACT: ContactInfo = { name: '', position: '', phone: '', email: '' }

/** Пункты, которые заполняются контактными полями вместо загрузки файла */
const CONTACT_ITEMS = new Set(['pm', 'arch-approver', 'tech-approver', 'budget-owner', 'correspondence'])

const GROUPS: ChecklistGroup[] = [
  {
    id: 'tz-data',
    title: 'Исходные данные, прилагаемые к ТЗ',
    description: 'Документы и сведения, которые заказчик передаёт проектировщику вместе с заданием',
    items: [
      { id: 'apz', label: 'АПЗ (архитектурно-планировочное задание)', hint: 'С реквизитами и сроком действия' },
      { id: 'land-docs', label: 'Документы на земельный участок', hint: 'Госакт, кадастровый номер, границы' },
      { id: 'topo', label: 'Топографическая съёмка 1:500', hint: 'Актуальность — не старше 2 лет' },
      { id: 'geology', label: 'Отчёт по инженерной геологии', hint: 'Включая сейсмическое микрорайонирование для сейсмических зон' },
      { id: 'tech-conditions', label: 'Технические условия на все инженерные сети', hint: 'Вода, канализация, тепло, электричество, связь' },
      { id: 'restrictions', label: 'Сведения об ограничениях участка', hint: 'Охранные зоны, сервитуты, ЗОУИТ' },
      { id: 'budget', label: 'Предполагаемый бюджет строительства' },
      { id: 'housing-class', label: 'Требования к классу жилья и отделке', tag: 'для жилья' },
      { id: 'flat-mix', label: 'Требования к составу квартир', hint: 'Квартирография, доли 1/2/3-комнатных', tag: 'для жилья' },
      { id: 'operator-req', label: 'Требования эксплуатирующей / управляющей организации' },
      { id: 'neighbors', label: 'Сведения о соседних зданиях и сетях', hint: 'Существующая застройка и коммуникации вокруг участка' },
    ],
  },
  {
    id: 'customer-roles',
    title: 'Назначения со стороны заказчика',
    description: 'Ответственные лица: укажите ФИО и должность — телефон и почта желательны для связи',
    items: [
      { id: 'pm', label: 'Руководитель проекта' },
      { id: 'arch-approver', label: 'Лицо, согласующее архитектуру' },
      { id: 'tech-approver', label: 'Лицо, согласующее технические решения' },
      { id: 'budget-owner', label: 'Ответственный за бюджет' },
      { id: 'correspondence', label: 'Ответственный за официальную переписку' },
    ],
  },
  {
    id: 'designer-actions',
    title: 'Действия генпроектировщика',
    description: 'Организационные шаги проектной организации на старте',
    items: [
      { id: 'gip', label: 'Назначен главный инженер проекта (ГИП)' },
      { id: 'team', label: 'Сформирована проектная команда' },
      { id: 'data-check', label: 'Проверены полнота и актуальность исходных данных' },
      { id: 'apz-compliance', label: 'Проверено соответствие параметров ТЗ требованиям АПЗ, ПДП и ограничениям участка' },
      { id: 'missing-list', label: 'Составлен перечень недостающей информации' },
      { id: 'schedule', label: 'Разработан календарный график проектирования' },
      { id: 'responsibility-matrix', label: 'Сформирована матрица ответственности' },
      { id: 'risk-register', label: 'Открыт реестр проектных рисков и вопросов' },
    ],
  },
]

// ─── Правила автоматической проверки файлов ──────────────────────────────────
// NB: \w и \b в JS не работают с кириллицей — используем [а-яё]+.

export const VERIFY: Record<string, VerifyConfig> = {
  // Исходные данные к ТЗ
  apz: {
    patterns: ['архитектурно-планировочн', 'АПЗ', 'планировочн[а-яё]+\\s+(задани|отметк)|красн[а-яё]+\\s+лини|этажност'],
    minMatch: 1,
  },
  'land-docs': {
    patterns: ['кадастров', 'земельн[а-яё]+\\s+участок', 'правоустанавливающ|государственн[а-яё]+\\s+акт|идентификационн[а-яё]+\\s+код'],
    minMatch: 2,
  },
  topo: {
    patterns: ['топографическ', '1\\s*:\\s*500', 'геодезическ|съ[её]мк|масштаб'],
    minMatch: 2,
  },
  geology: {
    patterns: ['инженерн[а-яё-]*геологическ|геологическ[а-яё]+\\s+изыскан', 'скважин|грунт|разрез|отч[её]т', 'сейсмическ[а-яё]+\\s+микрорайонирован|СМР'],
    minMatch: 2,
  },
  'tech-conditions': {
    patterns: ['техническ[а-яё]+\\s+услови', 'присоединени|подключени|точк[аи]\\s+подключени|выделени[ея]\\s+мощност'],
    minMatch: 1,
  },
  restrictions: {
    patterns: ['ограничен|обременен|сервитут|охранн[а-яё]+\\s+зон|ЗОУИТ|зон[аы]\\s+санитарн'],
    minMatch: 1,
  },
  budget: {
    patterns: ['бюджет|стоимост[ьи]\\s+строительств|инвестици', 'тенге|млн|млрд|USD|\\$'],
    minMatch: 1,
  },
  'housing-class': {
    patterns: ['класс\\s+(жилья|дома|объекта)|комфорт[-\\s]класс|бизнес[-\\s]класс|эконом[-\\s]класс|элитн', 'отделк|под\\s+чистов|white\\s*box'],
    minMatch: 1,
  },
  'flat-mix': {
    patterns: ['квартир', 'однокомнатн|двухкомнатн|тр[её]хкомнатн|[123]-комн|квартирограф|количеств[оа]\\s+комнат'],
    minMatch: 1,
  },
  'operator-req': {
    patterns: ['эксплуатирующ|управляющ[а-яё]+\\s+(компани|организац)|КСК|домоуправлен', 'требовани|регламент|эксплуатац'],
    minMatch: 1,
  },
  neighbors: {
    patterns: ['соседн[а-яё]+\\s+(здани|дом|объект|застройк)|существующ[а-яё]+\\s+(застройк|здани|сети|коммуникац)|окружающ[а-яё]+\\s+застройк'],
    minMatch: 1,
  },
  // Действия генпроектировщика
  gip: {
    patterns: ['ГИП|главн[а-яё]+\\s+инженер\\s+проект'],
    minMatch: 1,
    extractPersons: true,
  },
  team: {
    patterns: ['проектн[а-яё]+\\s+команд|состав\\s+команды|рабоч[а-яё]+\\s+групп'],
    minMatch: 1,
    extractPersons: true,
  },
  'data-check': {
    patterns: ['провер[а-яё]+\\s+(полнот|актуальност)|полнот[аы]\\s+и\\s+актуальност|актуальност[ьи]\\s+исходн'],
    minMatch: 1,
  },
  'apz-compliance': {
    patterns: ['соответстви[а-яё]+\\s+(параметр|требован|АПЗ|ПДП)|АПЗ[а-яё,\\s]+ПДП|ПДП[а-яё,\\s]+АПЗ'],
    minMatch: 1,
  },
  'missing-list': {
    patterns: ['перечен[ьи]\\s+недостающ|недостающ[а-яё]+\\s+(информац|данн|документ)|запрос[аы]?\\s+недостающ'],
    minMatch: 1,
  },
  schedule: {
    patterns: ['календарн[а-яё]+\\s+график|график\\s+(проектирования|выполнени|работ)'],
    minMatch: 1,
  },
  'responsibility-matrix': {
    patterns: ['матриц[аы]\\s+ответственност|ответственност[ьи]\\s+за\\s+раздел'],
    minMatch: 1,
    extractPersons: true,
  },
  'risk-register': {
    patterns: ['реестр\\s+(рисков|вопросов)|проектн[а-яё]+\\s+риск|журнал\\s+(рисков|вопросов)'],
    minMatch: 1,
  },
}

// ─── Извлечение ФИО из текста ────────────────────────────────────────────────

const PERSON_STOPWORDS = /^(Республика|Республики|Казахстан|Казахстана|Товарищество|Ограниченной|Ответственностью|Акционерное|Общество|Главный|Главного|Руководитель|Ответственный|Директор|Проект|Проекта)$/

export function extractPersons(text: string): string[] {
  const found = new Set<string>()
  // Фамилия И.О.
  for (const m of text.matchAll(/[А-ЯЁ][а-яё]+(?:-[А-ЯЁ][а-яё]+)?\s+[А-ЯЁ]\.\s?[А-ЯЁ]\./g)) {
    if (!PERSON_STOPWORDS.test(m[0].split(/\s+/)[0])) found.add(m[0])
  }
  // Фамилия Имя Отчество (отчество: -вич/-вна/-улы/-кызы и т.п.)
  for (const m of text.matchAll(/[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+/g)) {
    const parts = m[0].split(/\s+/)
    if (parts.some((w) => PERSON_STOPWORDS.test(w))) continue
    if (/(вич|вна|ыч|ична|овна|евна|улы|ұлы|кызы|қызы|уулу)$/i.test(parts[2])) found.add(m[0])
  }
  return [...found].slice(0, 5)
}

export function countMatches(text: string, patterns: string[]): number {
  return patterns.reduce((n, p) => {
    try {
      return new RegExp(p, 'iu').test(text) ? n + 1 : n
    } catch {
      return n
    }
  }, 0)
}

// ─── Валидация контактных полей ──────────────────────────────────────────────

export function isValidEmail(v: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim())
}

export function isValidPhone(v: string): boolean {
  const digits = v.replace(/\D/g, '')
  return digits.length >= 10 && digits.length <= 15 && /^[+]?[\d\s()—-]+$/.test(v.trim())
}

/** Контакт считается заполненным, когда указаны ФИО и должность */
export function isContactComplete(c: ContactInfo): boolean {
  return c.name.trim().length > 1 && c.position.trim().length > 1
}

// ─── Компонент ───────────────────────────────────────────────────────────────

export default function InputDataChecklist() {
  const [checked, setChecked] = useLocalStorage<Record<string, boolean>>('input-data-v1', {})
  const [attachments, setAttachments] = useLocalStorage<Record<string, Attachment>>('input-data-files-v1', {})
  const [contacts, setContacts] = useLocalStorage<Record<string, ContactInfo>>('input-data-contacts-v1', {})
  const [copied, setCopied] = useState(false)
  const [showMissing, setShowMissing] = useState(false)
  const [busyItem, setBusyItem] = useState<string | null>(null)
  const [uploadTarget, setUploadTarget] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const total = GROUPS.reduce((s, g) => s + g.items.length, 0)
  const done = GROUPS.reduce((s, g) => s + g.items.filter((i) => checked[i.id]).length, 0)
  const verified = Object.values(attachments).filter((a) => a.status === 'match').length
  const percent = Math.round((done / total) * 100)

  const missing = useMemo(
    () =>
      GROUPS.map((g) => ({
        group: g,
        items: g.items.filter((i) => !checked[i.id]),
      })).filter((g) => g.items.length > 0),
    [checked],
  )

  const missingText = missing
    .map((g) => `${g.group.title}:\n${g.items.map((i) => `— ${i.label}`).join('\n')}`)
    .join('\n\n')

  const copyMissing = async () => {
    await navigator.clipboard.writeText(`ПЕРЕЧЕНЬ НЕДОСТАЮЩИХ ДАННЫХ И ДЕЙСТВИЙ\n\n${missingText}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const updateContact = (itemId: string, field: keyof ContactInfo, value: string) => {
    const next: ContactInfo = { ...EMPTY_CONTACT, ...contacts[itemId], [field]: value }
    setContacts((c) => ({ ...c, [itemId]: next }))
    // Пункт отмечается автоматически, когда заполнены ФИО и должность
    setChecked((c) => ({ ...c, [itemId]: isContactComplete(next) }))
  }

  const startUpload = (itemId: string) => {
    setUploadTarget(itemId)
    // сбрасываем value, чтобы повторный выбор того же файла тоже сработал
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
      fileInputRef.current.click()
    }
  }

  const removeAttachment = (itemId: string) => {
    setAttachments((a) => {
      const next = { ...a }
      delete next[itemId]
      return next
    })
    setChecked((c) => ({ ...c, [itemId]: false }))
  }

  const handleFile = async (file: File | undefined) => {
    const itemId = uploadTarget
    if (!file || !itemId) return
    const cfg = VERIFY[itemId]
    setBusyItem(itemId)
    try {
      const result = await extractTextFromFile(file)
      const text = result.text
      if (!text.trim() || text.trim().length < 10) {
        setAttachments((a) => ({
          ...a,
          [itemId]: { fileName: file.name, status: 'error', detail: 'Не удалось извлечь текст — файл пустой или скан без текстового слоя' },
        }))
        return
      }
      const hits = cfg ? countMatches(text, cfg.patterns) : 0
      const persons = cfg?.extractPersons ? extractPersons(text) : []
      const warn = result.warning ? ` ${result.warning}` : ''
      if (cfg && hits >= cfg.minMatch) {
        const personNote = persons.length > 0 ? ` Найдены: ${persons.join(', ')}` : ''
        setAttachments((a) => ({
          ...a,
          [itemId]: {
            fileName: file.name,
            status: 'match',
            detail: `Признаки подтверждены: ${hits} из ${cfg.patterns.length}.${personNote}${warn}`,
            persons: persons.length > 0 ? persons : undefined,
          },
        }))
        // автоматически отмечаем пункт
        setChecked((c) => ({ ...c, [itemId]: true }))
      } else {
        const personNote = persons.length > 0 ? ` Найдены ФИО: ${persons.join(', ')}.` : ''
        setAttachments((a) => ({
          ...a,
          [itemId]: {
            fileName: file.name,
            status: 'mismatch',
            detail: `Характерные признаки документа не найдены — проверьте соответствие вручную.${personNote}${warn}`,
            persons: persons.length > 0 ? persons : undefined,
          },
        }))
      }
    } catch (e) {
      setAttachments((a) => ({
        ...a,
        [itemId]: {
          fileName: file.name,
          status: 'error',
          detail: e instanceof Error ? e.message : 'Ошибка чтения файла',
        },
      }))
    } finally {
      setBusyItem(null)
    }
  }

  const resetAll = () => {
    if (!confirm('Сбросить все отметки, приложенные файлы и контакты?')) return
    setChecked({})
    setAttachments({})
    setContacts({})
  }

  return (
    <div className="space-y-6">
      {/* Скрытый input для загрузки файлов */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".txt,.md,.text,.pdf,.doc,.docx"
        className="hidden"
        onChange={(e) => void handleFile(e.target.files?.[0])}
      />

      {/* Сводка */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Общая готовность к старту проектирования</span>
              <span className="tabular-nums text-muted-foreground">
                {done} из {total} · {percent}%
              </span>
            </div>
            <Progress value={percent} className="h-2" />
            <p className="text-xs text-muted-foreground">
              Документы прикрепляются файлом (скрепка) — содержимое проверяется автоматически.
              Для назначений заполните ФИО и должность — пункт отметится сам. Проверено файлами: {verified}.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowMissing((v) => !v)} disabled={missing.length === 0}>
              <ClipboardList className="mr-2 h-4 w-4" />
              {showMissing ? 'Скрыть перечень' : `Недостаёт: ${total - done}`}
            </Button>
            <Button variant="ghost" size="sm" onClick={resetAll}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Сбросить
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Перечень недостающего */}
      {showMissing && missing.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Перечень недостающих данных и действий</CardTitle>
            <CardDescription>Готовый текст для запроса заказчику или включения в протокол</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea readOnly value={missingText} className="min-h-[200px] font-mono text-xs leading-relaxed" />
            <Button variant="outline" size="sm" onClick={copyMissing}>
              {copied ? <Check className="mr-2 h-4 w-4 text-emerald-600" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? 'Скопировано' : 'Копировать перечень'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Группы чек-листа */}
      {GROUPS.map((group) => {
        const groupDone = group.items.filter((i) => checked[i.id]).length
        return (
          <Card key={group.id}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <CardTitle className="text-base">{group.title}</CardTitle>
                  <CardDescription>{group.description}</CardDescription>
                </div>
                <Badge variant="secondary" className="shrink-0 tabular-nums">
                  {groupDone}/{group.items.length}
                </Badge>
              </div>
              <Progress value={(groupDone / group.items.length) * 100} className="mt-2 h-1.5" />
            </CardHeader>
            <CardContent className="space-y-1">
              {group.items.map((item) => {
                const att = attachments[item.id]
                const isBusy = busyItem === item.id
                const isContact = CONTACT_ITEMS.has(item.id)
                const contact: ContactInfo = { ...EMPTY_CONTACT, ...contacts[item.id] }
                return (
                  <div
                    key={item.id}
                    className="rounded-md px-2 py-2 transition-colors hover:bg-muted/50"
                  >
                    <div className="flex items-start gap-3">
                      <Checkbox
                        className="mt-0.5"
                        checked={!!checked[item.id]}
                        onCheckedChange={(v) => setChecked((c) => ({ ...c, [item.id]: v === true }))}
                      />
                      <div className="flex-1">
                        <span className={`text-sm ${checked[item.id] ? 'text-muted-foreground line-through' : ''}`}>
                          {item.label}
                        </span>
                        {item.tag && (
                          <Badge variant="outline" className="ml-2 align-middle text-[10px] font-normal">
                            {item.tag}
                          </Badge>
                        )}
                        {item.hint && <span className="block text-xs text-muted-foreground">{item.hint}</span>}

                        {/* Контактные поля для назначений */}
                        {isContact && (
                          <div className="mt-2 space-y-1.5">
                            <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                              <Input
                                value={contact.name}
                                onChange={(e) => updateContact(item.id, 'name', e.target.value)}
                                placeholder="ФИО *"
                                className="h-8 text-xs"
                              />
                              <Input
                                value={contact.position}
                                onChange={(e) => updateContact(item.id, 'position', e.target.value)}
                                placeholder="Должность *"
                                className="h-8 text-xs"
                              />
                              <div>
                                <Input
                                  value={contact.phone}
                                  onChange={(e) => updateContact(item.id, 'phone', e.target.value)}
                                  placeholder="Телефон"
                                  type="tel"
                                  className={`h-8 text-xs ${contact.phone && !isValidPhone(contact.phone) ? 'border-amber-400' : ''}`}
                                />
                                {contact.phone && !isValidPhone(contact.phone) && (
                                  <span className="mt-0.5 block text-[11px] text-amber-600">
                                    Проверьте номер: ожидается формат +7 7XX XXX-XX-XX
                                  </span>
                                )}
                              </div>
                              <div>
                                <Input
                                  value={contact.email}
                                  onChange={(e) => updateContact(item.id, 'email', e.target.value)}
                                  placeholder="Электронная почта"
                                  type="email"
                                  className={`h-8 text-xs ${contact.email && !isValidEmail(contact.email) ? 'border-amber-400' : ''}`}
                                />
                                {contact.email && !isValidEmail(contact.email) && (
                                  <span className="mt-0.5 block text-[11px] text-amber-600">
                                    Похоже, в адресе ошибка
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Карточка приложенного файла */}
                        {att && (
                          <div
                            className={`mt-1.5 flex items-start gap-2 rounded-md border px-2.5 py-1.5 text-xs ${
                              att.status === 'match'
                                ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/40'
                                : att.status === 'mismatch'
                                  ? 'border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40'
                                  : 'border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/40'
                            }`}
                          >
                            {att.status === 'match' ? (
                              <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                            ) : (
                              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
                            )}
                            <div className="flex-1">
                              <span className="inline-flex items-center gap-1 font-medium">
                                <FileText className="h-3 w-3" />
                                {att.fileName}
                              </span>
                              <span className="block text-muted-foreground">{att.detail}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeAttachment(item.id)}
                              className="mt-0.5 shrink-0 text-muted-foreground hover:text-foreground"
                              title="Удалить файл"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Кнопка загрузки файла — только для документов и действий */}
                      {!isContact && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 shrink-0 p-0"
                          disabled={isBusy}
                          onClick={() => startUpload(item.id)}
                          title={att ? 'Заменить файл' : 'Прикрепить файл для автоматической проверки'}
                        >
                          {isBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Paperclip className="h-4 w-4" />}
                        </Button>
                      )}
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
