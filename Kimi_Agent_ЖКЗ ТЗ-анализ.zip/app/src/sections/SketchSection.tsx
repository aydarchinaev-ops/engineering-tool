import { useEffect, useMemo, useState } from 'react'
import { useLocalStorage } from '@/hooks/useLocalStorage'
import { getPrompt, PROMPTS_STORAGE_KEY, readExamples, withExample } from '@/analysis/prompts'
import { trpc } from '@/providers/trpc'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  RotateCcw,
  ClipboardList,
  Check,
  Copy,
  Sparkles,
  Eye,
  Info,
  Loader2,
} from 'lucide-react'

// ─── Эскизный проект ─────────────────────────────────────────────────────────
// Два варианта концепции минимум. Разделы проектировщика генерируются LLM
// с использованием данных предыдущих модулей (ТЗ, исходные данные, Basis of
// Design); визуализация каждого раздела открывается в отдельном окне.

export interface SketchSectionDef {
  id: string
  title: string
  /** Что именно просим сгенерировать у LLM */
  task: string
}

export const SKETCH_SECTIONS: SketchSectionDef[] = [
  { id: 'situational', title: 'Ситуационный план', task: 'Ситуационный план участка: окружающая застройка, улицы, ориентация по сторонам света, существующие сети.' },
  { id: 'placement', title: 'Посадка здания на участок', task: 'Посадка здания: положение на участке, отступы от границ и красных линий, ориентация фасадов.' },
  { id: 'entry-exit', title: 'Схема въезда и выезда', task: 'Схема въезда и выезда на участок: точки с улиц, разъезды, карманы, пешеходные входы.' },
  { id: 'fire-access', title: 'Проезды пожарной техники', task: 'Проезды пожарной техники: кольцевой или с двух сторон, ширина 4,2 м+, радиусы, площадки разворота, расстояние до фасада 5–8 м.' },
  { id: 'parking-scheme', title: 'Схема парковки', task: 'Схема наземной парковки: количество мест (из контекста), гостевые, м/м для МГН (10%, не менее 1), размещение по периметру.' },
  { id: 'parking-underground', title: 'Планы подземного паркинга', task: 'План подземного паркинга: габариты, сетка колонн 8,1×8,1 м, ramps, места, выделение зон для ИТП/насосной.' },
  { id: 'typical-floor', title: 'Планы типовых этажей', task: 'План типового этажа: квартирография из контекста, секции, лестнично-лифтовые узлы, диафрагмы жёсткости.' },
  { id: 'first-last-floor', title: 'Планы первого и верхнего этажей', task: 'Планы первого этажа (входные группы, встроенные помещения, МГН) и верхнего этажа (террасы/техэтаж).' },
  { id: 'sections', title: 'Разрезы', task: 'Продольный и поперечный разрезы: высоты этажей (3,0–3,3 м по классу), подземная часть, кровля, отметки.' },
  { id: 'facades', title: 'Фасады', task: 'Главный и дворовый фасады: композиция, материалы по типу фасада из контекста, ритм балконов/лоджий.' },
  { id: 'appearance', title: 'Внешний вид здания', task: 'Архитектурная концепция внешнего вида: силуэт, колористика, материалы, акценты первого этажа.' },
  { id: 'landscaping', title: 'Предварительное благоустройство', task: 'Концепция благоустройства: зонирование двора, детские/спортивные площадки, озеленение, МАФ, освещение.' },
  { id: 'structure-scheme', title: 'Предварительная конструктивная схема', task: 'Конструктивная схема для сейсмики 9 баллов: монолитный ж/б каркас, диафрагмы и ядра жёсткости, свайный фундамент, шаг колонн.' },
  { id: 'eng-rooms', title: 'Размещение инженерных помещений', task: 'Размещение инженерных помещений: ИТП, насосная, электрощитовые, венткамеры паркинга, шахты дымоудаления, водомерный узел, связь, стояки.' },
  { id: 'tep', title: 'Предварительные ТЭП', task: 'Предварительные технико-экономические показатели: площадь участка, застройки, общая/жилая/нежилая площадь, квартиры, парковка, КПЗ — по данным контекста.' },
  { id: 'insolation', title: 'Предварительный расчёт инсоляции', task: 'Предварительная оценка инсоляции: ориентация квартир, доля помещений с нормируемой инсоляцией, меры при дефиците.' },
  { id: 'cost', title: 'Предварительная оценка стоимости', task: 'Предварительная оценка стоимости строительства: удельный показатель по классу жилья × общая площадь, сравнение с бюджетом заказчика из контекста.' },
]

export const CONSTRUCTOR_ITEMS = [
  { id: 'frame', label: 'Принципиальная реализуемость каркаса', hint: 'монолитный ж/б, сейсмика 9 баллов' },
  { id: 'piles', label: 'Реализуемость свайного фундамента', hint: 'по данным инженерной геологии' },
  { id: 'diaphragms', label: 'Диафрагмы жёсткости для 9-балльной сейсмики', hint: 'расположение, толщина, связь с ЛЛУ' },
]

export const ENGINEER_ITEMS = [
  { id: 'itp', label: 'ИТП (индивидуальный тепловой пункт)' },
  { id: 'pump', label: 'Насосная' },
  { id: 'elec', label: 'Электрощитовые' },
  { id: 'vent', label: 'Венткамеры паркинга' },
  { id: 'smoke', label: 'Шахты дымоудаления' },
  { id: 'water', label: 'Водомерный узел' },
  { id: 'telecom', label: 'Помещения связи' },
  { id: 'risers', label: 'Вертикальные инженерные стояки' },
]

export const RESULT_ITEMS = [
  { id: 'chosen', label: 'Выбранный вариант' },
  { id: 'plans', label: 'Утверждённые планы' },
  { id: 'facades', label: 'Утверждённые фасады' },
  { id: 'tep', label: 'Подтверждённые ТЭП' },
  { id: 'protocol', label: 'Протокол утверждения концепции' },
]

// ── Контекст из предыдущих модулей (localStorage) ────────────────────────────

function readLS<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

export interface ProjectContext {
  text: string
  /** Короткие метки того, что удалось подтянуть — для карточки-индикатора */
  chips: string[]
}

export function buildProjectContext(): ProjectContext {
  const chips: string[] = []
  const lines: string[] = []

  // Параметры из «Основных проектных решений»
  const p = readLS<Record<string, string>>('design-basis-params-v1')
  if (p) {
    if (p.housingClass) { lines.push(`Класс жилья: ${p.housingClass}`); chips.push('класс') }
    if (p.mix1 || p.mix2 || p.mix3) { lines.push(`Квартирография: 1-комн. ${p.mix1 || '?'}%, 2-комн. ${p.mix2 || '?'}%, 3-комн. ${p.mix3 || '?'}%`); chips.push('квартирография') }
    if (p.flatAreaMin || p.flatAreaTarget) lines.push(`Площади квартир: мин. ${p.flatAreaMin || '?'} м², целевая ${p.flatAreaTarget || '?'} м²`)
    if (p.entrances) lines.push(`Количество подъездов: ${p.entrances}`)
    if (p.finishType) lines.push(`Отделка: ${p.finishType}`)
    if (p.facade) lines.push(`Тип фасада: ${p.facade}`)
    if (p.publicRooms) lines.push(`Встроенные общественные помещения: ${p.publicRooms}`)
    if (p.commercial) lines.push(`Коммерческие/общие помещения: ${p.commercial}`)
    if (p.evCharging) lines.push(`Зарядные станции для электромобилей: ${p.evCharging}`)
    if (p.metering) lines.push(`Учёт ресурсов: ${p.metering}`)
    if (p.maxBudget) { lines.push(`Допустимая стоимость строительства: ${p.maxBudget}`); chips.push('бюджет') }
    if (p.security) lines.push(`Системы безопасности: ${p.security}`)
    if (p.landscaping) lines.push(`Благоустройство: ${p.landscaping}`)
  }

  // Расчётные показатели
  const c = readLS<Record<string, string>>('design-basis-calc-v1')
  if (c) {
    if (c.siteArea) { lines.push(`Площадь участка: ${c.siteArea} м²`); chips.push('участок') }
    if (c.footprintArea) lines.push(`Площадь застройки: ${c.footprintArea} м²`)
    if (c.totalArea) lines.push(`Общая площадь здания: ${c.totalArea} м²`)
    if (c.flatsCount) { lines.push(`Количество квартир: ${c.flatsCount}`); chips.push('квартиры') }
    if (c.parkingActual) lines.push(`Парковочных мест: ${c.parkingActual}`)
  }

  // ТЗ (последний анализ)
  const hist = readLS<Array<{ docTitle?: string; report?: { sourceText?: string } }>>('tz-history')
  const lastTz = hist?.[0]
  if (lastTz?.report?.sourceText) {
    chips.push('ТЗ')
    lines.push(`\nФрагмент ТЗ (${lastTz.docTitle || 'документ'}):\n${lastTz.report.sourceText.slice(0, 3000)}`)
  }

  if (lines.length === 0) {
    return {
      text: 'Данные предыдущих модулей не заполнены — используй типовой проект: 9-этажный многоквартирный жилой дом, сейсмика 9 баллов, класс «комфорт».',
      chips: [],
    }
  }
  return { text: lines.join('\n'), chips }
}

/** Контакты назначенных лиц из раздела «Исходные данные» */
export function getContactOptions(): { value: string; label: string }[] {
  const contacts = readLS<Record<string, { name?: string; position?: string }>>('input-data-contacts-v1')
  if (!contacts) return []
  const roleLabel: Record<string, string> = {
    pm: 'руководитель проекта',
    'arch-approver': 'согласующий архитектуру',
    'tech-approver': 'согласующий технические решения',
    'budget-owner': 'ответственный за бюджет',
    correspondence: 'ответственный за переписку',
  }
  return Object.entries(contacts)
    .filter(([, c]) => c?.name?.trim())
    .map(([id, c]) => ({ value: c.name!.trim(), label: `${c.name!.trim()} — ${roleLabel[id] ?? c.position ?? id}` }))
}

// ── SVG из ответа LLM ────────────────────────────────────────────────────────

export function extractSvg(text: string): { svg: string | null; body: string } {
  let svg: string | null = null
  let body = text
  const fenced = text.match(/```svg\s*([\s\S]*?)```/)
  const raw = text.match(/<svg[\s\S]*?<\/svg>/)
  if (fenced) {
    svg = fenced[1].trim()
    body = text.replace(fenced[0], '').trim()
  } else if (raw) {
    svg = raw[0]
    body = text.replace(raw[0], '').trim()
  }
  if (svg) {
    // элементарная санитарная чистка: убираем скрипты и inline-обработчики
    svg = svg
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/\son\w+="[^"]*"/gi, '')
      .replace(/xlink:href/gi, 'href')
    if (!svg.startsWith('<svg')) svg = null
  }
  return { svg, body }
}

export interface GeneratedSection {
  text: string
  svg: string | null
  at: number
}

type Variant = 'v1' | 'v2'

const VARIANT_LABEL: Record<Variant, string> = { v1: 'Вариант 1', v2: 'Вариант 2' }
const VARIANT_GUIDE: Record<Variant, string> = {
  v1: 'Подход: компактная посадка, максимальная экономичность и простота реализации.',
  v2: 'Подход: альтернативная посадка, акцент на качество среды и архитектурную выразительность.',
}

// ─── Компонент ───────────────────────────────────────────────────────────────

export default function SketchSection() {
  const [variant, setVariant] = useLocalStorage<Variant>('sketch-variant-v1', 'v1')
  const [checked, setChecked] = useLocalStorage<Record<string, boolean>>('sketch-checks-v1', {})
  const [gen, setGen] = useLocalStorage<Record<string, GeneratedSection>>('sketch-gen-v1', {})
  const [chosen, setChosen] = useLocalStorage<'' | Variant>('sketch-chosen-v1', '')
  const [remarks, setRemarks] = useLocalStorage<{ owner: string; text: string }>('sketch-remarks-v1', { owner: '', text: '' })
  const [promptOverrides] = useLocalStorage<Record<string, string>>(PROMPTS_STORAGE_KEY, {})
  const [dialogSection, setDialogSection] = useState<string | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showMissing, setShowMissing] = useState(false)
  const [copied, setCopied] = useState(false)

  const startJob = trpc.ai.start.useMutation()
  const [job, setJob] = useState<{ variant: Variant; sectionId: string; jobId: string } | null>(null)
  const jobStatus = trpc.ai.status.useQuery(
    { id: job?.jobId ?? '' },
    { enabled: !!job, refetchInterval: 2000, retry: false },
  )
  const ctx = useMemo(buildProjectContext, [])
  const contactOptions = useMemo(getContactOptions, [])

  const dKey = (v: Variant, id: string) => `d:${v}:${id}`
  const genKey = (v: Variant, id: string) => `${v}:${id}`

  // Асинхронная генерация: опрашиваем статус задачи, пока она не завершится
  useEffect(() => {
    if (!job || !jobStatus.data) return
    const st = jobStatus.data
    if (st.state === 'done') {
      const { svg, body } = extractSvg(st.text ?? '')
      setGen((g) => ({ ...g, [genKey(job.variant, job.sectionId)]: { text: body, svg, at: Date.now() } }))
      setChecked((c) => ({ ...c, [dKey(job.variant, job.sectionId)]: true }))
      setBusy(null)
      setJob(null)
    } else if (st.state === 'error') {
      setError(st.error ?? 'Ошибка генерации')
      setBusy(null)
      setJob(null)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobStatus.data, job])

  const generateSection = (def: SketchSectionDef) => {
    const key = genKey(variant, def.id)
    setBusy(key)
    setError(null)
    const system = withExample(getPrompt('sketch-generate', promptOverrides), readExamples()['sketch'])
    const prompt = [
      'КОНТЕКСТ ПРОЕКТА (из предыдущих модулей):',
      ctx.text,
      '',
      `КОНЦЕПЦИЯ: ${VARIANT_LABEL[variant]}. ${VARIANT_GUIDE[variant]}`,
      '',
      `РАЗДЕЛ: ${def.title}`,
      `ЗАДАЧА: ${def.task}`,
    ].join('\n')
    startJob.mutate(
      { system, prompt, maxTokens: 6000 },
      {
        onSuccess: (data) => setJob({ variant, sectionId: def.id, jobId: data.id }),
        onError: (e) => {
          setError(e.message)
          setBusy(null)
        },
      },
    )
  }

  // Прогресс
  const designerDone = SKETCH_SECTIONS.filter(
    (s) => checked[dKey('v1', s.id)] && checked[dKey('v2', s.id)],
  ).length
  const designerTotal = SKETCH_SECTIONS.length * 2
  const designerCheckedCount = SKETCH_SECTIONS.reduce(
    (n, s) => n + (checked[dKey('v1', s.id)] ? 1 : 0) + (checked[dKey('v2', s.id)] ? 1 : 0),
    0,
  )
  const constructorDone = CONSTRUCTOR_ITEMS.filter((i) => checked[`k:${i.id}`]).length
  const engineerDone = ENGINEER_ITEMS.filter((i) => checked[`e:${i.id}`]).length
  const customerDone =
    (checked['c:reviewed'] ? 1 : 0) +
    (checked['c:commercial'] ? 1 : 0) +
    (chosen ? 1 : 0) +
    (remarks.owner && remarks.text.trim() ? 1 : 0) +
    (checked['c:approved'] ? 1 : 0)
  const resultDone =
    (chosen ? 1 : 0) + RESULT_ITEMS.filter((i) => i.id !== 'chosen' && checked[`r:${i.id}`]).length

  const total = designerTotal + CONSTRUCTOR_ITEMS.length + ENGINEER_ITEMS.length + 5 + RESULT_ITEMS.length
  const done = designerCheckedCount + constructorDone + engineerDone + customerDone + resultDone
  const percent = Math.round((done / total) * 100)

  // Перечень незакрытого
  const missingText = useMemo(() => {
    const parts: string[] = []
    for (const v of ['v1', 'v2'] as Variant[]) {
      const miss = SKETCH_SECTIONS.filter((s) => !checked[dKey(v, s.id)])
      if (miss.length) parts.push(`${VARIANT_LABEL[v]} — разделы в работе:\n${miss.map((s) => `— ${s.title}`).join('\n')}`)
    }
    const missK = CONSTRUCTOR_ITEMS.filter((i) => !checked[`k:${i.id}`])
    if (missK.length) parts.push(`Проверяет конструктор:\n${missK.map((i) => `— ${i.label}`).join('\n')}`)
    const missE = ENGINEER_ITEMS.filter((i) => !checked[`e:${i.id}`])
    if (missE.length) parts.push(`Подтверждают инженеры (место в здании):\n${missE.map((i) => `— ${i.label}`).join('\n')}`)
    const missC: string[] = []
    if (!checked['c:reviewed']) missC.push('— Рассмотреть варианты')
    if (!checked['c:commercial']) missC.push('— Проверить соответствие коммерческой модели')
    if (!chosen) missC.push('— Выбрать вариант')
    if (!(remarks.owner && remarks.text.trim())) missC.push('— Выдать сводные замечания (один ответственный)')
    if (!checked['c:approved']) missC.push('— Письменно утвердить выбранную концепцию')
    if (missC.length) parts.push(`Делает заказчик:\n${missC.join('\n')}`)
    const missR = RESULT_ITEMS.filter((i) => (i.id === 'chosen' ? !chosen : !checked[`r:${i.id}`]))
    if (missR.length) parts.push(`Результат шага:\n${missR.map((i) => `— ${i.label}`).join('\n')}`)
    return parts.join('\n\n')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checked, chosen, remarks])

  const copyMissing = async () => {
    await navigator.clipboard.writeText(`ЭСКИЗНЫЙ ПРОЕКТ — НЕ ЗАКРЫТО\n\n${missingText}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const resetAll = () => {
    if (!confirm('Сбросить эскизный проект: отметки, генерации, замечания?')) return
    setChecked({})
    setGen({})
    setChosen('')
    setRemarks({ owner: '', text: '' })
  }

  const dialogDef = SKETCH_SECTIONS.find((s) => s.id === dialogSection)
  const dialogGen = dialogDef ? gen[genKey(variant, dialogDef.id)] : undefined

  const simpleRow = (key: string, label: string, hint?: string) => (
    <div key={key} className="flex items-start gap-3 rounded-md px-2 py-2 transition-colors hover:bg-muted/50">
      <Checkbox
        className="mt-0.5"
        checked={!!checked[key]}
        onCheckedChange={(v) => setChecked((c) => ({ ...c, [key]: v === true }))}
      />
      <div className="flex-1">
        <span className={`text-sm ${checked[key] ? 'text-muted-foreground line-through' : ''}`}>{label}</span>
        {hint && <span className="block text-xs text-muted-foreground">{hint}</span>}
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      {/* Сводка + контекст */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Готовность эскизного проекта</span>
              <span className="tabular-nums text-muted-foreground">
                {done} из {total} · {percent}%
              </span>
            </div>
            <Progress value={percent} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {ctx.chips.length > 0 ? (
                <>
                  Используются данные предыдущих модулей:{' '}
                  {ctx.chips.map((c) => (
                    <Badge key={c} variant="secondary" className="mx-0.5 text-[10px] font-normal">
                      {c}
                    </Badge>
                  ))}
                </>
              ) : (
                'Предыдущие модули не заполнены — генерация будет использовать типовые параметры. Заполните «Проектные решения» для точного контекста.'
              )}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowMissing((v) => !v)} disabled={!missingText}>
              <ClipboardList className="mr-2 h-4 w-4" />
              {showMissing ? 'Скрыть перечень' : `Не закрыто: ${total - done}`}
            </Button>
            <Button variant="ghost" size="sm" onClick={resetAll}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Сбросить
            </Button>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/40">
          {error}
        </div>
      )}

      {/* Перечень незакрытого */}
      {showMissing && missingText && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Что осталось по эскизному проекту</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea readOnly value={missingText} className="min-h-[180px] font-mono text-xs leading-relaxed" />
            <Button variant="outline" size="sm" onClick={copyMissing}>
              {copied ? <Check className="mr-2 h-4 w-4 text-emerald-600" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? 'Скопировано' : 'Копировать перечень'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Разрабатывает проектировщик — 2 варианта */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Разрабатывает проектировщик</CardTitle>
              <CardDescription>
                Минимум два варианта размещения и планировки. Каждый раздел можно сгенерировать ИИ с учётом данных
                проекта — визуализация открывается в отдельном окне.
              </CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {designerCheckedCount}/{designerTotal}
            </Badge>
          </div>
          {/* Переключатель вариантов */}
          <div className="mt-3 flex items-center gap-2">
            {(['v1', 'v2'] as Variant[]).map((v) => (
              <button
                key={v}
                onClick={() => setVariant(v)}
                className={`rounded-md px-3 py-1.5 text-sm transition-colors ${
                  variant === v ? 'bg-slate-900 text-white' : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                {VARIANT_LABEL[v]}
                {chosen === v && <span className="ml-1.5 text-[10px] opacity-80">· выбран</span>}
              </button>
            ))}
            <span className="ml-auto text-xs text-muted-foreground tabular-nums">
              вариантов готово полностью: {designerDone}/{SKETCH_SECTIONS.length}
            </span>
          </div>
          <Progress
            value={
              (SKETCH_SECTIONS.filter((s) => checked[dKey(variant, s.id)]).length / SKETCH_SECTIONS.length) * 100
            }
            className="mt-2 h-1.5"
          />
        </CardHeader>
        <CardContent className="space-y-1">
          {SKETCH_SECTIONS.map((def) => {
            const key = dKey(variant, def.id)
            const g = gen[genKey(variant, def.id)]
            const isBusy = busy === genKey(variant, def.id)
            return (
              <div key={def.id} className="rounded-md px-2 py-2 transition-colors hover:bg-muted/50">
                <div className="flex items-start gap-3">
                  <Checkbox
                    className="mt-0.5"
                    checked={!!checked[key]}
                    onCheckedChange={(v) => setChecked((c) => ({ ...c, [key]: v === true }))}
                  />
                  <div className="flex-1">
                    <span className={`text-sm ${checked[key] ? 'text-muted-foreground' : ''}`}>{def.title}</span>
                    {isBusy && (
                      <span className="block text-[11px] text-muted-foreground">
                        Генерация… может занять 1–2 минуты
                      </span>
                    )}
                    {g && (
                      <span className="block text-[11px] text-muted-foreground">
                        Сгенерировано {new Date(g.at).toLocaleString('ru-RU')}
                        {g.svg ? ' · есть схема' : ''}
                      </span>
                    )}
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      disabled={isBusy}
                      onClick={() => void generateSection(def)}
                      title={g ? 'Перегенерировать раздел (ИИ)' : 'Сгенерировать раздел (ИИ)'}
                    >
                      {isBusy ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Sparkles className="mr-1 h-3.5 w-3.5" />}
                      {g ? 'Ещё раз' : 'ИИ'}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      disabled={!g}
                      onClick={() => setDialogSection(def.id)}
                      title="Открыть визуализацию раздела"
                    >
                      <Eye className="mr-1 h-3.5 w-3.5" />
                      Визуализация
                    </Button>
                  </div>
                </div>
              </div>
            )
          })}
        </CardContent>
      </Card>

      {/* Проверяет конструктор */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Проверяет конструктор</CardTitle>
              <CardDescription>Принципиальная реализуемость конструктива для сейсмики 9 баллов</CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {constructorDone}/{CONSTRUCTOR_ITEMS.length}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-1">
          {CONSTRUCTOR_ITEMS.map((i) => simpleRow(`k:${i.id}`, i.label, i.hint))}
        </CardContent>
      </Card>

      {/* Подтверждают инженеры */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Подтверждают инженеры</CardTitle>
              <CardDescription>В здании должно хватить места для инженерных систем</CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {engineerDone}/{ENGINEER_ITEMS.length}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-1">
          {ENGINEER_ITEMS.map((i) => simpleRow(`e:${i.id}`, i.label))}
        </CardContent>
      </Card>

      {/* Делает заказчик */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Делает заказчик</CardTitle>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {customerDone}/5
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            Замечания заказчика должен собирать один ответственный человек. Если архитекторы получают
            несогласованные комментарии от нескольких представителей заказчика, проект уходит в бесконечные
            переделки.
          </div>

          {simpleRow('c:reviewed', 'Рассмотрены оба варианта')}
          {simpleRow('c:commercial', 'Проверено соответствие коммерческой модели')}

          {/* Выбор варианта */}
          <div className="flex items-start gap-3 rounded-md px-2 py-2">
            <span
              className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border ${
                chosen ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-input'
              }`}
            >
              {chosen && <Check className="h-3 w-3" />}
            </span>
            <div className="flex-1">
              <span className="text-sm">Вариант выбран заказчиком</span>
              <div className="mt-1.5 flex gap-2">
                {(['v1', 'v2'] as Variant[]).map((v) => (
                  <button
                    key={v}
                    onClick={() => setChosen(chosen === v ? '' : v)}
                    className={`rounded-md border px-3 py-1 text-xs transition-colors ${
                      chosen === v
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40'
                        : 'border-input text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {VARIANT_LABEL[v]}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Сводные замечания */}
          <div className="flex items-start gap-3 rounded-md px-2 py-2">
            <span
              className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border ${
                remarks.owner && remarks.text.trim() ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-input'
              }`}
            >
              {remarks.owner && remarks.text.trim() && <Check className="h-3 w-3" />}
            </span>
            <div className="flex-1 space-y-1.5">
              <span className="text-sm">Сводные замечания выданы</span>
              <select
                value={remarks.owner}
                onChange={(e) => setRemarks((r) => ({ ...r, owner: e.target.value }))}
                className="h-8 w-full rounded-md border border-input bg-background px-2 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
              >
                <option value="">— ответственный за сбор замечаний —</option>
                {contactOptions.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
                {contactOptions.length === 0 && (
                  <option value="" disabled>
                    (заполните контакты в разделе «Исходные данные»)
                  </option>
                )}
              </select>
              <Textarea
                value={remarks.text}
                onChange={(e) => setRemarks((r) => ({ ...r, text: e.target.value }))}
                placeholder="Сводные замечания заказчика к выбранному варианту…"
                className="min-h-[80px] text-xs"
              />
            </div>
          </div>

          {simpleRow('c:approved', 'Концепция утверждена письменно')}
        </CardContent>
      </Card>

      {/* Результат шага */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Результат шага</CardTitle>
              <CardDescription>Фиксирует согласованную концепцию</CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {resultDone}/{RESULT_ITEMS.length}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-1">
          {/* Выбранный вариант — производный пункт */}
          <div className="flex items-start gap-3 rounded-md px-2 py-2">
            <span
              className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border ${
                chosen ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-input'
              }`}
            >
              {chosen && <Check className="h-3 w-3" />}
            </span>
            <span className={`text-sm ${chosen ? 'text-muted-foreground line-through' : ''}`}>
              Выбранный вариант{chosen ? `: ${VARIANT_LABEL[chosen]}` : ''}
            </span>
          </div>
          {RESULT_ITEMS.filter((i) => i.id !== 'chosen').map((i) => simpleRow(`r:${i.id}`, i.label))}
        </CardContent>
      </Card>

      {/* Окно визуализации раздела */}
      <Dialog open={!!dialogDef} onOpenChange={(o) => !o && setDialogSection(null)}>
        <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
          {dialogDef && (
            <>
              <DialogHeader>
                <DialogTitle>
                  {dialogDef.title} · {VARIANT_LABEL[variant]}
                </DialogTitle>
                <DialogDescription>
                  {dialogGen
                    ? `Сгенерировано ${new Date(dialogGen.at).toLocaleString('ru-RU')}`
                    : 'Раздел ещё не сгенерирован'}
                </DialogDescription>
              </DialogHeader>
              {dialogGen ? (
                <div className="space-y-4">
                  {dialogGen.svg && (
                    <div
                      className="overflow-hidden rounded-md border bg-white [&_svg]:h-auto [&_svg]:w-full"
                      dangerouslySetInnerHTML={{ __html: dialogGen.svg }}
                    />
                  )}
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">{dialogGen.text}</div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Нажмите «Сгенерировать», чтобы ИИ подготовил концепцию раздела по данным проекта.
                </p>
              )}
              <div className="flex justify-end border-t pt-3">
                <Button
                  size="sm"
                  disabled={busy === genKey(variant, dialogDef.id)}
                  onClick={() => void generateSection(dialogDef)}
                >
                  {busy === genKey(variant, dialogDef.id) ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Sparkles className="mr-2 h-4 w-4" />
                  )}
                  {dialogGen ? 'Перегенерировать' : 'Сгенерировать'}
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
