import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocalStorage } from '@/hooks/useLocalStorage'
import { extractTextFromFile } from '@/analysis/fileExtract'
import { verifyText, parseNum, type Attachment, type VerifyConfig } from '@/analysis/verify'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import {
  RotateCcw,
  ClipboardList,
  Check,
  Copy,
  Paperclip,
  FileText,
  X,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Calculator,
} from 'lucide-react'

// ─── Основные проектные решения (Basis of Design) ────────────────────────────
// Шаг между ТЗ и детальным проектированием:
// 1) заказчик определяет параметры; 2) проектировщик проверяет их на участке
//    и по нормам (в т.ч. автоматически); 3) заказчик утверждает результат.

// ── Параметры, которые определяет заказчик ───────────────────────────────────

export interface BasisParams {
  housingClass: string // эконом / комфорт / бизнес / элит
  mix1: string // % 1-комнатных
  mix2: string // % 2-комнатных
  mix3: string // % 3-комнатных
  flatAreaMin: string // м²
  flatAreaTarget: string // м²
  entrances: string
  finishReq: string // требования к отделке квартир и общих зон
  finishType: string // черновая / предчистовая / чистовая
  publicRooms: string
  commercial: string // коммерческие / общего пользования / не планируются
  facade: string
  landscaping: string
  security: string
  metering: string
  evCharging: string
  maxBudget: string
}

export const EMPTY_BASIS: BasisParams = {
  housingClass: '',
  mix1: '',
  mix2: '',
  mix3: '',
  flatAreaMin: '',
  flatAreaTarget: '',
  entrances: '',
  finishReq: '',
  finishType: '',
  publicRooms: '',
  commercial: '',
  facade: '',
  landscaping: '',
  security: '',
  metering: '',
  evCharging: '',
  maxBudget: '',
}

interface CustomerItem {
  id: string
  label: string
  hint?: string
  done: (p: BasisParams) => boolean
}

export const CUSTOMER_ITEMS: CustomerItem[] = [
  { id: 'cls', label: 'Класс жилого комплекса', hint: 'эконом, комфорт, бизнес', done: (p) => !!p.housingClass },
  {
    id: 'mix',
    label: 'Точное соотношение 1-, 2- и 3-комнатных квартир',
    hint: 'доли в процентах, в сумме 100%',
    done: (p) => {
      const a = parseNum(p.mix1)
      const b = parseNum(p.mix2)
      const c = parseNum(p.mix3)
      return a !== null && b !== null && c !== null && Math.round(a + b + c) === 100
    },
  },
  {
    id: 'areas',
    label: 'Минимальные и целевые площади квартир',
    hint: 'м² по каждому типу или усреднённо',
    done: (p) => parseNum(p.flatAreaMin) !== null && parseNum(p.flatAreaTarget) !== null,
  },
  { id: 'entrances', label: 'Количество подъездов', done: (p) => parseNum(p.entrances) !== null && parseNum(p.entrances)! > 0 },
  {
    id: 'finish-req',
    label: 'Требования к отделке квартир и общих зон',
    done: (p) => p.finishReq.trim().length > 2,
  },
  {
    id: 'finish-type',
    label: 'Тип отделки: черновая, предчистовая или чистовая',
    done: (p) => !!p.finishType,
  },
  {
    id: 'public-rooms',
    label: 'Состав встроенных общественных помещений',
    hint: 'консьерж, колясочная, коворкинг, фитнес…',
    done: (p) => p.publicRooms.trim().length > 2,
  },
  {
    id: 'commercial',
    label: 'Коммерческие помещения или помещения общего пользования',
    done: (p) => !!p.commercial,
  },
  { id: 'facade', label: 'Тип фасада', done: (p) => !!p.facade },
  { id: 'landscaping', label: 'Требования к благоустройству', done: (p) => p.landscaping.trim().length > 2 },
  { id: 'security', label: 'Требования к системам безопасности', hint: 'видеонаблюдение, СКУД, домофония, охрана', done: (p) => p.security.trim().length > 2 },
  { id: 'metering', label: 'Система учёта воды, тепла и электроэнергии', done: (p) => !!p.metering },
  { id: 'ev', label: 'Необходимость зарядных станций для электромобилей', done: (p) => !!p.evCharging },
  { id: 'budget', label: 'Допустимая стоимость строительства', done: (p) => parseNum(p.maxBudget) !== null && parseNum(p.maxBudget)! > 0 },
]

// ── Проверки проектировщика ──────────────────────────────────────────────────

interface CheckItem {
  id: string
  label: string
  hint?: string
}

export const DESIGNER_ITEMS: CheckItem[] = [
  { id: 'fits-site', label: 'Здание помещается на участке', hint: 'генплан: габариты, пятно застройки' },
  { id: 'offsets', label: 'Соблюдаются отступы', hint: 'от красных линий и границ участка' },
  { id: 'parking', label: 'Достаточно парковочных мест', hint: 'можно проверить расчётом ниже' },
  { id: 'insolation', label: 'Выполняется инсоляция квартир', hint: 'расчёт или ссылка на санитарные нормы' },
  { id: 'fire-dist', label: 'Соблюдаются противопожарные расстояния' },
  { id: 'fire-access', label: 'Возможен проезд пожарной техники' },
  { id: 'playgrounds', label: 'Помещаются детские и спортивные площадки' },
  { id: 'tu-points', label: 'Возможны подключения в точках, указанных в ТУ' },
  {
    id: 'area-vs-flats',
    label: 'Общая площадь соответствует заданному количеству квартир',
    hint: 'напр., 8 400 м² → 72 квартиры; можно проверить расчётом ниже',
  },
  { id: 'density', label: 'Показатели плотности и площади застройки не превышаются', hint: 'коэффициент застройки — расчётом ниже' },
]

// ── Результат шага: что утверждает заказчик ──────────────────────────────────

export const RESULT_ITEMS: CheckItem[] = [
  { id: 'flat-program', label: 'Программа квартир' },
  { id: 'rooms-table', label: 'Таблица помещений' },
  { id: 'tep', label: 'Основные технико-экономические показатели (ТЭП)' },
  { id: 'materials', label: 'Требования к материалам' },
  { id: 'eng-systems', label: 'Требования к инженерным системам' },
  { id: 'target-budget', label: 'Целевой бюджет' },
  { id: 'design-criteria', label: 'Основные критерии проектирования' },
]

// ── Правила автопроверки файлов для проверок проектировщика и результата ────

export const FILE_VERIFY: Record<string, VerifyConfig> = {
  'fits-site': {
    patterns: ['генплан|ситуационн[а-яё]+\\s+план', 'пятно\\s+застройки|площад[ьи]\\s+застройки|габарит'],
    minMatch: 1,
  },
  offsets: {
    patterns: ['отступ', 'красн[а-яё]+\\s+лини|границ[аы]\\s+участка'],
    minMatch: 1,
  },
  parking: {
    patterns: ['парков|машино[ -]?мест|автостоянк|паркинг'],
    minMatch: 1,
  },
  insolation: {
    patterns: ['инсоляц', 'санитарн[а-яё]+\\s+норм|естественн[а-яё]+\\s+освещ|КЕО'],
    minMatch: 1,
  },
  'fire-dist': {
    patterns: ['противопожарн[а-яё]+\\s+(расстоян|разрыв|норм|требован)'],
    minMatch: 1,
  },
  'fire-access': {
    patterns: ['проезд[аы]?\\s+(для\\s+)?пожарн|пожарн[а-яё]+\\s+(техник|автомобил|машин|лестниц)'],
    minMatch: 1,
  },
  playgrounds: {
    patterns: ['детск[а-яё]+\\s+(игров[а-яё]+\\s+)?площадк|спортивн[а-яё]+\\s+площадк|площадк[аи]\\s+отдыха'],
    minMatch: 1,
  },
  'tu-points': {
    patterns: ['точк[аи]\\s+подключени|присоединени', 'техническ[а-яё]+\\s+услови'],
    minMatch: 1,
  },
  'area-vs-flats': {
    patterns: ['общ[а-яё]+\\s+площад', 'квартир'],
    minMatch: 2,
  },
  density: {
    patterns: ['плотност|коэффициент[аы]?\\s+застройки|процент\\s+застройки|площад[ьи]\\s+застройки'],
    minMatch: 1,
  },
  'flat-program': {
    patterns: ['программ[аы]\\s+квартир|квартирограф'],
    minMatch: 1,
  },
  'rooms-table': {
    patterns: ['таблиц[аы]\\s+помещени|экспликац'],
    minMatch: 1,
  },
  tep: {
    patterns: ['технико-экономическ|ТЭП'],
    minMatch: 1,
  },
  materials: {
    patterns: ['требовани[яе]\\s+к\\s+материал|материал|отделочн[а-яё]+\\s+материал'],
    minMatch: 1,
  },
  'eng-systems': {
    patterns: ['инженерн[а-яё]+\\s+систем|отоплен|вентиляц|водоснабжен|электроснабжен|ОВиК|ЭОМ'],
    minMatch: 1,
  },
  'target-budget': {
    patterns: ['целев[а-яё]+\\s+бюджет|бюджет|стоимост[ьи]\\s+строительств'],
    minMatch: 1,
  },
  'design-criteria': {
    patterns: ['критери[яи]\\s+проектирован|basis of design|основн[а-яё]+\\s+проектн[а-яё]+\\s+решен'],
    minMatch: 1,
  },
}

// ── Автопроверка показателей (расчёт) ────────────────────────────────────────

export interface CalcInputs {
  siteArea: string // площадь участка, м²
  footprintArea: string // площадь застройки, м²
  totalArea: string // общая площадь здания, м²
  flatsCount: string // количество квартир
  parkingActual: string // парковочных мест по генплану
}

export const EMPTY_CALC: CalcInputs = { siteArea: '', footprintArea: '', totalArea: '', flatsCount: '', parkingActual: '' }

/** Расчётная норма парковки на квартиру по классу жилья (оценочно) */
export const PARKING_COEFF: Record<string, number> = {
  эконом: 0.7,
  комфорт: 1.0,
  бизнес: 1.5,
  элит: 2.0,
}

export interface CalcResult {
  id: string // связанный пункт чек-листа
  ready: boolean // достаточно данных для вывода
  ok: boolean
  text: string
}

export function runCalc(c: CalcInputs, p: BasisParams): CalcResult[] {
  const results: CalcResult[] = []

  // 1. Общая площадь ↔ количество квартир
  const total = parseNum(c.totalArea)
  const flats = parseNum(c.flatsCount)
  if (total && flats && flats > 0) {
    const avg = total / flats
    const min = parseNum(p.flatAreaMin)
    const target = parseNum(p.flatAreaTarget)
    let ok = true
    let note = ''
    if (min && avg < min) {
      ok = false
      note = ` — это ниже минимальной площади квартиры (${min} м²)`
    } else if (target) {
      const dev = Math.abs(avg - target) / target
      if (dev > 0.15) {
        ok = false
        note = ` — отклонение от целевой (${target} м²) ${(dev * 100).toFixed(0)}% при допустимых 15%`
      } else {
        note = ` — в пределах 15% от целевой (${target} м²)`
      }
    }
    results.push({
      id: 'area-vs-flats',
      ready: true,
      ok,
      text: `Средняя общая площадь квартиры: ${avg.toFixed(1)} м² (${total.toLocaleString('ru-RU')} м² / ${flats} кв.)${note}`,
    })
  } else {
    results.push({ id: 'area-vs-flats', ready: false, ok: false, text: 'Укажите общую площадь здания и количество квартир' })
  }

  // 2. Коэффициент застройки
  const site = parseNum(c.siteArea)
  const foot = parseNum(c.footprintArea)
  if (site && foot && site > 0) {
    const k = foot / site
    const ok = k <= 0.4
    results.push({
      id: 'density',
      ready: true,
      ok,
      text: `Коэффициент застройки: ${k.toFixed(2)} — ${ok ? 'в пределах' : 'превышает'} ориентир 0,35–0,40 для многоэтажного жилья`,
    })
  } else {
    results.push({ id: 'density', ready: false, ok: false, text: 'Укажите площадь участка и площадь застройки' })
  }

  // 3. Парковка
  const parking = parseNum(c.parkingActual)
  if (flats && flats > 0 && parking !== null && p.housingClass) {
    const coeff = PARKING_COEFF[p.housingClass] ?? 1.0
    const norm = Math.ceil(flats * coeff)
    const ok = parking >= norm
    results.push({
      id: 'parking',
      ready: true,
      ok,
      text: `Расчётный минимум: ${norm} мест (${coeff.toLocaleString('ru-RU')} на квартиру, класс «${p.housingClass}»); по генплану: ${parking} — ${ok ? 'достаточно' : `не хватает ${norm - parking}`}`,
    })
  } else {
    results.push({ id: 'parking', ready: false, ok: false, text: 'Укажите количество квартир, мест по генплану и класс жилья (выше)' })
  }

  return results
}

// ─── Компонент ───────────────────────────────────────────────────────────────

const SELECT_CLASS =
  'h-8 w-full rounded-md border border-input bg-background px-2 text-xs shadow-sm focus:outline-none focus:ring-1 focus:ring-ring'

export default function DesignBasisSection() {
  const [params, setParams] = useLocalStorage<BasisParams>('design-basis-params-v1', EMPTY_BASIS)
  const [checked, setChecked] = useLocalStorage<Record<string, boolean>>('design-basis-checks-v1', {})
  const [attachments, setAttachments] = useLocalStorage<Record<string, Attachment>>('design-basis-files-v1', {})
  const [calc, setCalc] = useLocalStorage<CalcInputs>('design-basis-calc-v1', EMPTY_CALC)
  const [copied, setCopied] = useState(false)
  const [showMissing, setShowMissing] = useState(false)
  const [busyItem, setBusyItem] = useState<string | null>(null)
  const [uploadTarget, setUploadTarget] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const setParam = (key: keyof BasisParams, value: string) => setParams((p) => ({ ...p, [key]: value }))
  const setCalcField = (key: keyof CalcInputs, value: string) => setCalc((c) => ({ ...c, [key]: value }))

  // Расчёт автопроверки показателей
  const calcResults = useMemo(() => runCalc(calc, params), [calc, params])

  // Успешный расчёт автоматически отмечает связанный пункт
  useEffect(() => {
    for (const r of calcResults) {
      if (r.ready && r.ok && !checked[r.id]) {
        setChecked((c) => ({ ...c, [r.id]: true }))
      }
    }
  }, [calcResults, checked, setChecked])

  // Прогресс
  const customerDone = CUSTOMER_ITEMS.filter((i) => i.done(params)).length
  const fileItems = [...DESIGNER_ITEMS, ...RESULT_ITEMS]
  const filesDone = fileItems.filter((i) => checked[i.id]).length
  const total = CUSTOMER_ITEMS.length + fileItems.length
  const done = customerDone + filesDone
  const percent = Math.round((done / total) * 100)

  // Перечень недостающего
  const missingText = useMemo(() => {
    const parts: string[] = []
    const missCustomer = CUSTOMER_ITEMS.filter((i) => !i.done(params))
    if (missCustomer.length) {
      parts.push(`Определяет заказчик:\n${missCustomer.map((i) => `— ${i.label}`).join('\n')}`)
    }
    const missDesigner = DESIGNER_ITEMS.filter((i) => !checked[i.id])
    if (missDesigner.length) {
      parts.push(`Проверяет проектировщик:\n${missDesigner.map((i) => `— ${i.label}`).join('\n')}`)
    }
    const missResult = RESULT_ITEMS.filter((i) => !checked[i.id])
    if (missResult.length) {
      parts.push(`Утверждает заказчик (результат шага):\n${missResult.map((i) => `— ${i.label}`).join('\n')}`)
    }
    return parts.join('\n\n')
  }, [params, checked])

  const copyMissing = async () => {
    await navigator.clipboard.writeText(`ОСНОВНЫЕ ПРОЕКТНЫЕ РЕШЕНИЯ — НЕ ЗАКРЫТО\n\n${missingText}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Загрузка и проверка файла
  const startUpload = (itemId: string) => {
    setUploadTarget(itemId)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
      fileInputRef.current.click()
    }
  }

  const removeAttachment = (itemId: string) => {
    setAttachments((a) => {
      const next = { ...a }
      delete next[itemId]
      return next
    })
    setChecked((c) => ({ ...c, [itemId]: false }))
  }

  const handleFile = async (file: File | undefined) => {
    const itemId = uploadTarget
    if (!file || !itemId) return
    setBusyItem(itemId)
    try {
      const result = await extractTextFromFile(file)
      const att = verifyText(file.name, result.text, result.warning, FILE_VERIFY[itemId])
      setAttachments((a) => ({ ...a, [itemId]: att }))
      if (att.status === 'match') setChecked((c) => ({ ...c, [itemId]: true }))
    } catch (e) {
      setAttachments((a) => ({
        ...a,
        [itemId]: {
          fileName: file.name,
          status: 'error',
          detail: e instanceof Error ? e.message : 'Ошибка чтения файла',
        },
      }))
    } finally {
      setBusyItem(null)
    }
  }

  const resetAll = () => {
    if (!confirm('Сбросить параметры, отметки, расчёт и приложенные файлы?')) return
    setParams(EMPTY_BASIS)
    setChecked({})
    setAttachments({})
    setCalc(EMPTY_CALC)
  }

  // Сумма квартирографии
  const mixSum = [params.mix1, params.mix2, params.mix3].map(parseNum)
  const mixFilled = mixSum.every((v) => v !== null)
  const mixTotal = mixFilled ? (mixSum as number[]).reduce((a, b) => a + b, 0) : null

  // Строка пункта с файлом (проектировщик / результат)
  const renderFileItem = (item: CheckItem) => {
    const att = attachments[item.id]
    const isBusy = busyItem === item.id
    return (
      <div key={item.id} className="rounded-md px-2 py-2 transition-colors hover:bg-muted/50">
        <div className="flex items-start gap-3">
          <Checkbox
            className="mt-0.5"
            checked={!!checked[item.id]}
            onCheckedChange={(v) => setChecked((c) => ({ ...c, [item.id]: v === true }))}
          />
          <div className="flex-1">
            <span className={`text-sm ${checked[item.id] ? 'text-muted-foreground line-through' : ''}`}>{item.label}</span>
            {item.hint && <span className="block text-xs text-muted-foreground">{item.hint}</span>}
            {att && (
              <div
                className={`mt-1.5 flex items-start gap-2 rounded-md border px-2.5 py-1.5 text-xs ${
                  att.status === 'match'
                    ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/40'
                    : att.status === 'mismatch'
                      ? 'border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40'
                      : 'border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/40'
                }`}
              >
                {att.status === 'match' ? (
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                ) : (
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
                )}
                <div className="flex-1">
                  <span className="inline-flex items-center gap-1 font-medium">
                    <FileText className="h-3 w-3" />
                    {att.fileName}
                  </span>
                  <span className="block text-muted-foreground">{att.detail}</span>
                </div>
                <button
                  type="button"
                  onClick={() => removeAttachment(item.id)}
                  className="mt-0.5 shrink-0 text-muted-foreground hover:text-foreground"
                  title="Удалить файл"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 shrink-0 p-0"
            disabled={isBusy}
            onClick={() => startUpload(item.id)}
            title={att ? 'Заменить файл' : 'Прикрепить файл для автоматической проверки'}
          >
            {isBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Paperclip className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    )
  }

  // Строка параметра заказчика с индикатором заполненности
  const renderParamRow = (item: CustomerItem, control: React.ReactNode) => {
    const ok = item.done(params)
    return (
      <div key={item.id} className="rounded-md px-2 py-2 transition-colors hover:bg-muted/50">
        <div className="flex items-start gap-3">
          <span
            className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border ${
              ok ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-input'
            }`}
          >
            {ok && <Check className="h-3 w-3" />}
          </span>
          <div className="flex-1">
            <span className={`text-sm ${ok ? 'text-muted-foreground' : ''}`}>{item.label}</span>
            {item.hint && <span className="block text-xs text-muted-foreground">{item.hint}</span>}
            <div className="mt-1.5">{control}</div>
          </div>
        </div>
      </div>
    )
  }

  const itemById = (id: string) => CUSTOMER_ITEMS.find((i) => i.id === id)!

  return (
    <div className="space-y-6">
      <input
        ref={fileInputRef}
        type="file"
        accept=".txt,.md,.text,.pdf,.doc,.docx"
        className="hidden"
        onChange={(e) => void handleFile(e.target.files?.[0])}
      />

      {/* Сводка */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Готовность Basis of Design</span>
              <span className="tabular-nums text-muted-foreground">
                {done} из {total} · {percent}%
              </span>
            </div>
            <Progress value={percent} className="h-2" />
            <p className="text-xs text-muted-foreground">
              ТЗ задаёт общие рамки — здесь согласуются конкретные проектные решения: параметры от заказчика,
              проверки проектировщика (в т.ч. автоматические) и утверждаемый результат.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowMissing((v) => !v)} disabled={!missingText}>
              <ClipboardList className="mr-2 h-4 w-4" />
              {showMissing ? 'Скрыть перечень' : `Не закрыто: ${total - done}`}
            </Button>
            <Button variant="ghost" size="sm" onClick={resetAll}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Сбросить
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Перечень незакрытого */}
      {showMissing && missingText && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Что осталось согласовать</CardTitle>
            <CardDescription>Готовый текст для протокола или письма заказчику</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea readOnly value={missingText} className="min-h-[180px] font-mono text-xs leading-relaxed" />
            <Button variant="outline" size="sm" onClick={copyMissing}>
              {copied ? <Check className="mr-2 h-4 w-4 text-emerald-600" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? 'Скопировано' : 'Копировать перечень'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* 1. Определяет заказчик */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Определяет заказчик</CardTitle>
              <CardDescription>Параметры, без которых невозможно детальное проектирование</CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {customerDone}/{CUSTOMER_ITEMS.length}
            </Badge>
          </div>
          <Progress value={(customerDone / CUSTOMER_ITEMS.length) * 100} className="mt-2 h-1.5" />
        </CardHeader>
        <CardContent className="space-y-1">
          {renderParamRow(
            itemById('cls'),
            <select value={params.housingClass} onChange={(e) => setParam('housingClass', e.target.value)} className={SELECT_CLASS}>
              <option value="">— не выбрано —</option>
              <option value="эконом">эконом</option>
              <option value="комфорт">комфорт</option>
              <option value="бизнес">бизнес</option>
              <option value="элит">элит</option>
            </select>,
          )}
          {renderParamRow(
            itemById('mix'),
            <div className="space-y-1">
              <div className="grid grid-cols-3 gap-1.5">
                <Input value={params.mix1} onChange={(e) => setParam('mix1', e.target.value)} placeholder="1-комн., %" className="h-8 text-xs" />
                <Input value={params.mix2} onChange={(e) => setParam('mix2', e.target.value)} placeholder="2-комн., %" className="h-8 text-xs" />
                <Input value={params.mix3} onChange={(e) => setParam('mix3', e.target.value)} placeholder="3-комн., %" className="h-8 text-xs" />
              </div>
              {mixTotal !== null && (
                <span className={`text-[11px] ${mixTotal === 100 ? 'text-emerald-600' : 'text-amber-600'}`}>
                  Σ = {mixTotal}%{mixTotal === 100 ? '' : ' — должно быть 100%'}
                </span>
              )}
            </div>,
          )}
          {renderParamRow(
            itemById('areas'),
            <div className="grid grid-cols-2 gap-1.5">
              <Input value={params.flatAreaMin} onChange={(e) => setParam('flatAreaMin', e.target.value)} placeholder="Минимум, м²" className="h-8 text-xs" />
              <Input value={params.flatAreaTarget} onChange={(e) => setParam('flatAreaTarget', e.target.value)} placeholder="Целевая, м²" className="h-8 text-xs" />
            </div>,
          )}
          {renderParamRow(
            itemById('entrances'),
            <Input value={params.entrances} onChange={(e) => setParam('entrances', e.target.value)} placeholder="Например, 4" className="h-8 text-xs" />,
          )}
          {renderParamRow(
            itemById('finish-req'),
            <Input
              value={params.finishReq}
              onChange={(e) => setParam('finishReq', e.target.value)}
              placeholder="Квартиры и МОП: материалы, уровень отделки"
              className="h-8 text-xs"
            />,
          )}
          {renderParamRow(
            itemById('finish-type'),
            <select value={params.finishType} onChange={(e) => setParam('finishType', e.target.value)} className={SELECT_CLASS}>
              <option value="">— не выбрано —</option>
              <option value="черновая">черновая</option>
              <option value="предчистовая">предчистовая</option>
              <option value="чистовая">чистовая</option>
            </select>,
          )}
          {renderParamRow(
            itemById('public-rooms'),
            <Input
              value={params.publicRooms}
              onChange={(e) => setParam('publicRooms', e.target.value)}
              placeholder="Перечень встроенных помещений"
              className="h-8 text-xs"
            />,
          )}
          {renderParamRow(
            itemById('commercial'),
            <select value={params.commercial} onChange={(e) => setParam('commercial', e.target.value)} className={SELECT_CLASS}>
              <option value="">— не выбрано —</option>
              <option value="коммерческие">коммерческие помещения</option>
              <option value="общего пользования">помещения общего пользования</option>
              <option value="не планируются">не планируются</option>
            </select>,
          )}
          {renderParamRow(
            itemById('facade'),
            <select value={params.facade} onChange={(e) => setParam('facade', e.target.value)} className={SELECT_CLASS}>
              <option value="">— не выбрано —</option>
              <option value="вентилируемый">вентилируемый фасад</option>
              <option value="мокрый (штукатурный)">мокрый (штукатурный)</option>
              <option value="кирпичный">кирпичный</option>
              <option value="комбинированный">комбинированный</option>
            </select>,
          )}
          {renderParamRow(
            itemById('landscaping'),
            <Input
              value={params.landscaping}
              onChange={(e) => setParam('landscaping', e.target.value)}
              placeholder="Озеленение, площадки, МАФ, освещение"
              className="h-8 text-xs"
            />,
          )}
          {renderParamRow(
            itemById('security'),
            <Input
              value={params.security}
              onChange={(e) => setParam('security', e.target.value)}
              placeholder="Видеонаблюдение, СКУД, домофония"
              className="h-8 text-xs"
            />,
          )}
          {renderParamRow(
            itemById('metering'),
            <select value={params.metering} onChange={(e) => setParam('metering', e.target.value)} className={SELECT_CLASS}>
              <option value="">— не выбрано —</option>
              <option value="индивидуальный">индивидуальный учёт</option>
              <option value="общедомовой">общедомовой учёт</option>
              <option value="комбинированный (АСКУЭ)">комбинированный (АСКУЭ)</option>
            </select>,
          )}
          {renderParamRow(
            itemById('ev'),
            <select value={params.evCharging} onChange={(e) => setParam('evCharging', e.target.value)} className={SELECT_CLASS}>
              <option value="">— не выбрано —</option>
              <option value="да">да, станции в паркинге</option>
              <option value="подготовить инфраструктуру">подготовить инфраструктуру</option>
              <option value="нет">нет</option>
            </select>,
          )}
          {renderParamRow(
            itemById('budget'),
            <Input
              value={params.maxBudget}
              onChange={(e) => setParam('maxBudget', e.target.value)}
              placeholder="Например, 4 500 000 000 тенге"
              className="h-8 text-xs"
            />,
          )}
        </CardContent>
      </Card>

      {/* Автоматическая проверка показателей */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Calculator className="h-4 w-4" />
            Автоматическая проверка показателей
          </CardTitle>
          <CardDescription>
            Введите цифры из исходных данных и генплана — расчёт сравнит их с параметрами заказчика и нормативными
            ориентирами, а при успехе сам отметит соответствующие пункты ниже
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-5">
            <Input value={calc.siteArea} onChange={(e) => setCalcField('siteArea', e.target.value)} placeholder="Участок, м²" className="h-8 text-xs" />
            <Input value={calc.footprintArea} onChange={(e) => setCalcField('footprintArea', e.target.value)} placeholder="Застройка, м²" className="h-8 text-xs" />
            <Input value={calc.totalArea} onChange={(e) => setCalcField('totalArea', e.target.value)} placeholder="Общая площадь, м²" className="h-8 text-xs" />
            <Input value={calc.flatsCount} onChange={(e) => setCalcField('flatsCount', e.target.value)} placeholder="Квартир, шт" className="h-8 text-xs" />
            <Input value={calc.parkingActual} onChange={(e) => setCalcField('parkingActual', e.target.value)} placeholder="Мест парковки" className="h-8 text-xs" />
          </div>
          <div className="space-y-1.5">
            {calcResults.map((r) => (
              <div key={r.id} className="flex items-start gap-2 text-xs">
                {!r.ready ? (
                  <span className="mt-0.5 h-3.5 w-3.5 shrink-0 rounded-full border border-dashed border-muted-foreground/40" />
                ) : r.ok ? (
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                ) : (
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
                )}
                <span className={r.ready ? (r.ok ? 'text-foreground' : 'text-amber-700 dark:text-amber-400') : 'text-muted-foreground'}>
                  {r.text}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 2. Проверяет проектировщик */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Проверяет проектировщик</CardTitle>
              <CardDescription>
                Приложите генплан, расчёт или выдержку из ТУ — содержимое проверится автоматически, либо отметьте
                вручную
              </CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {DESIGNER_ITEMS.filter((i) => checked[i.id]).length}/{DESIGNER_ITEMS.length}
            </Badge>
          </div>
          <Progress value={(DESIGNER_ITEMS.filter((i) => checked[i.id]).length / DESIGNER_ITEMS.length) * 100} className="mt-2 h-1.5" />
        </CardHeader>
        <CardContent className="space-y-1">{DESIGNER_ITEMS.map(renderFileItem)}</CardContent>
      </Card>

      {/* 3. Результат шага */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Результат шага — утверждает заказчик</CardTitle>
              <CardDescription>Документы, которые фиксируют согласованные основные проектные решения</CardDescription>
            </div>
            <Badge variant="secondary" className="shrink-0 tabular-nums">
              {RESULT_ITEMS.filter((i) => checked[i.id]).length}/{RESULT_ITEMS.length}
            </Badge>
          </div>
          <Progress value={(RESULT_ITEMS.filter((i) => checked[i.id]).length / RESULT_ITEMS.length) * 100} className="mt-2 h-1.5" />
        </CardHeader>
        <CardContent className="space-y-1">{RESULT_ITEMS.map(renderFileItem)}</CardContent>
      </Card>
    </div>
  )
}
