// ─── Панель настроек ─────────────────────────────────────────────────────────
// Три раздела:
//   1. Промпты — редактируемые промпты для всех модулей (сгруппированы);
//   2. Примеры документов — образцы, подставляемые в ИИ-генерацию;
//   3. Внешний вид — тема, размер шрифта, гарнитура.

import { useEffect, useRef, useState } from 'react'
import { useLocalStorage } from '@/hooks/useLocalStorage'
import {
  PROMPT_FUNCTIONS,
  PROMPT_MODULES,
  PROMPTS_STORAGE_KEY,
  EXAMPLE_TARGETS,
  readExamples,
  saveExample,
  type ExampleDoc,
} from '@/analysis/prompts'
import { extractTextFromFile } from '@/analysis/fileExtract'
import {
  APPEARANCE_KEY,
  APPEARANCE_EVENT,
  DEFAULT_APPEARANCE,
  applyAppearance,
  type AppearanceSettings,
} from '@/hooks/useAppearance'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RotateCcw, Check, FileText, Upload, Trash2, Loader2, Sun, Moon, Monitor } from 'lucide-react'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function SettingsPanel({ open, onOpenChange }: Props) {
  const [overrides, setOverrides] = useLocalStorage<Record<string, string>>(PROMPTS_STORAGE_KEY, {})
  const [appearance, setAppearance] = useLocalStorage<AppearanceSettings>(APPEARANCE_KEY, DEFAULT_APPEARANCE)
  const [examples, setExamples] = useState<Record<string, ExampleDoc>>({})
  const [savedFlash, setSavedFlash] = useState(false)
  const [uploading, setUploading] = useState<string | null>(null)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const fileInputs = useRef<Record<string, HTMLInputElement | null>>({})

  useEffect(() => {
    if (open) setExamples(readExamples())
  }, [open])

  const flash = () => {
    setSavedFlash(true)
    setTimeout(() => setSavedFlash(false), 1200)
  }

  // ── Промпты ──
  const setPrompt = (id: string, value: string) => {
    setOverrides((o) => ({ ...o, [id]: value }))
    flash()
  }
  const resetOne = (id: string) => {
    setOverrides((o) => {
      const next = { ...o }
      delete next[id]
      return next
    })
  }
  const resetAll = () => {
    if (confirm('Вернуть все промпты к значениям по умолчанию?')) setOverrides({})
  }
  const customCount = PROMPT_FUNCTIONS.filter((f) => overrides[f.id]?.trim()).length

  // ── Примеры документов ──
  const handleExampleFile = async (id: string, file: File) => {
    setUploading(id)
    setUploadError(null)
    try {
      const res = await extractTextFromFile(file)
      const doc: ExampleDoc = { name: file.name, text: res.text.slice(0, 4000), at: Date.now() }
      saveExample(id, doc)
      setExamples(readExamples())
      flash()
    } catch (e) {
      setUploadError(e instanceof Error ? e.message : 'Не удалось прочитать файл')
    } finally {
      setUploading(null)
    }
  }
  const removeExample = (id: string) => {
    saveExample(id, null)
    setExamples(readExamples())
  }

  // ── Внешний вид ──
  const setApp = (patch: Partial<AppearanceSettings>) => {
    const next = { ...appearance, ...patch }
    setAppearance(next)
    applyAppearance(next)
    window.dispatchEvent(new Event(APPEARANCE_EVENT))
    flash()
  }

  const seg = <T extends string>(
    value: T,
    options: { v: T; label: string; icon?: React.ReactNode }[],
    onChange: (v: T) => void,
  ) => (
    <div className="flex flex-wrap gap-1">
      {options.map((o) => (
        <Button
          key={o.v}
          variant={value === o.v ? 'default' : 'outline'}
          size="sm"
          className="h-7 text-xs"
          onClick={() => onChange(o.v)}
        >
          {o.icon}
          {o.label}
        </Button>
      ))}
    </div>
  )

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col sm:max-w-2xl">
        <SheetHeader>
          <div className="flex items-center justify-between gap-3 pr-6">
            <SheetTitle>Настройки</SheetTitle>
            {savedFlash && (
              <span className="inline-flex items-center gap-1 text-xs text-emerald-600">
                <Check className="h-3.5 w-3.5" />
                Сохранено
              </span>
            )}
          </div>
          <SheetDescription>
            Все настройки сохраняются автоматически и хранятся локально в этом браузере.
          </SheetDescription>
        </SheetHeader>

        <Tabs defaultValue="prompts" className="mt-4 flex min-h-0 flex-1 flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="prompts">Промпты</TabsTrigger>
            <TabsTrigger value="examples">Примеры документов</TabsTrigger>
            <TabsTrigger value="appearance">Внешний вид</TabsTrigger>
          </TabsList>

          {/* ── Промпты ── */}
          <TabsContent value="prompts" className="mt-4 min-h-0 flex-1 space-y-6 overflow-y-auto pr-1">
            <p className="text-xs text-muted-foreground">
              Промпты модулей «Эскизный проект» и «3D-модель» применяются при ИИ-генерации сразу;
              остальные — при подключении ИИ-анализа к соответствующим модулям.
            </p>
            {PROMPT_MODULES.map((mod) => {
              const fns = PROMPT_FUNCTIONS.filter((f) => f.module === mod.id)
              if (!fns.length) return null
              return (
                <div key={mod.id} className="space-y-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{mod.title}</p>
                  {fns.map((fn) => {
                    const isCustom = !!overrides[fn.id]?.trim()
                    return (
                      <div key={fn.id} className="space-y-1.5 rounded-lg border p-3">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-sm font-medium">{fn.title}</p>
                            <p className="text-xs text-muted-foreground">{fn.description}</p>
                          </div>
                          <div className="flex shrink-0 items-center gap-1">
                            {isCustom && (
                              <Badge variant="outline" className="text-[10px] font-normal">
                                изменён
                              </Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                              onClick={() => resetOne(fn.id)}
                              disabled={!isCustom}
                              title="Вернуть промпт по умолчанию"
                            >
                              <RotateCcw className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                        <Textarea
                          value={overrides[fn.id] ?? fn.defaultPrompt}
                          onChange={(e) => setPrompt(fn.id, e.target.value)}
                          className="min-h-[110px] text-xs leading-relaxed"
                        />
                      </div>
                    )
                  })}
                </div>
              )
            })}
            <div className="flex items-center justify-between border-t pt-3">
              <span className="text-xs text-muted-foreground">
                Изменено промптов: {customCount} из {PROMPT_FUNCTIONS.length}
              </span>
              <Button variant="outline" size="sm" onClick={resetAll} disabled={customCount === 0}>
                <RotateCcw className="mr-2 h-3.5 w-3.5" />
                Сбросить все
              </Button>
            </div>
          </TabsContent>

          {/* ── Примеры документов ── */}
          <TabsContent value="examples" className="mt-4 min-h-0 flex-1 space-y-3 overflow-y-auto pr-1">
            <p className="text-xs text-muted-foreground">
              Загруженные образцы подставляются в ИИ-генерацию как эталон структуры и стиля
              (используются первые 4000 символов текста). Пометка «ИИ» — применяется уже сейчас,
              остальные — при подключении ИИ-анализа к модулю.
            </p>
            {uploadError && <p className="text-xs text-destructive">{uploadError}</p>}
            {EXAMPLE_TARGETS.map((t) => {
              const doc = examples[t.id]
              return (
                <div key={t.id} className="flex items-start gap-3 rounded-lg border p-3">
                  <FileText className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{t.title}</p>
                      {t.live && (
                        <Badge variant="secondary" className="text-[10px] font-normal">
                          ИИ
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{t.description}</p>
                    {doc && (
                      <p className="mt-1 truncate text-xs text-emerald-700 dark:text-emerald-400">
                        {doc.name} · {new Date(doc.at).toLocaleString('ru-RU')}
                      </p>
                    )}
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <input
                      ref={(el) => {
                        fileInputs.current[t.id] = el
                      }}
                      type="file"
                      accept=".pdf,.doc,.docx,.txt,.md"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0]
                        if (f) void handleExampleFile(t.id, f)
                        e.target.value = ''
                      }}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs"
                      disabled={uploading === t.id}
                      onClick={() => fileInputs.current[t.id]?.click()}
                    >
                      {uploading === t.id ? (
                        <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Upload className="mr-1 h-3.5 w-3.5" />
                      )}
                      {doc ? 'Заменить' : 'Загрузить'}
                    </Button>
                    {doc && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0 text-muted-foreground"
                        onClick={() => removeExample(t.id)}
                        title="Удалить пример"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              )
            })}
          </TabsContent>

          {/* ── Внешний вид ── */}
          <TabsContent value="appearance" className="mt-4 min-h-0 flex-1 space-y-5 overflow-y-auto pr-1">
            <div className="space-y-1.5">
              <p className="text-sm font-medium">Тема</p>
              {seg(
                appearance.theme,
                [
                  { v: 'light', label: 'Светлая', icon: <Sun className="mr-1 h-3.5 w-3.5" /> },
                  { v: 'dark', label: 'Тёмная', icon: <Moon className="mr-1 h-3.5 w-3.5" /> },
                  { v: 'system', label: 'Как в системе', icon: <Monitor className="mr-1 h-3.5 w-3.5" /> },
                ],
                (v) => setApp({ theme: v }),
              )}
            </div>
            <div className="space-y-1.5">
              <p className="text-sm font-medium">Размер шрифта</p>
              {seg(
                appearance.fontSize,
                [
                  { v: 's', label: 'Мелкий' },
                  { v: 'm', label: 'Средний' },
                  { v: 'l', label: 'Крупный' },
                ],
                (v) => setApp({ fontSize: v }),
              )}
            </div>
            <div className="space-y-1.5">
              <p className="text-sm font-medium">Шрифт</p>
              {seg(
                appearance.fontFamily,
                [
                  { v: 'system', label: 'Системный' },
                  { v: 'serif', label: 'С засечками' },
                  { v: 'mono', label: 'Моноширинный' },
                ],
                (v) => setApp({ fontFamily: v }),
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setAppearance(DEFAULT_APPEARANCE)
                applyAppearance(DEFAULT_APPEARANCE)
                window.dispatchEvent(new Event(APPEARANCE_EVENT))
              }}
            >
              <RotateCcw className="mr-2 h-3.5 w-3.5" />
              Вернуть стандартные
            </Button>
            <p className="text-xs text-muted-foreground">
              Настройки внешнего вида применяются сразу и действуют на все модули приложения.
            </p>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  )
}
