import { useMemo, useState } from 'react'
import {
  generateTZ,
  DEFAULT_PARAMS,
  BUILDING_TYPE_LABEL,
  CITY_SEISMIC,
  type ProjectParams,
  type BuildingType,
} from '@/analysis/generator'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Copy, Check, Download, ScanSearch, Sparkles } from 'lucide-react'

interface Props {
  onSendToAnalysis: (text: string, title: string) => void
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  )
}

export default function GeneratorSection({ onSendToAnalysis }: Props) {
  const [params, setParams] = useState<ProjectParams>(DEFAULT_PARAMS)
  const [copied, setCopied] = useState(false)

  const set = <K extends keyof ProjectParams>(key: K, value: ProjectParams[K]) =>
    setParams((p) => ({ ...p, [key]: value }))

  const generated = useMemo(() => generateTZ(params), [params])
  const title =
    params.objectName.trim() || `${BUILDING_TYPE_LABEL[params.buildingType]} в г. ${params.city || '—'}`

  const copy = async () => {
    await navigator.clipboard.writeText(generated)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const download = () => {
    const blob = new Blob([generated], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `ТЗ_${title.replace(/[«»"\\/:*?<>|]/g, '').slice(0, 60)}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
      {/* Форма параметров */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Sparkles className="h-4 w-4" />
            Параметры проекта
          </CardTitle>
          <CardDescription>
            Заполните краткое описание — справа автоматически собирается ТЗ с нормативными ссылками РК.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field label="Тип объекта">
            <Select
              value={params.buildingType}
              onValueChange={(v) => {
                const t = v as BuildingType
                setParams((p) => ({
                  ...p,
                  buildingType: t,
                  capacityUnit: t === 'public' ? 'человек' : 'квартир',
                  capacity: t === 'public' ? '300' : t === 'residential-single' ? '1' : '72',
                  floors: t === 'residential-single' ? '2' : p.floors,
                }))
              }}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(BUILDING_TYPE_LABEL).map(([v, l]) => (
                  <SelectItem key={v} value={v}>{l}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Название объекта" hint="Оставьте пустым — сформируется автоматически">
            <Input
              value={params.objectName}
              onChange={(e) => set('objectName', e.target.value)}
              placeholder="Жилой дом по ул. Абая, г. Алматы"
            />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Город" hint="Сейсмичность подставится автоматически">
              <Select
                value={params.city in CITY_SEISMIC ? params.city : 'other'}
                onValueChange={(v) => {
                  if (v === 'other') return set('city', '')
                  setParams((p) => ({ ...p, city: v, seismic: String(CITY_SEISMIC[v]) }))
                }}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.keys(CITY_SEISMIC).map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                  <SelectItem value="other">Другой…</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Сейсмичность, баллов">
              <Select value={params.seismic} onValueChange={(v) => set('seismic', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['5', '6', '7', '8', '9'].map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
          {!(params.city in CITY_SEISMIC) && (
            <Field label="Название города">
              <Input value={params.city} onChange={(e) => set('city', e.target.value)} placeholder="Город" />
            </Field>
          )}

          <Field label="Адрес / кадастровый номер участка">
            <Input
              value={params.address}
              onChange={(e) => set('address', e.target.value)}
              placeholder="ул. Кунаева, кадастровый № 20-311-…"
            />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Заказчик">
              <Input value={params.customer} onChange={(e) => set('customer', e.target.value)} placeholder="ТОО «…»" />
            </Field>
            <Field label="Вид строительства">
              <Select
                value={params.constructionKind}
                onValueChange={(v) => set('constructionKind', v as ProjectParams['constructionKind'])}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">Новое строительство</SelectItem>
                  <SelectItem value="reconstruction">Реконструкция</SelectItem>
                  <SelectItem value="expansion">Расширение</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Этажность">
              <Input type="number" min={1} value={params.floors} onChange={(e) => set('floors', e.target.value)} />
            </Field>
            <Field label="Общая площадь, м²">
              <Input type="number" min={1} value={params.totalArea} onChange={(e) => set('totalArea', e.target.value)} />
            </Field>
            <Field label={params.buildingType === 'public' ? 'Вместимость' : 'Кол-во квартир'}>
              <Input type="number" min={1} value={params.capacity} onChange={(e) => set('capacity', e.target.value)} />
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Высота этажа, м">
              <Input value={params.floorHeight} onChange={(e) => set('floorHeight', e.target.value)} />
            </Field>
            <Field label="Машиномест">
              <Input type="number" min={0} value={params.parkingPlaces} onChange={(e) => set('parkingPlaces', e.target.value)} />
            </Field>
            <Field label="Сроки ПСД / РД, дней">
              <div className="flex gap-1">
                <Input type="number" min={1} value={params.psdDays} onChange={(e) => set('psdDays', e.target.value)} />
                <Input type="number" min={1} value={params.rdDays} onChange={(e) => set('rdDays', e.target.value)} />
              </div>
            </Field>
          </div>

          <Field label="Конструктивная система">
            <Input value={params.structure} onChange={(e) => set('structure', e.target.value)} />
          </Field>

          <div className="flex flex-wrap gap-x-6 gap-y-2 pt-1">
            {(
              [
                ['needBim', 'BIM-модель'],
                ['needLandscaping', 'Благоустройство'],
                ['needEnergy', 'Энергоэффективность (СН РК 2.04-07-2022)'],
              ] as const
            ).map(([key, label]) => (
              <label key={key} className="flex cursor-pointer items-center gap-2 text-sm">
                <Checkbox checked={params[key]} onCheckedChange={(v) => set(key, v === true)} />
                {label}
              </label>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Результат */}
      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle className="text-base">Сгенерированное ТЗ</CardTitle>
          <CardDescription>{title} · обновляется при изменении параметров</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-1 flex-col gap-3">
          <Textarea readOnly value={generated} className="min-h-[420px] flex-1 resize-y font-mono text-xs leading-relaxed" />
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={copy}>
              {copied ? <Check className="mr-2 h-4 w-4 text-emerald-600" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? 'Скопировано' : 'Копировать'}
            </Button>
            <Button variant="outline" size="sm" onClick={download}>
              <Download className="mr-2 h-4 w-4" />
              Скачать .txt
            </Button>
            <Button size="sm" onClick={() => onSendToAnalysis(generated, title)}>
              <ScanSearch className="mr-2 h-4 w-4" />
              Отправить на анализ
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
