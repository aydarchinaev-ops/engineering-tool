import { useRef, useState } from 'react'
import '@/analysis/plugins' // регистрация встроенных плагинов-анализаторов
import { runAnalysis, getPlugins } from '@/analysis/engine'
import { useLocalStorage } from '@/hooks/useLocalStorage'
import type { AnalysisReport, Checklist, HistoryItem } from '@/types/analysis'
import AnalyzerPanel from '@/sections/AnalyzerPanel'
import ReportView from '@/sections/ReportView'
import ChecklistEditor from '@/sections/ChecklistEditor'
import HistoryPanel from '@/sections/HistoryPanel'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScanSearch, ListChecks, History, Sparkles } from 'lucide-react'

// ─── Универсальное рабочее место документа ───────────────────────────────────
// Один и тот же набор вкладок (Анализ / Генерация / Чек-лист / История)
// используется и для ТЗ, и для договора — отличаются только данные.

interface DocWorkspaceProps {
  /** Префикс ключей localStorage ('tz' | 'contract') */
  storageKey: string
  defaultChecklist: Checklist
  exampleText: string
  /** Подпись под заголовком вкладки «Анализ» */
  analyzeDescription: string
  /** Подпись вкладки «Чек-лист» */
  checklistIntro: string
  /** Содержимое вкладки «Генерация» */
  renderGenerator: (onSendToAnalysis: (text: string, title: string) => void) => React.ReactNode
  /** Подпись вкладки «Генерация» */
  generatorIntro: string
  /** Подпись кнопки с примером документа */
  exampleLabel?: string
}

type SubTab = 'analyze' | 'generate' | 'checklist' | 'history'

const SUB_TABS: { id: SubTab; label: string; icon: React.ReactNode }[] = [
  { id: 'analyze', label: 'Анализ', icon: <ScanSearch className="h-4 w-4" /> },
  { id: 'generate', label: 'Генерация', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'checklist', label: 'Чек-лист', icon: <ListChecks className="h-4 w-4" /> },
  { id: 'history', label: 'История', icon: <History className="h-4 w-4" /> },
]

export default function DocWorkspace({
  storageKey,
  defaultChecklist,
  exampleText,
  analyzeDescription,
  checklistIntro,
  renderGenerator,
  generatorIntro,
  exampleLabel,
}: DocWorkspaceProps) {
  const [tab, setTab] = useState<SubTab>('analyze')
  const [checklist, setChecklist] = useLocalStorage<Checklist>(`${storageKey}-checklist-v2`, defaultChecklist)
  const [history, setHistory] = useLocalStorage<HistoryItem[]>(`${storageKey}-history`, [])
  const [report, setReport] = useState<AnalysisReport | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [analyzerText, setAnalyzerText] = useState('')
  const [analyzerFileName, setAnalyzerFileName] = useState<string | undefined>()
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handleAnalyzerTextChange = (text: string, fileName?: string) => {
    setAnalyzerText(text)
    setAnalyzerFileName(fileName)
  }

  const handleAnalyze = (text: string, fileName?: string) => {
    setAnalyzing(true)
    setTimeout(() => {
      const result = runAnalysis(text, checklist, getPlugins(), fileName)
      setReport(result)
      setHistory((h) =>
        [
          {
            id: result.id,
            createdAt: result.createdAt,
            docTitle: result.docTitle,
            score: result.score,
            verdict: result.verdict,
            report: result,
          },
          ...h,
        ].slice(0, 50),
      )
      setAnalyzing(false)
    }, 350)
  }

  const handleSendToAnalysis = (text: string, title: string) => {
    setAnalyzerText(text)
    setAnalyzerFileName(undefined)
    setReport(null)
    setTab('analyze')
    setTimeout(() => window.scrollTo({ top: 0, behavior: 'smooth' }), 50)
    void title
  }

  // Переход к месту находки: вкладка «Анализ», фокус и выделение фрагмента
  const handleLocate = (index: number, length: number) => {
    setTab('analyze')
    setTimeout(() => {
      const el = textareaRef.current
      if (!el) return
      el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      el.focus({ preventScroll: true })
      el.setSelectionRange(index, index + length)
    }, 120)
  }

  return (
    <div className="space-y-6">
      {/* Внутренняя навигация */}
      <nav className="flex flex-wrap gap-1 rounded-lg border bg-white p-1">
        {SUB_TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm transition-colors ${
              tab === t.id ? 'bg-slate-900 text-white' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </nav>

      {tab === 'analyze' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Документ для анализа</CardTitle>
              <CardDescription>{analyzeDescription}</CardDescription>
            </CardHeader>
            <CardContent>
              <AnalyzerPanel
                onAnalyze={handleAnalyze}
                analyzing={analyzing}
                text={analyzerText}
                fileName={analyzerFileName}
                onTextChange={handleAnalyzerTextChange}
                textareaRef={textareaRef}
                exampleText={exampleText}
                exampleLabel={exampleLabel}
              />
            </CardContent>
          </Card>
          {report && <ReportView report={report} onLocate={handleLocate} />}
        </>
      )}

      {tab === 'generate' && (
        <>
          <p className="text-sm text-muted-foreground">{generatorIntro}</p>
          {renderGenerator(handleSendToAnalysis)}
        </>
      )}

      {tab === 'checklist' && (
        <>
          <div>
            <h2 className="text-lg font-semibold tracking-tight">Настройка чек-листа</h2>
            <p className="text-sm text-muted-foreground">{checklistIntro}</p>
          </div>
          <ChecklistEditor checklist={checklist} onChange={setChecklist} />
        </>
      )}

      {tab === 'history' && (
        <>
          <div>
            <h2 className="text-lg font-semibold tracking-tight">История анализов</h2>
            <p className="text-sm text-muted-foreground">
              Хранится локально в вашем браузере (до 50 последних отчётов).
            </p>
          </div>
          <HistoryPanel
            history={history}
            onOpen={(item) => {
              setReport(item.report)
              setAnalyzerText(item.report.sourceText ?? '')
              setAnalyzerFileName(undefined)
              setTab('analyze')
            }}
            onDelete={(id) => setHistory((h) => h.filter((x) => x.id !== id))}
            onClear={() => setHistory([])}
          />
        </>
      )}
    </div>
  )
}
