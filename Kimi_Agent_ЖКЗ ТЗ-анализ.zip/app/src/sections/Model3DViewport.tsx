// ─── 3D-вьюпорт массовой модели (three.js) ───────────────────────────────────
// Строит сцену по параметрам модели: участок, корпус(а) с поэтажной разбивкой,
// окна, подъезды, подземный паркинг, открытая парковка, деревья.

import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { computeLayout, type Model3DParams, type Rect } from '@/analysis/model3d'

export interface Model3DLayers {
  windows: boolean
  parking: boolean
  trees: boolean
  basement: boolean
  autorotate: boolean
}

interface Props {
  params: Model3DParams
  layers: Model3DLayers
}

const FACADE = 0xd8d2c4
const FACADE_WING = 0xcfc8b8
const SLAB = 0x8f8a80
const GLASS = 0x2e4756
const ROOF = 0x6b6560

export default function Model3DViewport({ params: p, layers }: Props) {
  const mountRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return

    const L = computeLayout(p)
    const H = p.floorHeight
    const bldH = p.floors * H

    // ── Рендерер / сцена / камера ──
    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFShadowMap
    mount.appendChild(renderer.domElement)

    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0xeef2f5)
    scene.fog = new THREE.Fog(0xeef2f5, p.siteWidth * 1.6, p.siteWidth * 4)

    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, p.siteWidth * 8)
    const fitCamera = () => {
      const r = Math.max(p.siteWidth, p.siteDepth)
      camera.position.set(r * 0.85, r * 0.7, r * 0.95)
      camera.lookAt(0, bldH * 0.3, 0)
    }
    fitCamera()

    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.08
    controls.maxPolarAngle = Math.PI / 2.02
    controls.target.set(0, bldH * 0.3, 0)
    controls.autoRotate = layers.autorotate
    controls.autoRotateSpeed = 0.8

    // ── Свет ──
    scene.add(new THREE.HemisphereLight(0xffffff, 0x9aa38e, 0.9))
    const sun = new THREE.DirectionalLight(0xfff5e6, 1.6)
    sun.position.set(-p.siteWidth * 0.6, bldH * 2.2, p.siteDepth * 0.9)
    sun.castShadow = true
    sun.shadow.mapSize.set(2048, 2048)
    const sc = Math.max(p.siteWidth, p.siteDepth) * 0.75
    Object.assign(sun.shadow.camera, { left: -sc, right: sc, top: sc, bottom: -sc, far: bldH * 6 })
    scene.add(sun)

    // ── Земля и участок ──
    const groundSize = Math.max(p.siteWidth, p.siteDepth) * 3
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(groundSize, groundSize),
      new THREE.MeshLambertMaterial({ color: 0xc9cdc2 }),
    )
    ground.rotation.x = -Math.PI / 2
    ground.position.y = -0.05
    ground.receiveShadow = true
    scene.add(ground)

    const site = new THREE.Mesh(
      new THREE.PlaneGeometry(L.site.w, L.site.d),
      new THREE.MeshLambertMaterial({ color: 0xaec49a }),
    )
    site.rotation.x = -Math.PI / 2
    site.position.y = 0.01
    site.receiveShadow = true
    scene.add(site)

    // Проезд вдоль южной границы
    const road = new THREE.Mesh(
      new THREE.PlaneGeometry(L.site.w, 7),
      new THREE.MeshLambertMaterial({ color: 0x5b5f63 }),
    )
    road.rotation.x = -Math.PI / 2
    road.position.set(0, 0.02, L.site.d / 2 - 3.5)
    road.receiveShadow = true
    scene.add(road)

    // Граница участка
    const borderPts = [
      new THREE.Vector3(-L.site.w / 2, 0.05, -L.site.d / 2),
      new THREE.Vector3(L.site.w / 2, 0.05, -L.site.d / 2),
      new THREE.Vector3(L.site.w / 2, 0.05, L.site.d / 2),
      new THREE.Vector3(-L.site.w / 2, 0.05, L.site.d / 2),
      new THREE.Vector3(-L.site.w / 2, 0.05, -L.site.d / 2),
    ]
    scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(borderPts), new THREE.LineBasicMaterial({ color: 0x8a2f2f })))

    // ── Здание ──
    const disposables: { dispose(): void }[] = []
    const facadeMat = new THREE.MeshStandardMaterial({ color: FACADE, roughness: 0.85 })
    const wingMat = new THREE.MeshStandardMaterial({ color: FACADE_WING, roughness: 0.85 })
    const slabMat = new THREE.MeshLambertMaterial({ color: SLAB })
    const roofMat = new THREE.MeshLambertMaterial({ color: ROOF })
    const glassMat = new THREE.MeshStandardMaterial({ color: GLASS, roughness: 0.25, metalness: 0.4 })
    disposables.push(facadeMat, wingMat, slabMat, roofMat, glassMat)

    const rects: { r: Rect; mat: THREE.Material }[] = [{ r: L.building, mat: facadeMat }]
    if (L.wing) rects.push({ r: L.wing, mat: wingMat })

    const windowGeo = new THREE.BoxGeometry(1.6, 1.4, 0.12)
    disposables.push(windowGeo)
    const winMatrices: THREE.Matrix4[] = []

    for (const { r, mat } of rects) {
      // Основной объём
      const body = new THREE.Mesh(new THREE.BoxGeometry(r.w, bldH, r.d), mat)
      body.position.set(r.x, bldH / 2, r.y)
      body.castShadow = body.receiveShadow = true
      scene.add(body)
      disposables.push(body.geometry)

      // Плиты (тонкие выступающие пояса)
      for (let i = 1; i < p.floors; i++) {
        const band = new THREE.Mesh(new THREE.BoxGeometry(r.w + 0.18, 0.16, r.d + 0.18), slabMat)
        band.position.set(r.x, i * H, r.y)
        scene.add(band)
        disposables.push(band.geometry)
      }

      // Парапет
      const parapet = new THREE.Mesh(new THREE.BoxGeometry(r.w + 0.3, 0.5, r.d + 0.3), roofMat)
      parapet.position.set(r.x, bldH + 0.25, r.y)
      parapet.castShadow = true
      scene.add(parapet)
      disposables.push(parapet.geometry)

      // Оконные проёмы по длинным фасадам (InstancedMesh)
      const m4 = new THREE.Matrix4()
      const cols = Math.max(1, Math.floor((r.w - 2) / 2.9))
      for (let fl = 0; fl < p.floors; fl++) {
        const wy = fl * H + H * 0.55
        for (let c = 0; c < cols; c++) {
          const wx = r.x - r.w / 2 + (r.w / (cols + 1)) * (c + 1)
          for (const side of [-1, 1]) {
            m4.makeTranslation(wx, wy, r.y + (side * r.d) / 2 + side * 0.07)
            winMatrices.push(m4.clone())
          }
        }
      }
    }
    let windowsMesh: THREE.InstancedMesh | null = null
    if (layers.windows && winMatrices.length) {
      windowsMesh = new THREE.InstancedMesh(windowGeo, glassMat, winMatrices.length)
      winMatrices.forEach((m, i) => windowsMesh!.setMatrixAt(i, m))
      windowsMesh.instanceMatrix.needsUpdate = true
      scene.add(windowsMesh)
    }

    // Подъезды: козырёк + тёмный блок входа на южном фасаде
    const canopyMat = new THREE.MeshLambertMaterial({ color: 0x374151 })
    disposables.push(canopyMat)
    for (const e of L.entrances) {
      const canopy = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.25, 2.0), canopyMat)
      canopy.position.set(e.x, H * 0.85, e.y + 0.9)
      canopy.castShadow = true
      scene.add(canopy)
      const door = new THREE.Mesh(new THREE.BoxGeometry(2.4, H * 0.8, 0.25), glassMat)
      door.position.set(e.x, (H * 0.8) / 2, e.y + 0.1)
      scene.add(door)
      disposables.push(canopy.geometry, door.geometry)
    }

    // Подземный паркинг: полупрозрачный объём под корпусом + въездной пандус
    if (p.basement && layers.basement) {
      const basMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, transparent: true, opacity: 0.35 })
      disposables.push(basMat)
      const bas = new THREE.Mesh(new THREE.BoxGeometry(L.building.w + 6, 3.3, L.building.d + 6), basMat)
      bas.position.set(L.building.x, -1.65, L.building.y)
      scene.add(bas)
      disposables.push(bas.geometry)
      const ramp = new THREE.Mesh(new THREE.BoxGeometry(6, 0.3, 14), slabMat)
      ramp.position.set(L.building.x + L.building.w / 2 + 5, -1.2, L.building.y)
      ramp.rotation.x = 0.18
      scene.add(ramp)
      disposables.push(ramp.geometry)
    }

    // ── Парковка ──
    if (layers.parking) {
      const asphaltMat = new THREE.MeshLambertMaterial({ color: 0x6b7280 })
      const markMat = new THREE.MeshBasicMaterial({ color: 0xf3f4f6 })
      const carMats = [0xb91c1c, 0x1d4ed8, 0xe5e7eb, 0x111827, 0xca8a04].map(
        (c) => new THREE.MeshLambertMaterial({ color: c }),
      )
      disposables.push(asphaltMat, markMat, ...carMats)
      let carSeed = 7
      const rnd = () => {
        carSeed = (carSeed * 1664525 + 1013904223) >>> 0
        return carSeed / 4294967296
      }
      for (const r of L.parking) {
        const lot = new THREE.Mesh(new THREE.PlaneGeometry(r.w + 1, r.d + 1.6), asphaltMat)
        lot.rotation.x = -Math.PI / 2
        lot.position.set(r.x, 0.03, r.y)
        lot.receiveShadow = true
        scene.add(lot)
        disposables.push(lot.geometry)
        const spots = Math.floor(r.w / 2.5)
        for (let i = 0; i <= spots; i++) {
          const line = new THREE.Mesh(new THREE.PlaneGeometry(0.12, r.d), markMat)
          line.rotation.x = -Math.PI / 2
          line.position.set(r.x - (spots * 2.5) / 2 + i * 2.5, 0.04, r.y)
          scene.add(line)
          disposables.push(line.geometry)
        }
        // Машины (~60% заполнение, детерминированно)
        for (let i = 0; i < spots; i++) {
          if (rnd() > 0.6) continue
          const car = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.4, 4.4), carMats[Math.floor(rnd() * carMats.length)])
          car.position.set(r.x - (spots * 2.5) / 2 + (i + 0.5) * 2.5, 0.7, r.y)
          car.castShadow = true
          scene.add(car)
          disposables.push(car.geometry)
        }
      }
    }

    // ── Деревья ──
    if (layers.trees) {
      const trunkMat = new THREE.MeshLambertMaterial({ color: 0x6b4a2b })
      const crownMat = new THREE.MeshLambertMaterial({ color: 0x3f7a3a })
      disposables.push(trunkMat, crownMat)
      const trunkGeo = new THREE.CylinderGeometry(0.18, 0.25, 1.6, 6)
      const crownGeo = new THREE.ConeGeometry(1.6, 3.6, 8)
      disposables.push(trunkGeo, crownGeo)
      for (const t of L.trees) {
        const trunk = new THREE.Mesh(trunkGeo, trunkMat)
        trunk.position.set(t.x, 0.8, t.y)
        const crown = new THREE.Mesh(crownGeo, crownMat)
        crown.position.set(t.x, 3.2, t.y)
        crown.castShadow = true
        scene.add(trunk, crown)
      }
    }

    // ── Цикл, resize, очистка ──
    const resize = () => {
      const w = mount.clientWidth
      const h = mount.clientHeight
      if (w === 0 || h === 0) return
      renderer.setSize(w, h)
      camera.aspect = w / h
      camera.updateProjectionMatrix()
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(mount)

    let raf = 0
    const tick = () => {
      raf = requestAnimationFrame(tick)
      controls.update()
      renderer.render(scene, camera)
    }
    tick()

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      controls.dispose()
      disposables.forEach((d) => d.dispose())
      scene.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          o.geometry?.dispose()
        }
      })
      renderer.dispose()
      mount.removeChild(renderer.domElement)
    }
  }, [p, layers])

  return <div ref={mountRef} className="h-[560px] w-full overflow-hidden rounded-lg border bg-slate-100" />
}
