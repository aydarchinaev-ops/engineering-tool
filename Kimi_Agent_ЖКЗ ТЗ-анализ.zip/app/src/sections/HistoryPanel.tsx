import type { HistoryItem } from '@/types/analysis'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Trash2, History } from 'lucide-react'

interface Props {
  history: HistoryItem[]
  onOpen: (item: HistoryItem) => void
  onDelete: (id: string) => void
  onClear: () => void
}

const VERDICT_LABEL = {
  excellent: 'Полное',
  good: 'Хорошее',
  weak: 'Слабое',
  poor: 'Неполное',
} as const

function badgeClass(score: number) {
  if (score >= 85) return 'bg-emerald-100 text-emerald-800 border-emerald-200'
  if (score >= 65) return 'bg-blue-100 text-blue-800 border-blue-200'
  if (score >= 40) return 'bg-amber-100 text-amber-800 border-amber-200'
  return 'bg-red-100 text-red-800 border-red-200'
}

export default function HistoryPanel({ history, onOpen, onDelete, onClear }: Props) {
  if (history.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
          <History className="h-10 w-10 text-muted-foreground/40" />
          <div>
            <p className="font-medium">История пуста</p>
            <p className="text-sm text-muted-foreground">Результаты анализов будут сохраняться здесь автоматически.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Сохранено анализов: {history.length}</p>
        <Button variant="ghost" size="sm" onClick={() => confirm('Очистить всю историю?') && onClear()}>
          <Trash2 className="mr-2 h-3.5 w-3.5" /> Очистить
        </Button>
      </div>
      {history.map((item) => (
        <Card
          key={item.id}
          className="cursor-pointer transition-colors hover:border-foreground/20"
          onClick={() => onOpen(item)}
        >
          <CardContent className="flex items-center gap-4 p-4">
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{item.docTitle}</p>
              <p className="text-xs text-muted-foreground">{new Date(item.createdAt).toLocaleString('ru-RU')}</p>
            </div>
            <Badge variant="outline" className={badgeClass(item.score)}>
              {item.score} · {VERDICT_LABEL[item.verdict]}
            </Badge>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 shrink-0 text-muted-foreground hover:text-red-600"
              onClick={(e) => {
                e.stopPropagation()
                onDelete(item.id)
              }}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
