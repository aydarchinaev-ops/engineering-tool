import { useRef, useState } from 'react'
import type { Category, Checklist, Criterion } from '@/types/analysis'
import { DEFAULT_CHECKLIST } from '@/analysis/defaultChecklist'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Download, Upload, RotateCcw, Plus, Pencil, Trash2 } from 'lucide-react'

interface Props {
  checklist: Checklist
  onChange: (c: Checklist) => void
}

const emptyCriterion = (): Criterion => ({
  id: crypto.randomUUID(),
  title: '',
  description: '',
  patterns: [],
  minMatches: 1,
  weight: 3,
  recommendation: '',
  enabled: true,
})

export default function ChecklistEditor({ checklist, onChange }: Props) {
  const [editing, setEditing] = useState<{ catId: string; criterion: Criterion } | null>(null)
  const [patternsText, setPatternsText] = useState('')
  const importRef = useRef<HTMLInputElement>(null)

  const updateCriterion = (catId: string, updated: Criterion) => {
    onChange({
      ...checklist,
      categories: checklist.categories.map((cat) =>
        cat.id === catId
          ? {
              ...cat,
              criteria: cat.criteria.some((c) => c.id === updated.id)
                ? cat.criteria.map((c) => (c.id === updated.id ? updated : c))
                : [...cat.criteria, updated],
            }
          : cat,
      ),
    })
  }

  const deleteCriterion = (catId: string, id: string) => {
    onChange({
      ...checklist,
      categories: checklist.categories.map((cat) =>
        cat.id === catId ? { ...cat, criteria: cat.criteria.filter((c) => c.id !== id) } : cat,
      ),
    })
  }

  const addCategory = () => {
    const title = prompt('Название новой категории:')
    if (!title?.trim()) return
    const cat: Category = { id: crypto.randomUUID(), title: title.trim(), criteria: [] }
    onChange({ ...checklist, categories: [...checklist.categories, cat] })
  }

  const deleteCategory = (id: string) => {
    if (!confirm('Удалить категорию со всеми критериями?')) return
    onChange({ ...checklist, categories: checklist.categories.filter((c) => c.id !== id) })
  }

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(checklist, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'checklist.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  const importJson = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result)) as Checklist
        if (!Array.isArray(data.categories)) throw new Error()
        onChange({ ...data, id: 'custom', builtIn: false })
      } catch {
        alert('Не удалось прочитать файл: некорректный формат чек-листа.')
      }
    }
    reader.readAsText(file)
  }

  const openEditor = (catId: string, criterion: Criterion) => {
    setPatternsText(criterion.patterns.join('\n'))
    setEditing({ catId, criterion: { ...criterion } })
  }

  const saveEditor = () => {
    if (!editing) return
    const criterion = {
      ...editing.criterion,
      patterns: patternsText.split('\n').map((p) => p.trim()).filter(Boolean),
    }
    updateCriterion(editing.catId, criterion)
    setEditing(null)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">{checklist.name}</CardTitle>
            <CardDescription>{checklist.description}</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={exportJson}>
              <Download className="mr-2 h-4 w-4" /> Экспорт
            </Button>
            <Button variant="outline" size="sm" onClick={() => importRef.current?.click()}>
              <Upload className="mr-2 h-4 w-4" /> Импорт
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => confirm('Вернуть стандартный чек-лист? Ваши правки будут потеряны.') && onChange(DEFAULT_CHECKLIST)}
            >
              <RotateCcw className="mr-2 h-4 w-4" /> Сбросить
            </Button>
            <input
              ref={importRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) importJson(f)
                e.target.value = ''
              }}
            />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <Accordion type="multiple" className="w-full">
          {checklist.categories.map((cat) => (
            <AccordionItem key={cat.id} value={cat.id}>
              <AccordionTrigger className="text-sm font-medium">
                <span className="flex items-center gap-2">
                  {cat.title}
                  <Badge variant="secondary" className="font-normal">
                    {cat.criteria.length}
                  </Badge>
                </span>
              </AccordionTrigger>
              <AccordionContent className="space-y-1">
                {cat.criteria.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center gap-3 rounded-md border border-transparent px-2 py-2 hover:border-border hover:bg-muted/40"
                  >
                    <Switch
                      checked={c.enabled}
                      onCheckedChange={(v) => updateCriterion(cat.id, { ...c, enabled: v })}
                    />
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm ${c.enabled ? '' : 'text-muted-foreground line-through'}`}>{c.title}</p>
                      <p className="truncate text-xs text-muted-foreground">{c.description}</p>
                    </div>
                    <Badge variant="outline" className="shrink-0 tabular-nums">
                      вес {c.weight}
                    </Badge>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditor(cat.id, c)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-red-600"
                      onClick={() => deleteCriterion(cat.id, c.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" onClick={() => openEditor(cat.id, emptyCriterion())}>
                    <Plus className="mr-1 h-3.5 w-3.5" /> Критерий
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-muted-foreground hover:text-red-600"
                    onClick={() => deleteCategory(cat.id)}
                  >
                    <Trash2 className="mr-1 h-3.5 w-3.5" /> Удалить категорию
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        <Button variant="outline" size="sm" onClick={addCategory}>
          <Plus className="mr-2 h-4 w-4" /> Новая категория
        </Button>
      </CardContent>

      {/* Диалог редактирования критерия */}
      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Критерий проверки</DialogTitle>
            <DialogDescription>
              Шаблоны — это регулярные выражения, по одному на строку. Критерий пройден, если найдено не меньше
              заданного числа различных совпадений.
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Название</Label>
                <Input
                  value={editing.criterion.title}
                  onChange={(e) => setEditing({ ...editing, criterion: { ...editing.criterion, title: e.target.value } })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Что проверяем</Label>
                <Input
                  value={editing.criterion.description}
                  onChange={(e) => setEditing({ ...editing, criterion: { ...editing.criterion, description: e.target.value } })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Шаблоны поиска (regex, по строке на шаблон)</Label>
                <Textarea
                  value={patternsText}
                  onChange={(e) => setPatternsText(e.target.value)}
                  className="min-h-[100px] font-mono text-xs"
                  placeholder={'срок[иа]?\\s+выполнени\nдедлайн'}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Важность: {editing.criterion.weight}/5</Label>
                  <Slider
                    value={[editing.criterion.weight]}
                    min={1}
                    max={5}
                    step={1}
                    onValueChange={([v]) => setEditing({ ...editing, criterion: { ...editing.criterion, weight: v } })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Мин. совпадений</Label>
                  <Input
                    type="number"
                    min={1}
                    value={editing.criterion.minMatches}
                    onChange={(e) =>
                      setEditing({ ...editing, criterion: { ...editing.criterion, minMatches: Math.max(1, +e.target.value || 1) } })
                    }
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Рекомендация при непрохождении</Label>
                <Textarea
                  value={editing.criterion.recommendation}
                  onChange={(e) => setEditing({ ...editing, criterion: { ...editing.criterion, recommendation: e.target.value } })}
                  className="min-h-[60px]"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>
              Отмена
            </Button>
            <Button onClick={saveEditor} disabled={!editing?.criterion.title.trim()}>
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
