import { useMemo, useState } from 'react'
import { generateContract, DEFAULT_CONTRACT_PARAMS, type ContractParams } from '@/analysis/contractGenerator'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Copy, Check, Download, ScanSearch, FileSignature } from 'lucide-react'

interface Props {
  onSendToAnalysis: (text: string, title: string) => void
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  )
}

export default function ContractGeneratorSection({ onSendToAnalysis }: Props) {
  const [params, setParams] = useState<ContractParams>(DEFAULT_CONTRACT_PARAMS)
  const [copied, setCopied] = useState(false)

  const set = <K extends keyof ContractParams>(key: K, value: ContractParams[K]) =>
    setParams((p) => ({ ...p, [key]: value }))

  const generated = useMemo(() => generateContract(params), [params])
  const title = `Договор на проектирование ${params.objectName || ''}`.trim()

  const copy = async () => {
    await navigator.clipboard.writeText(generated)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const download = () => {
    const blob = new Blob([generated], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `Договор_проектные_работы_${params.contractNumber.replace(/[\\/:*?<>|]/g, '-')}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileSignature className="h-4 w-4" />
            Параметры договора
          </CardTitle>
          <CardDescription>
            Структура соответствует ГК РК (подряд); флажок FIDIC добавляет положения по мотивам White Book.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Заказчик (наименование)">
              <Input value={params.customerName} onChange={(e) => set('customerName', e.target.value)} placeholder="ТОО «…»" />
            </Field>
            <Field label="БИН заказчика">
              <Input value={params.customerBin} onChange={(e) => set('customerBin', e.target.value)} placeholder="12 цифр" />
            </Field>
          </div>
          <Field label="Представитель заказчика">
            <Input value={params.customerCeo} onChange={(e) => set('customerCeo', e.target.value)} placeholder="директор Иванов И.И." />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Проектировщик (наименование)">
              <Input value={params.contractorName} onChange={(e) => set('contractorName', e.target.value)} placeholder="ТОО «…»" />
            </Field>
            <Field label="БИН проектировщика">
              <Input value={params.contractorBin} onChange={(e) => set('contractorBin', e.target.value)} placeholder="12 цифр" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Представитель проектировщика">
              <Input value={params.contractorCeo} onChange={(e) => set('contractorCeo', e.target.value)} placeholder="директор Петров П.П." />
            </Field>
            <Field label="Лицензия проектировщика №">
              <Input value={params.contractorLicense} onChange={(e) => set('contractorLicense', e.target.value)} placeholder="ГСЛ-…" />
            </Field>
          </div>

          <Field label="Объект">
            <Input value={params.objectName} onChange={(e) => set('objectName', e.target.value)} placeholder="Многоквартирный жилой дом" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Адрес объекта">
              <Input value={params.objectAddress} onChange={(e) => set('objectAddress', e.target.value)} placeholder="г. Алматы, ул. …" />
            </Field>
            <Field label="Город договора">
              <Input value={params.city} onChange={(e) => set('city', e.target.value)} />
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Цена, тенге">
              <Input value={params.price} onChange={(e) => set('price', e.target.value)} placeholder="18 000 000" />
            </Field>
            <Field label="Аванс, %">
              <Input type="number" min={0} max={100} value={params.advancePercent} onChange={(e) => set('advancePercent', e.target.value)} />
            </Field>
            <Field label="Номер договора">
              <Input value={params.contractNumber} onChange={(e) => set('contractNumber', e.target.value)} />
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Срок ПСД, дней">
              <Input type="number" min={1} value={params.psdDays} onChange={(e) => set('psdDays', e.target.value)} />
            </Field>
            <Field label="Срок РД, дней">
              <Input type="number" min={1} value={params.rdDays} onChange={(e) => set('rdDays', e.target.value)} />
            </Field>
            <Field label="Рассмотрение, раб. дней" hint="Срок приёмки заказчиком">
              <Input type="number" min={1} value={params.reviewDays} onChange={(e) => set('reviewDays', e.target.value)} />
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Неустойка, %/день">
              <Input value={params.penaltyPercent} onChange={(e) => set('penaltyPercent', e.target.value)} />
            </Field>
            <Field label="Лимит неустойки, %">
              <Input value={params.penaltyCap} onChange={(e) => set('penaltyCap', e.target.value)} />
            </Field>
            <Field label="Суд (город)">
              <Input value={params.courtCity} onChange={(e) => set('courtCity', e.target.value)} />
            </Field>
          </div>

          <label className="flex cursor-pointer items-center gap-2 pt-1 text-sm">
            <Checkbox checked={params.includeFidic} onCheckedChange={(v) => set('includeFidic', v === true)} />
            Включить положения по мотивам FIDIC (лимит ответственности, страхование, приостановление работ)
          </label>
        </CardContent>
      </Card>

      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle className="text-base">Сгенерированный договор</CardTitle>
          <CardDescription>Обновляется при изменении параметров</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-1 flex-col gap-3">
          <Textarea readOnly value={generated} className="min-h-[420px] flex-1 resize-y font-mono text-xs leading-relaxed" />
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={copy}>
              {copied ? <Check className="mr-2 h-4 w-4 text-emerald-600" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? 'Скопировано' : 'Копировать'}
            </Button>
            <Button variant="outline" size="sm" onClick={download}>
              <Download className="mr-2 h-4 w-4" />
              Скачать .txt
            </Button>
            <Button size="sm" onClick={() => onSendToAnalysis(generated, title)}>
              <ScanSearch className="mr-2 h-4 w-4" />
              Отправить на анализ
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
