import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { FileUp, FileText, ScanSearch, RotateCcw, Loader2, AlertTriangle, X } from 'lucide-react'
import { extractTextFromFile } from '@/analysis/fileExtract'

interface Props {
  onAnalyze: (text: string, fileName?: string) => void
  analyzing: boolean
  text: string
  fileName?: string
  onTextChange: (text: string, fileName?: string) => void
  /** Ref на поле ввода — используется для подсветки мест из отчёта */
  textareaRef?: React.RefObject<HTMLTextAreaElement | null>
  /** Текст кнопки «Пример» */
  exampleText: string
  /** Подпись кнопки с примером */
  exampleLabel?: string
}

export default function AnalyzerPanel({
  onAnalyze,
  analyzing,
  text,
  fileName,
  onTextChange,
  textareaRef,
  exampleText,
  exampleLabel = 'Пример ТЗ',
}: Props) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>()
  const [warning, setWarning] = useState<string>()
  const fileRef = useRef<HTMLInputElement>(null)

  const handleFile = async (file: File) => {
    setLoading(true)
    setError(undefined)
    setWarning(undefined)
    try {
      const result = await extractTextFromFile(file)
      onTextChange(result.text, file.name)
      setWarning(result.warning)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Не удалось прочитать файл.')
    } finally {
      setLoading(false)
    }
  }

  const wordCount = text.split(/\s+/).filter(Boolean).length

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={loading}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileUp className="mr-2 h-4 w-4" />}
          {loading ? 'Читаем файл…' : 'Загрузить файл'}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            onTextChange(exampleText)
            setError(undefined)
            setWarning(undefined)
          }}
        >
          <FileText className="mr-2 h-4 w-4" />
          {exampleLabel}
        </Button>
        {text && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              onTextChange('')
              setError(undefined)
              setWarning(undefined)
            }}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Очистить
          </Button>
        )}
        <input
          ref={fileRef}
          type="file"
          accept=".txt,.md,.text,.pdf,.doc,.docx"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) handleFile(f)
            e.target.value = ''
          }}
        />
        {fileName && <span className="text-xs text-muted-foreground">Файл: {fileName}</span>}
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
          <X className="mt-0.5 h-4 w-4 shrink-0" />
          {error}
        </div>
      )}
      {warning && (
        <div className="flex items-start gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          {warning}
        </div>
      )}

      <Textarea
        ref={textareaRef}
        value={text}
        onChange={(e) => onTextChange(e.target.value)}
        placeholder="Вставьте текст документа сюда…"
        className="min-h-[320px] resize-y font-mono text-sm leading-relaxed"
      />

      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">
          {wordCount > 0
            ? `${wordCount} слов · ${text.length} символов`
            : 'Поддерживаются текст и файлы PDF, DOCX, DOC, TXT, MD'}
        </span>
        <Button onClick={() => onAnalyze(text, fileName)} disabled={wordCount < 10 || analyzing || loading}>
          <ScanSearch className="mr-2 h-4 w-4" />
          {analyzing ? 'Анализ…' : 'Проанализировать'}
        </Button>
      </div>
    </div>
  )
}
