import type { AnalysisReport } from '@/types/analysis'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { CheckCircle2, XCircle, AlertTriangle, Info, Lightbulb, MapPin } from 'lucide-react'

const VERDICT = {
  excellent: { label: 'Полное ТЗ', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  good: { label: 'Хорошее, есть пробелы', className: 'bg-blue-100 text-blue-800 border-blue-200' },
  weak: { label: 'Требует доработки', className: 'bg-amber-100 text-amber-800 border-amber-200' },
  poor: { label: 'Критически неполное', className: 'bg-red-100 text-red-800 border-red-200' },
} as const

function scoreColor(score: number) {
  if (score >= 85) return '#059669'
  if (score >= 65) return '#2563eb'
  if (score >= 40) return '#d97706'
  return '#dc2626'
}

function ScoreRing({ score }: { score: number }) {
  const r = 54
  const c = 2 * Math.PI * r
  return (
    <div className="relative h-36 w-36">
      <svg viewBox="0 0 128 128" className="h-full w-full -rotate-90">
        <circle cx="64" cy="64" r={r} fill="none" stroke="#e5e7eb" strokeWidth="10" />
        <circle
          cx="64"
          cy="64"
          r={r}
          fill="none"
          stroke={scoreColor(score)}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (c * score) / 100}
          className="transition-all duration-700"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-semibold tracking-tight" style={{ color: scoreColor(score) }}>
          {score}
        </span>
        <span className="text-xs text-muted-foreground">из 100</span>
      </div>
    </div>
  )
}

const SEVERITY_ICON = {
  critical: <XCircle className="h-4 w-4 text-red-600" />,
  warning: <AlertTriangle className="h-4 w-4 text-amber-600" />,
  info: <Info className="h-4 w-4 text-blue-600" />,
}

export default function ReportView({
  report,
  onLocate,
}: {
  report: AnalysisReport
  onLocate?: (index: number, length: number) => void
}) {
  const failed = report.categoryResults.flatMap((c) =>
    c.results.filter((r) => !r.passed && r.criterion.enabled).map((r) => ({ ...r, category: c.category.title })),
  )

  return (
    <div className="space-y-6">
      {/* Сводка */}
      <Card>
        <CardContent className="flex flex-col items-start gap-6 p-6 sm:flex-row sm:items-center">
          <ScoreRing score={report.score} />
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg font-semibold tracking-tight">{report.docTitle}</h2>
              <Badge variant="outline" className={VERDICT[report.verdict].className}>
                {VERDICT[report.verdict].label}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              {new Date(report.createdAt).toLocaleString('ru-RU')} · {report.wordCount} слов ·{' '}
              {failed.length === 0 ? 'все проверки пройдены' : `не пройдено проверок: ${failed.length}`}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Категории */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Полнота по разделам</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          {report.categoryResults.map((cat) => (
            <div key={cat.category.id} className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{cat.category.title}</span>
                <span className="tabular-nums text-muted-foreground">{cat.score}%</span>
              </div>
              <Progress value={cat.score} className="h-1.5" />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Что не хватает */}
      {failed.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Lightbulb className="h-4 w-4 text-amber-500" />
              Чего не хватает — рекомендации
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="multiple" className="w-full">
              {failed
                .sort((a, b) => b.criterion.weight - a.criterion.weight)
                .map((r) => (
                  <AccordionItem key={r.criterion.id} value={r.criterion.id}>
                    <AccordionTrigger className="text-left text-sm">
                      <span className="flex items-center gap-2">
                        <XCircle className="h-4 w-4 shrink-0 text-red-500" />
                        <span>
                          {r.criterion.title}
                          <span className="ml-2 text-xs font-normal text-muted-foreground">
                            {r.category} · важность {r.criterion.weight}/5
                          </span>
                        </span>
                      </span>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-1 pl-6 text-sm">
                      <p className="text-muted-foreground">{r.criterion.description}</p>
                      <p>{r.criterion.recommendation}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
            </Accordion>
          </CardContent>
        </Card>
      )}

      {/* Все проверки */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Детализация проверок</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {report.categoryResults.map((cat) => (
            <div key={cat.category.id}>
              <p className="mt-4 mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground first:mt-0">
                {cat.category.title}
              </p>
              {cat.results
                .filter((r) => r.criterion.enabled)
                .map((r) => (
                  <div key={r.criterion.id} className="flex items-start gap-2 py-1.5 text-sm">
                    {r.passed ? (
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                    ) : (
                      <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                    )}
                    <div>
                      <span>{r.criterion.title}</span>
                      {r.passed && r.matches.length > 0 && (
                        <span className="ml-2 text-xs text-muted-foreground">
                          найдено: {r.matches.join(', ')}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Плагины */}
      {report.pluginFindings.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Дополнительные проверки</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {report.pluginFindings.map((f, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <span className="mt-0.5 shrink-0">{SEVERITY_ICON[f.severity]}</span>
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{f.title}</p>
                  <p className="text-muted-foreground">{f.detail}</p>
                  {f.locations && f.locations.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {f.locations.map((loc, j) => (
                        <button
                          key={j}
                          type="button"
                          onClick={() => onLocate?.(loc.index, loc.match.length)}
                          title={onLocate ? `Перейти к месту в тексте: ${loc.context}` : loc.context}
                          className="inline-flex max-w-full items-center gap-1 rounded-md border border-border bg-muted/50 px-2 py-1 text-xs transition-colors hover:border-foreground/30 hover:bg-muted"
                        >
                          <MapPin className="h-3 w-3 shrink-0 text-muted-foreground" />
                          <span className="truncate">
                            <mark className="bg-amber-200/70 px-0.5 rounded-sm">{loc.match}</mark>
                            <span className="ml-1 text-muted-foreground">{loc.context}</span>
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
