// ─── Доменные типы анализатора ТЗ ────────────────────────────────────────────
// Архитектура модульная: критерии и плагины — независимые единицы,
// которые можно добавлять, не меняя ядро движка.

export interface Criterion {
  id: string
  /** Короткое название проверки, напр. «Критерии приёмки» */
  title: string
  /** Что именно проверяется — показывается пользователю */
  description: string
  /** Регулярные выражения (строки). Проход = найдено >= minMatches совпадений */
  patterns: string[]
  minMatches: number
  /** Важность критерия 1–5, влияет на итоговый балл */
  weight: number
  /** Совет, который увидит пользователь, если проверка не пройдена */
  recommendation: string
  enabled: boolean
}

export interface Category {
  id: string
  title: string
  criteria: Criterion[]
}

export interface Checklist {
  id: string
  name: string
  description: string
  builtIn?: boolean
  categories: Category[]
}

// ─── Результаты ──────────────────────────────────────────────────────────────

export interface CriterionResult {
  criterion: Criterion
  passed: boolean
  /** Найденные совпадения (до 3 штук для предпросмотра) */
  matches: string[]
  matchCount: number
}

export interface CategoryResult {
  category: Category
  results: CriterionResult[]
  /** 0..100 */
  score: number
}

export interface FindingLocation {
  /** Найденный фрагмент */
  match: string
  /** Позиция начала в исходном тексте */
  index: number
  /** Контекст вокруг находки для предпросмотра */
  context: string
}

export interface PluginFinding {
  severity: 'info' | 'warning' | 'critical'
  title: string
  detail: string
  /** Места в тексте, если плагин может их указать */
  locations?: FindingLocation[]
}

/** Плагин-анализатор: расширение поверх чек-листа. */
export interface AnalyzerPlugin {
  id: string
  name: string
  description: string
  run: (text: string) => PluginFinding[]
}

export interface AnalysisReport {
  id: string
  createdAt: number
  /** Первые слова документа или имя файла */
  docTitle: string
  textLength: number
  wordCount: number
  /** 0..100 */
  score: number
  verdict: 'excellent' | 'good' | 'weak' | 'poor'
  /** Исходный текст — нужен для подсветки мест из истории */
  sourceText?: string
  categoryResults: CategoryResult[]
  pluginFindings: PluginFinding[]
}

export interface HistoryItem {
  id: string
  createdAt: number
  docTitle: string
  score: number
  verdict: AnalysisReport['verdict']
  report: AnalysisReport
}
