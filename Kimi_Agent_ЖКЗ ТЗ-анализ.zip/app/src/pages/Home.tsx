import { useState } from 'react'
import { useAppearance } from '@/hooks/useAppearance'
import { DEFAULT_CHECKLIST, EXAMPLE_TZ } from '@/analysis/defaultChecklist'
import { CONTRACT_CHECKLIST, EXAMPLE_CONTRACT } from '@/analysis/contractChecklist'
import DocWorkspace from '@/sections/DocWorkspace'
import GeneratorSection from '@/sections/GeneratorSection'
import ContractGeneratorSection from '@/sections/ContractGeneratorSection'
import InputDataChecklist from '@/sections/InputDataChecklist'
import DesignBasisSection from '@/sections/DesignBasisSection'
import SketchSection from '@/sections/SketchSection'
import Model3DSection from '@/sections/Model3DSection'
import SettingsPanel from '@/sections/SettingsPanel'
import { ClipboardCheck, FolderInput, FileSignature, Building2, DraftingCompass, PencilRuler, Box, Settings } from 'lucide-react'

type Section = 'tz' | 'input-data' | 'design-basis' | 'contract' | 'sketch' | 'model3d'

const SECTIONS: { id: Section; label: string; icon: React.ReactNode }[] = [
  { id: 'tz', label: 'ТЗ-Аналитик', icon: <ClipboardCheck className="h-4 w-4" /> },
  { id: 'input-data', label: 'Исходные данные', icon: <FolderInput className="h-4 w-4" /> },
  { id: 'contract', label: 'Договор', icon: <FileSignature className="h-4 w-4" /> },
  { id: 'design-basis', label: 'Проектные решения', icon: <DraftingCompass className="h-4 w-4" /> },
  { id: 'sketch', label: 'Эскизный проект', icon: <PencilRuler className="h-4 w-4" /> },
  { id: 'model3d', label: '3D-модель', icon: <Box className="h-4 w-4" /> },
]

export default function Home() {
  useAppearance()
  const [section, setSection] = useState<Section>('tz')
  const [settingsOpen, setSettingsOpen] = useState(false)

  return (
    <div className="min-h-screen bg-neutral-50 text-foreground">
      {/* Шапка */}
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900 text-white">
              <Building2 className="h-4 w-4" />
            </div>
            <div>
              <p className="text-sm font-semibold leading-tight tracking-tight">Проектный офис</p>
              <p className="text-[11px] leading-tight text-muted-foreground">Проектирование зданий</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <nav className="flex gap-1">
              {SECTIONS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSection(s.id)}
                  className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm transition-colors ${
                    section === s.id
                      ? 'bg-slate-900 text-white'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  {s.icon}
                  <span className="hidden sm:inline">{s.label}</span>
                </button>
              ))}
            </nav>
            <button
              onClick={() => setSettingsOpen(true)}
              className="ml-1 flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              title="Настройки промптов"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      <SettingsPanel open={settingsOpen} onOpenChange={setSettingsOpen} />

      <main className="mx-auto max-w-5xl px-4 py-8">
        {section === 'tz' && (
          <DocWorkspace
            storageKey="tz"
            defaultChecklist={DEFAULT_CHECKLIST}
            exampleText={EXAMPLE_TZ}
            analyzeDescription="Вставьте текст задания на проектирование жилого или общественного здания — движок проверит его по 8 разделам (Строительный кодекс РК № 253-VIII, СП РК) и дополнительным анализаторам."
            checklistIntro="Добавляйте собственные критерии и категории, меняйте веса, экспортируйте конфигурацию в JSON. Изменения применяются к следующим анализам автоматически."
            generatorIntro="Заполните краткое описание проекта — получите полноценное задание на проектирование со ссылками на Строительный кодекс РК № 253-VIII, СП РК и СН РК. Готовый текст можно сразу проверить анализатором."
            renderGenerator={(onSend) => <GeneratorSection onSendToAnalysis={onSend} />}
          />
        )}

        {section === 'input-data' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Исходные данные для проектирования</h1>
              <p className="text-sm text-muted-foreground">
                Чек-лист комплектности: документы к ТЗ, назначения заказчика и стартовые действия генпроектировщика.
                Отметки сохраняются в браузере.
              </p>
            </div>
            <InputDataChecklist />
          </div>
        )}

        {section === 'design-basis' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Основные проектные решения (Basis of Design)</h1>
              <p className="text-sm text-muted-foreground">
                Согласование исходных проектных решений до старта детального проектирования: параметры заказчика,
                проверки проектировщика и утверждаемый результат.
              </p>
            </div>
            <DesignBasisSection />
          </div>
        )}

        {section === 'sketch' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Эскизный проект</h1>
              <p className="text-sm text-muted-foreground">
                Минимум два варианта концепции: разделы генерируются ИИ на основе данных предыдущих модулей,
                визуализация каждого раздела — в отдельном окне.
              </p>
            </div>
            <SketchSection />
          </div>
        )}

        {section === 'model3d' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-lg font-semibold tracking-tight">3D-модель здания</h1>
              <p className="text-sm text-muted-foreground">
                Массовая модель, автоматически собранная из данных предыдущих модулей: параметры
                можно скорректировать, результат экспортируется в IFC для BIM-инструментов.
              </p>
            </div>
            <Model3DSection />
          </div>
        )}

        {section === 'contract' && (
          <DocWorkspace
            storageKey="contract"
            defaultChecklist={CONTRACT_CHECKLIST}
            exampleText={EXAMPLE_CONTRACT}
            exampleLabel="Пример договора"
            analyzeDescription="Вставьте текст договора на выполнение проектных работ — движок проверит существенные условия по ГК РК (стороны, предмет, цена, сроки, приёмка, ответственность) и опциональные положения FIDIC."
            checklistIntro="Критерии проверки договора: существенные условия по Гражданскому кодексу РК. Добавляйте свои пункты, меняйте веса, экспортируйте в JSON."
            generatorIntro="Укажите стороны, объект, цену и сроки — получите проект договора на выполнение проектных работ по структуре ГК РК. Флажок FIDIC добавляет положения по мотивам White Book. Результат требует проверки юристом."
            renderGenerator={(onSend) => <ContractGeneratorSection onSendToAnalysis={onSend} />}
          />
        )}
      </main>

      <footer className="border-t py-6">
        <p className="text-center text-xs text-muted-foreground">
          Проектный офис · анализ выполняется локально, документы никуда не отправляются · не является юридической
          консультацией
        </p>
      </footer>
    </div>
  )
}
