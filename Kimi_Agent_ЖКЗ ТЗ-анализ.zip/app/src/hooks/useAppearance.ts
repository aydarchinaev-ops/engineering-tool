// ─── Системные настройки внешнего вида ───────────────────────────────────────
// Тема (светлая/тёмная/системная), размер шрифта, гарнитура.
// Применяются к <html>/<body>, хранятся локально (app-appearance-v1).

import { useEffect } from 'react'

export interface AppearanceSettings {
  theme: 'light' | 'dark' | 'system'
  fontSize: 's' | 'm' | 'l'
  fontFamily: 'system' | 'serif' | 'mono'
}

export const APPEARANCE_KEY = 'app-appearance-v1'

export const DEFAULT_APPEARANCE: AppearanceSettings = {
  theme: 'light',
  fontSize: 'm',
  fontFamily: 'system',
}

export const APPEARANCE_EVENT = 'appearance-changed'

const FONT_SIZE_PX: Record<AppearanceSettings['fontSize'], string> = { s: '14px', m: '16px', l: '18px' }

const FONT_STACKS: Record<AppearanceSettings['fontFamily'], string> = {
  system: "-apple-system, 'Segoe UI', Roboto, 'Noto Sans', 'Helvetica Neue', Arial, sans-serif",
  serif: "Georgia, 'Times New Roman', 'Noto Serif', serif",
  mono: "'JetBrains Mono', 'SF Mono', Consolas, 'Courier New', monospace",
}

export function readAppearance(): AppearanceSettings {
  try {
    const raw = JSON.parse(localStorage.getItem(APPEARANCE_KEY) ?? '{}') as Partial<AppearanceSettings>
    return { ...DEFAULT_APPEARANCE, ...raw }
  } catch {
    return { ...DEFAULT_APPEARANCE }
  }
}

function isDark(theme: AppearanceSettings['theme']): boolean {
  if (theme === 'dark') return true
  if (theme === 'system') return window.matchMedia('(prefers-color-scheme: dark)').matches
  return false
}

export function applyAppearance(s: AppearanceSettings) {
  const root = document.documentElement
  root.classList.toggle('dark', isDark(s.theme))
  root.style.fontSize = FONT_SIZE_PX[s.fontSize]
  document.body.style.fontFamily = s.fontFamily === 'system' ? '' : FONT_STACKS[s.fontFamily]
}

/** Применяет настройки при загрузке приложения и следит за их изменением */
export function useAppearance() {
  useEffect(() => {
    const apply = () => applyAppearance(readAppearance())
    apply()
    const media = window.matchMedia('(prefers-color-scheme: dark)')
    media.addEventListener('change', apply)
    window.addEventListener(APPEARANCE_EVENT, apply)
    return () => {
      media.removeEventListener('change', apply)
      window.removeEventListener(APPEARANCE_EVENT, apply)
    }
  }, [])
}
