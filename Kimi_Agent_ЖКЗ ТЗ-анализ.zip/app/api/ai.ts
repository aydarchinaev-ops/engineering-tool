import { randomUUID } from "crypto";
import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";

// ─── ИИ-генерация (Kimi, Anthropic-совместимый Messages API) ─────────────────
// Креды провизионируются порталом в .env:
//   DEFAULT_AI_API_KEY / DEFAULT_AI_BASE_URL / DEFAULT_AI_MODEL
//
// Генерация асинхронная: start запускает фоновую задачу и сразу возвращает id,
// status отдаёт состояние. Так длинные ответы (описание + SVG-схема) не упираются
// в таймауты HTTP-шлюзов.

interface AiTextBlock {
  type: string;
  text?: string;
}

interface AiResponse {
  content?: AiTextBlock[];
  error?: { message?: string };
}

interface Job {
  state: "pending" | "done" | "error";
  text?: string;
  error?: string;
  at: number;
}

const jobs = new Map<string, Job>();

/** Чистим задачи старше 30 минут */
function sweep() {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [k, v] of jobs) if (v.at < cutoff) jobs.delete(k);
}

async function runJob(id: string, system: string, prompt: string, maxTokens: number) {
  try {
    const key = process.env.DEFAULT_AI_API_KEY;
    const base = (process.env.DEFAULT_AI_BASE_URL || "https://api.kimi.com/coding/v1").replace(/\/$/, "");
    const model = process.env.DEFAULT_AI_MODEL || "kimi-k2.5";
    if (!key) throw new Error("ИИ не настроен на сервере (нет DEFAULT_AI_API_KEY)");

    let lastError: Error | null = null;

    // До 3 попыток: длинные генерации иногда обрываются по сети
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const resp = await fetch(`${base}/messages`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": key,
            Authorization: `Bearer ${key}`,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model,
            max_tokens: maxTokens,
            // без режима размышлений — так в 5–6 раз быстрее и предсказуемее по времени
            thinking: { type: "disabled" },
            system,
            messages: [{ role: "user", content: prompt }],
          }),
          // генеральный таймаут запроса — 4 минуты
          signal: AbortSignal.timeout(240_000),
        });

        if (!resp.ok) {
          const body = await resp.text();
          // 429/5xx — временные, есть смысл повторить; 4xx — нет
          const retriable = resp.status === 429 || resp.status >= 500;
          const err = new Error(`ИИ-сервис недоступен: HTTP ${resp.status} — ${body.slice(0, 200)}`);
          if (!retriable || attempt === 3) throw err;
          lastError = err;
          await new Promise((r) => setTimeout(r, attempt * 3000));
          continue;
        }

        const data = (await resp.json()) as AiResponse;
        if (data.error?.message) throw new Error(`ИИ-сервис: ${data.error.message}`);
        const text = (data.content ?? [])
          .filter((b) => b.type === "text" && b.text)
          .map((b) => b.text!)
          .join("\n")
          .trim();
        if (!text) throw new Error("ИИ вернул пустой ответ");
        jobs.set(id, { state: "done", text, at: Date.now() });
        return;
      } catch (e) {
        const err = e instanceof Error ? e : new Error("Ошибка генерации");
        // Ошибки сети (fetch failed, таймаут) — повторяем; остальные — сразу наружу
        const isNetwork = err.name === "TimeoutError" || err.name === "AbortError" || err.message === "fetch failed";
        if (!isNetwork || attempt === 3) throw err;
        lastError = err;
        await new Promise((r) => setTimeout(r, attempt * 3000));
      }
    }
    throw lastError ?? new Error("Ошибка генерации");
  } catch (e) {
    jobs.set(id, {
      state: "error",
      error: describeError(e),
      at: Date.now(),
    });
  }
}

/** Понятное описание ошибки, включая причину обрыва сети (undici cause) */
function describeError(e: unknown): string {
  if (!(e instanceof Error)) return "Ошибка генерации";
  const cause = (e as { cause?: { code?: string; message?: string } }).cause;
  if (e.message === "fetch failed") {
    const detail = cause?.code ?? cause?.message ?? "нет соединения";
    return `Не удалось связаться с ИИ-сервисом (${detail}). Повторите попытку — обычно это временный сбой сети.`;
  }
  if (e.name === "TimeoutError" || e.name === "AbortError") {
    return "ИИ-сервис не ответил за 4 минуты — запрос прерван. Повторите попытку.";
  }
  return e.message;
}

export const aiRouter = createRouter({
  /** Запустить генерацию, вернуть id задачи */
  start: publicQuery
    .input(
      z.object({
        system: z.string().max(8000),
        prompt: z.string().max(30000),
        maxTokens: z.number().int().min(512).max(12000).optional(),
      }),
    )
    .mutation(({ input }) => {
      sweep();
      const id = randomUUID();
      jobs.set(id, { state: "pending", at: Date.now() });
      void runJob(id, input.system, input.prompt, input.maxTokens ?? 7000);
      return { id };
    }),

  /** Опрос состояния задачи */
  status: publicQuery.input(z.object({ id: z.string().uuid() })).query(({ input }) => {
    const job = jobs.get(input.id);
    if (!job) {
      return { state: "error" as const, error: "Задача не найдена (сервер был перезапущен) — запустите генерацию ещё раз" };
    }
    return job;
  }),
});
